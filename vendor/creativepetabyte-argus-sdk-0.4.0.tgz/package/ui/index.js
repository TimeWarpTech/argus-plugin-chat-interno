// src/ui/components.ts
var COMPONENT_TYPE = /* @__PURE__ */ Symbol.for("argus.ui.component");
function marker(type) {
  const component = (() => {
    throw new Error("an Argus component is composed, never called directly");
  });
  Object.defineProperty(component, COMPONENT_TYPE, { value: type });
  return component;
}
var Text = marker("text");
var Heading = marker("heading");
var Field = marker("field");
var Badge = marker("badge");
var Stack = marker("stack");
var Row = marker("row");
var Panel = marker("panel");
var Link = marker("link");
var Button = marker("button");
var Sandbox = marker("sandbox");

// src/ui/context.ts
import { useCallback, useSyncExternalStore } from "react";
var versionReaders = /* @__PURE__ */ new WeakMap();
function definePluginContext(options) {
  const states = /* @__PURE__ */ new Map();
  const listeners = /* @__PURE__ */ new Map();
  const versions = /* @__PURE__ */ new Map();
  const notify = (tenantId) => {
    versions.set(tenantId, (versions.get(tenantId) ?? 0) + 1);
    for (const listener of [...listeners.get(tenantId) ?? []]) {
      try {
        listener();
      } catch {
      }
    }
  };
  const forTenant = (tenantId) => {
    const existing = states.get(tenantId);
    if (existing !== void 0) return existing.state;
    const created = options.create(tenantId);
    states.set(tenantId, { state: created });
    return created;
  };
  const drop = (tenantId) => {
    const entry = states.get(tenantId);
    if (entry === void 0) return;
    states.delete(tenantId);
    try {
      options.destroy?.(entry.state);
    } finally {
      notify(tenantId);
    }
  };
  const handle = {
    for: forTenant,
    drop,
    dropAll() {
      for (const tenantId of [...states.keys()]) {
        try {
          drop(tenantId);
        } catch {
        }
      }
    },
    subscribe(tenantId, listener) {
      const forTenantSet = listeners.get(tenantId) ?? /* @__PURE__ */ new Set();
      forTenantSet.add(listener);
      listeners.set(tenantId, forTenantSet);
      return () => {
        forTenantSet.delete(listener);
        if (forTenantSet.size === 0 && listeners.get(tenantId) === forTenantSet) listeners.delete(tenantId);
      };
    },
    snapshot: forTenant,
    notify
  };
  versionReaders.set(handle, (tenantId) => versions.get(tenantId) ?? 0);
  return handle;
}
function usePluginContext(handle, tenantId) {
  const subscribe = useCallback((onChange) => handle.subscribe(tenantId, onChange), [handle, tenantId]);
  const version = versionReaders.get(handle);
  if (version === void 0) {
    throw new Error("usePluginContext needs a handle returned by definePluginContext, not a copy or a wrapper of one");
  }
  useSyncExternalStore(subscribe, () => version(tenantId));
  return handle.snapshot(tenantId);
}

// src/ui/host-props.ts
function portalTarget(props) {
  const container = props.portalContainer;
  if (container === void 0 || container === null) return void 0;
  return typeof container === "object" && container.nodeType === 1 ? container : void 0;
}

// src/ui/jsx-runtime.ts
function typeOf(component) {
  if (typeof component !== "function") return void 0;
  const marked = component[COMPONENT_TYPE];
  return typeof marked === "string" ? marked : void 0;
}
function childrenOf(raw) {
  if (raw === void 0 || raw === null || raw === false || raw === true) return [];
  if (Array.isArray(raw)) return raw.flatMap(childrenOf);
  if (typeof raw === "string") return [{ type: "text", value: raw }];
  return [raw];
}
function jsx(component, props) {
  const type = typeOf(component);
  if (type === void 0) {
    throw new Error("only Argus components may be used here: <div> and foreign components are not");
  }
  const { children, ...rest } = props;
  const node = { type, ...rest };
  if (type === "stack" || type === "row" || type === "panel") {
    node.children = childrenOf(children);
  }
  return node;
}
var jsxs = jsx;
var jsxDEV = jsx;
function Fragment(props) {
  return { type: "stack", children: childrenOf(props.children) };
}

// src/ui/stream.ts
var ownerOf = (topic) => topic.split(":")[0] ?? "";
function createPluginStream(host) {
  const handlers = /* @__PURE__ */ new Map();
  let release;
  const deliver = (event) => {
    for (const topic of event.topics) {
      for (const handler of [...handlers.get(topic) ?? []]) {
        try {
          handler(event);
        } catch {
        }
      }
    }
  };
  return {
    watch(topics) {
      if (host.pluginId !== void 0) {
        const foreign = topics.find((topic) => ownerOf(topic) !== host.pluginId);
        if (foreign !== void 0) {
          throw new Error(`${host.pluginId} cannot watch ${foreign}: a topic belongs to the plugin that names it`);
        }
      }
      host.watch(topics);
    },
    on(topic, handler) {
      release ??= host.subscribe(deliver);
      const forTopic = handlers.get(topic) ?? /* @__PURE__ */ new Set();
      forTopic.add(handler);
      handlers.set(topic, forTopic);
      return () => {
        forTopic.delete(handler);
        if (forTopic.size === 0) handlers.delete(topic);
        if (handlers.size === 0) {
          release?.();
          release = void 0;
        }
      };
    }
  };
}
export {
  Badge,
  Button,
  Field,
  Fragment,
  Heading,
  Link,
  Panel,
  Row,
  Sandbox,
  Stack,
  Text,
  createPluginStream,
  definePluginContext,
  jsx,
  jsxDEV,
  jsxs,
  portalTarget,
  usePluginContext
};
//# sourceMappingURL=index.js.map