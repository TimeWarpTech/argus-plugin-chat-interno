import { T as Tone, U as UiNode, S as StreamedEvent } from '../jsx-runtime-pQ-6Omvb.js';
export { F as Fragment, j as jsx, a as jsxDEV, b as jsxs } from '../jsx-runtime-pQ-6Omvb.js';

/**
 * The components a plugin composes with.
 *
 * Each is a marker the JSX runtime turns into a node. They exist so the author writes
 *
 *   <Panel title="CRM"><Field label="Plano" value="Business" /></Panel>
 *
 * with their editor completing props and their typechecker refusing mistakes -- the experience of
 * writing TSX, because it IS TSX. It compiles on the author's machine, and the tree is what ships.
 */
interface Components {
    Text: (props: {
        value: string;
        tone?: Tone;
    }) => UiNode;
    Heading: (props: {
        value: string;
    }) => UiNode;
    Field: (props: {
        label: string;
        value: string;
        mono?: boolean;
    }) => UiNode;
    Badge: (props: {
        label: string;
        tone?: Tone;
    }) => UiNode;
    Stack: (props: {
        children?: unknown;
    }) => UiNode;
    Row: (props: {
        children?: unknown;
    }) => UiNode;
    Panel: (props: {
        title?: string;
        children?: unknown;
    }) => UiNode;
    /** Somewhere inside the app. Relative only: a plugin does not navigate the tab away. */
    Link: (props: {
        label: string;
        to: string;
        icon?: string;
    }) => UiNode;
    /** Pressing it tells the plugin, as an event. There is no callback: a callback would be code. */
    Button: (props: {
        label: string;
        action: string;
        tone?: Tone;
    }) => UiNode;
    /** The plugin's own screen, in a frame of its own, for when composition is not enough. */
    Sandbox: (props: {
        title: string;
        url: string;
    }) => UiNode;
}
declare const Text: (props: {
    value: string;
    tone?: Tone;
}) => UiNode;
declare const Heading: (props: {
    value: string;
}) => UiNode;
declare const Field: (props: {
    label: string;
    value: string;
    mono?: boolean;
}) => UiNode;
declare const Badge: (props: {
    label: string;
    tone?: Tone;
}) => UiNode;
declare const Stack: (props: {
    children?: unknown;
}) => UiNode;
declare const Row: (props: {
    children?: unknown;
}) => UiNode;
declare const Panel: (props: {
    title?: string;
    children?: unknown;
}) => UiNode;
declare const Link: (props: {
    label: string;
    to: string;
    icon?: string;
}) => UiNode;
declare const Button: (props: {
    label: string;
    action: string;
    tone?: Tone;
}) => UiNode;
declare const Sandbox: (props: {
    title: string;
    url: string;
}) => UiNode;

/**
 * State that lives as long as the COMPANY does, not as long as a screen is mounted.
 *
 * The first plugin whose work outlives a screen (a music player) kept its state in a module singleton
 * and tied its lifetime to React: count the mounted components, destroy the audio when the count hits
 * zero. Opening a ticket unmounted the player screen, the count hit zero, and the music stopped. The
 * count then needed a `queueMicrotask` to survive StrictMode's double mount -- a workaround for having
 * given a component the power to end something it does not own.
 *
 * So the ownership is inverted. Here, mounting draws and never owns: `subscribe` and the hook only
 * watch, and the single thing that ends a context is `drop`, called by whoever knows the company is
 * gone (the shell, on logout or when the company switches off the plugin).
 *
 * State is keyed by company because one browser session can serve several, and company A's player
 * must never be company B's. A dropped company is not poisoned: the next `for` builds a new state.
 * That matters because the ESM module cache never re-imports a bundle, so a context that was only
 * destroyed would leave the plugin inert for the rest of the session.
 *
 * Nothing here names a DOM type: this package is typechecked without the DOM library.
 */
interface PluginContextOptions<S> {
    /** Builds one company's state. Runs once per company until that company is dropped. */
    create: (tenantId: string) => S;
    /** Releases what the state holds (an audio element, a socket). Called by `drop`, never by a screen. */
    destroy?: (state: S) => void;
}
interface PluginContextHandle<S> {
    /** This company's state, created on first use. The same instance until the company is dropped. */
    for(tenantId: string): S;
    /** Ends one company's context and tells its listeners. The next `for` builds a fresh state. */
    drop(tenantId: string): void;
    /** Ends every company's context. One failing `destroy` does not stop the others. */
    dropAll(): void;
    /** Runs `listener` when that company's state changes or is dropped. Returns the release; releasing destroys nothing. */
    subscribe(tenantId: string, listener: () => void): () => void;
    /** What a render reads: `for` under the name the store contract expects. */
    snapshot(tenantId: string): S;
    /** The state's own way to say "I changed": a mutable state calls this after it moves. */
    notify(tenantId: string): void;
}
declare function definePluginContext<S>(options: PluginContextOptions<S>): PluginContextHandle<S>;
/**
 * Reads a company's state and re-renders when it changes. It owns nothing: unmounting the last
 * component that calls this leaves the state exactly where it was.
 */
declare function usePluginContext<S>(handle: PluginContextHandle<S>, tenantId: string): S;

/**
 * The kernel stream, as a plugin's SCREEN sees it.
 *
 * A plugin on a server already hears events: it subscribes over its own connection and the kernel
 * pushes. A plugin's component in the browser had nothing -- the app's stream lives behind an internal
 * alias a plugin bundle cannot import -- so a plugin screen could only poll, or go quiet.
 *
 * This is the surface the host passes in, alongside React and the design system. It is deliberately
 * narrow: a screen says which topics it is watching and is told when they move. It never reaches the
 * connection, never sends, and hears only what the kernel already decided this session may hear --
 * `watch` is a hint about interest, not a grant of permission.
 */

/** What the host wires in. The plugin never builds one of these. */
interface PluginStreamHost {
    /** Tells the kernel which rooms this browser is watching. */
    watch(topics: readonly string[]): void;
    /** Every event this browser hears; returns the release. */
    subscribe(handler: (event: StreamedEvent) => void): () => void;
    /**
     * Who is asking. Present when the host knows which plugin this screen belongs to, and then a topic
     * outside that plugin is refused here -- so the author sees the mistake instead of silence.
     */
    pluginId?: string;
}
interface PluginStream {
    /** Says what this screen is looking at. Called again on every change; the last call wins. */
    watch(topics: readonly string[]): void;
    /** Runs `handler` for every event carrying `topic`. Returns the release. */
    on(topic: string, handler: (event: StreamedEvent) => void): () => void;
}
declare function createPluginStream(host: PluginStreamHost): PluginStream;

/**
 * What the host hands a component a plugin shipped.
 *
 * The rule is that the host does not replace anything the plugin brought — it provides only what the
 * plugin cannot provide for itself. That is React, the kernel stream, and, for a plugin that brought
 * its own stylesheets, the node where its portals have to mount. No components, no base stylesheet,
 * no reset: a plugin that ships its own design system already answered those questions.
 *
 * Two facts join that list for the same reason: which company is being looked at, which lives in the
 * shell's session, and which background effects that company approved, which is the kernel's verdict
 * on a permission the plugin can see neither side of. Both are knowledge, not capability — a plugin
 * handed them still does its own work, and one that guessed at them would be guessing at a refusal.
 *
 * The product's theme tokens are not on this list, and that is the point — they are inherited, not
 * given. Custom properties cross a shadow boundary on their own, so a plugin that writes
 * `var(--color-panel)` follows the product into dark mode, and one that writes its own colour keeps
 * it. Nobody has to arrange either.
 */
/**
 * The host's DOM node, described by what it is rather than by a DOM type.
 *
 * This package is typechecked without the DOM library, because most of it runs in Node: naming
 * `HTMLElement` here would not compile. `Element` is the caller's own type — in the browser, the real
 * one — and the shape below is what makes the runtime check possible.
 */
interface DomNode {
    nodeType: number;
}
/** What a press is worth: the kernel accepted it and will deliver it. There is no answer coming. */
interface ActionAck {
    accepted: boolean;
}
/**
 * Asks this plugin's own contract a question and waits for the answer.
 *
 * The one thing a bundle could not do: `invoke` is one-way by design, and without this a component
 * that has to show a NUMBER has nowhere to get one. Scoped to contracts this plugin itself provides —
 * the host resolves the provider from what the plugin declared and what the company installed, so
 * this opens no door the plugin did not already own.
 *
 * It resolves rather than rejects, always. The answer is whatever the contract returned, which for a
 * contract that refused the input is its own code: `{ error: "division_by_zero" }`. A refusal by the
 * HOST — not installed, not approved, not reachable — arrives in the same shape with a host code, so
 * one `error` check covers both and a "no" never arrives as an exception somebody forgot to catch.
 */
type PluginCall = (contract: string, method: string, input?: unknown) => Promise<unknown>;
/** Tells the plugin that somebody pressed something. Delivered as an event; no answer comes back. */
type PluginInvoke = (action: string, payload?: unknown) => Promise<ActionAck>;
/** Navigates to one of this plugin's internal application routes, such as `plugins/chat.tickets`. */
type PluginNavigate = (path: string) => void;
interface PluginHostProps<Element extends DomNode = DomNode, SlotNode = unknown> {
    /** Current session user, for UI defaults and read state. Backend authorization remains authoritative. */
    me?: string;
    /** Say what you are watching; be told when it moves. The data still comes through the typed client. */
    stream?: PluginStream;
    /**
     * The reader's language, as the PRODUCT decided it — never `navigator.language`.
     *
     * A BCP 47 tag, to be handed straight to `Intl` and to whatever the plugin translates with. The
     * browser's language is a different fact and the wrong one: somebody reading the product in English
     * on a Portuguese machine must not be shown half a screen in each. A plugin that reached for
     * `navigator.language` was not being careless — until now there was nothing else to reach for.
     */
    locale?: string;
    /**
     * Which company this component is being drawn for — the key its own context is kept under.
     *
     * A plugin cannot work this out: the company lives in the shell's session, and one browser session
     * serves several. Without it a plugin whose state outlives its screen had one state for every
     * company at once, so company A's player was company B's. It is the argument `usePluginContext`
     * takes, and the reason that hook asks for a company rather than assuming there is only one.
     */
    tenantId?: string;
    /**
     * The background effects this company APPROVED for this plugin, as plain effect names (`"audio"`).
     *
     * A verdict, not a request: the kernel already crossed what the plugin asked for with what the
     * company approved and with the operator's ceiling. A plugin reads it to decide whether to start the
     * effect at all, and must not re-derive it — it cannot see either input, and guessing the answer is
     * how an effect ends up running after it was refused. Absent means nothing was approved.
     */
    background?: readonly string[];
    /** Asks this plugin's own contract something and gets the answer. See `PluginCall`. */
    call?: PluginCall;
    /** Raises an event for this plugin. `{ accepted }` and nothing more — this is not a reply channel. */
    invoke?: PluginInvoke;
    /** Navigate inside the application from a custom TSX slot. */
    navigate?: PluginNavigate;
    /** Current application path, for marking the active destination in custom navigation. */
    pathname?: string;
    /** Current URL query string, including the leading question mark, for plugin deep links. */
    search?: string;
    /** Renders a host-owned extension point inside this screen, when the host supports slots. */
    renderSlot?: (name: string) => SlotNode;
    /**
     * Where anything that portals must mount, inside this plugin's own shadow root.
     *
     * `undefined` for a plugin that brought no stylesheets: it has no shadow root, so there is nothing
     * to be brought back into, and the default is right.
     */
    portalContainer?: Element;
}
/**
 * The node a portal must mount in, read out of what the host sent.
 *
 * Radix and anything else that portals mount on `document.body` by default — outside the shadow root,
 * where this plugin's stylesheet does not reach, so a menu would open with no styling at all. Passing
 * this to a `Portal`'s `container` is what keeps it where its rules are.
 *
 * Checked rather than asserted, like anything arriving from outside: a host that sends something that
 * is not an element gets the default, not a DOM call on a string.
 */
declare function portalTarget<Element extends DomNode>(props: Pick<PluginHostProps<Element>, "portalContainer">): Element | undefined;

export { type ActionAck, Badge, Button, type Components, type DomNode, Field, Heading, Link, Panel, type PluginCall, type PluginContextHandle, type PluginContextOptions, type PluginHostProps, type PluginInvoke, type PluginNavigate, type PluginStream, type PluginStreamHost, Row, Sandbox, Stack, StreamedEvent, Text, Tone, UiNode, createPluginStream, definePluginContext, portalTarget, usePluginContext };
