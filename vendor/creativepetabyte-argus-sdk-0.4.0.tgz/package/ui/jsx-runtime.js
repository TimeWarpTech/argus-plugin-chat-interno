// src/ui/components.ts
var COMPONENT_TYPE = /* @__PURE__ */ Symbol.for("argus.ui.component");
function marker(type) {
  const component = (() => {
    throw new Error("an Argus component is composed, never called directly");
  });
  Object.defineProperty(component, COMPONENT_TYPE, { value: type });
  return component;
}
var Text = marker("text");
var Heading = marker("heading");
var Field = marker("field");
var Badge = marker("badge");
var Stack = marker("stack");
var Row = marker("row");
var Panel = marker("panel");
var Link = marker("link");
var Button = marker("button");
var Sandbox = marker("sandbox");

// src/ui/jsx-runtime.ts
function typeOf(component) {
  if (typeof component !== "function") return void 0;
  const marked = component[COMPONENT_TYPE];
  return typeof marked === "string" ? marked : void 0;
}
function childrenOf(raw) {
  if (raw === void 0 || raw === null || raw === false || raw === true) return [];
  if (Array.isArray(raw)) return raw.flatMap(childrenOf);
  if (typeof raw === "string") return [{ type: "text", value: raw }];
  return [raw];
}
function jsx(component, props) {
  const type = typeOf(component);
  if (type === void 0) {
    throw new Error("only Argus components may be used here: <div> and foreign components are not");
  }
  const { children, ...rest } = props;
  const node = { type, ...rest };
  if (type === "stack" || type === "row" || type === "panel") {
    node.children = childrenOf(children);
  }
  return node;
}
var jsxs = jsx;
var jsxDEV = jsx;
function Fragment(props) {
  return { type: "stack", children: childrenOf(props.children) };
}
export {
  Fragment,
  jsx,
  jsxDEV,
  jsxs
};
//# sourceMappingURL=jsx-runtime.js.map