import { F as FetchLike, M as ManifestSlot, a as CallOptions, D as DiscoveredContract, b as PublishNotification, c as PublishNotificationResult, d as DirectoryMember, e as DiscoveredEvent, H as Host, P as PluginManifest, S as ServedContracts, f as ServedRoutes, g as PageNodeShape, h as ServedCall, i as ArtefactZone, B as BackgroundEffect } from './host-BWk47Iqh.js';
export { j as ARTEFACT_ZONES, A as ArtefactToStore, k as BACKGROUND_EFFECTS, l as CallerIdentity, E as EmittedEvent, m as Emitter, n as EmitterDeps, G as GrantView, o as HostStorage, K as KernelOffer, N as NO_ARTEFACT_STORE, O as OutboxFiles, p as OutboxWriteFailed, q as PluginOutbox, r as RELAY_CAPABILITY, s as RelayConsumer, t as RelayConsumerOptions, u as RelayLink, v as RelayOffer, R as RelayedToMe, w as RouteAnswer, x as RouteRequest, y as SlotNodeShape, z as StoredArtefact, I as backgroundScope, J as contractCallScope, L as createEmitter, Q as createFileOutbox, T as createMemoryOutbox, U as createRelayConsumer, V as createRelayLink, W as emitThroughRelay, X as eventsEmitScope, Y as eventsReadScope, Z as integrityOf, _ as nodeOutboxFiles, $ as verifyGrant } from './host-BWk47Iqh.js';
import { R as ReceivedEvent, P as PluginInstance } from './kernel-testing-CUj7buVf.js';
export { S as SseParserOptions, c as createSseParser } from './kernel-testing-CUj7buVf.js';
import { Server } from 'node:http';
import 'zod';

interface ContractProviderChange {
    contract: string;
    provider: string;
    available: boolean;
}

interface PluginClientOptions {
    /** Where the kernel is, e.g. "http://localhost:43000". */
    kernelUrl: string;
    /** The deployment's credential. It only grants the events of instances hosted here. */
    credential: string;
    /** What to do with an event. Returning normally means it was handled. */
    onEvent(event: ReceivedEvent): Promise<void> | void;
    /**
     * This instance's token, so the client can confirm delivery itself.
     *
     * Given here rather than passed to `acknowledge` on every event, because confirming is the
     * transport's job: every plugin was writing that line by hand, and getting it wrong is silent in
     * both directions — too early loses the event if the process dies, forgotten makes the kernel
     * redeliver forever. This project has shipped the first of those.
     *
     * Absent for a deployment that hosts several instances and acknowledges each by its own token.
     */
    instanceToken?: string;
    onError?(error: unknown): void;
    /**
     * Called every time the stream connects, including every reconnection.
     *
     * This is where a plugin re-announces itself. The kernel forgets everything a plugin contributed
     * when its connection goes away — deliberately, so a plugin that vanished leaves no screens behind —
     * and nothing used to say so on the way back: a kernel restart left plugins connected, answering
     * calls, and contributing no interface at all until somebody restarted each one by hand.
     *
     * A failure here is reported and the stream still runs: a plugin that cannot re-announce yet can
     * still handle the events it receives, and the next reconnection tries again.
     */
    onConnected?(): Promise<void> | void;
    /** How long before the first reconnection attempt. Doubles up to half a minute. */
    retryMs?: number;
    /** Maximum wait for handlers after disconnect/stop. Unfinished work is not acknowledged. Default 5 seconds. */
    drainTimeoutMs?: number;
    /** Maximum wait for re-announcement before consuming events. Default 30 seconds. */
    connectedTimeoutMs?: number;
    /** Injected in tests; defaults to the global. */
    fetch?: FetchLike;
}
interface PluginClient {
    /** Opens the stream and keeps reading until stopped. */
    start(): Promise<void>;
    stop(): Promise<void>;
    /** Confirms events to the kernel, in one call. */
    acknowledge(instanceToken: string, eventIds: readonly string[]): Promise<void>;
}
/**
 * A plugin's side of the connection.
 *
 * Outbound only: it opens the stream and posts back on it, so the plugin never listens on a port and
 * can live behind NAT or inside the customer's own infrastructure.
 *
 * It remembers the last event it saw and sends it as Last-Event-ID when reconnecting, which is how the
 * kernel knows where to resume. Losing that would mean asking for everything on every reconnect, or --
 * far worse -- silently skipping what arrived while it was away.
 */
declare function createPluginClient(options: PluginClientOptions): PluginClient;

/** A connection to one remote plugin over one concrete transport. */
interface PeerConnection {
    readonly peerId: string;
    readonly transport: string;
    send(message: Uint8Array): Promise<void>;
    onMessage(listener: (message: Uint8Array) => void): () => void;
    /** Notifies remote closure or transport failure, including while idle. */
    onClose?(listener: () => void): () => void;
    close(): void | Promise<void>;
}
/** One replaceable transport implementation, such as WebRTC DataChannel or a relay. */
interface PeerTransportAdapter {
    /** Stable diagnostic name for the implementation. */
    readonly name: string;
    /** Opens a connection to a peer. Failure lets the registry try the next adapter. */
    connect(peerId: string, signal: AbortSignal): Promise<PeerConnection>;
    /** Reports a peer that initiated a connection through this adapter. */
    onConnection?(listener: (connection: PeerConnection) => void): () => void;
    /** Stops listeners and other adapter-wide resources. */
    close?(): void | Promise<void>;
}
/** SDP exchanged by the signaling service; application payloads never use this path. */
interface PeerSessionDescription {
    type: "offer" | "answer";
    sdp: string;
}
/**
 * Authenticated signaling request/response interface consumed by direct transports.
 *
 * Implementations bind the caller identity to the signaling session; callers cannot select their
 * own `from` identity. The signaling service only carries session descriptions, never datachannel
 * messages.
 */
interface PeerSignalingAdapter {
    onOffer(handler: (fromPeerId: string, offer: PeerSessionDescription, signal: AbortSignal) => Promise<PeerSessionDescription>): () => void;
    requestOffer(peerId: string, offer: PeerSessionDescription, signal: AbortSignal): Promise<PeerSessionDescription>;
}
interface PeerTransportRegistryOptions {
    /** This SDK instance's stable id, used to reject self-connections. */
    localPeerId: string;
    /** Must consult a trusted grant or test policy before any adapter is contacted. */
    authorize(peerId: string, signal: AbortSignal): Promise<boolean>;
    /** Preferred first. Later adapters are tried when opening or using an earlier one fails. */
    adapters: readonly PeerTransportAdapter[];
    /** Bounds each authorization/adapter attempt. Caller signal bounds the whole operation. Defaults to 10 seconds. */
    connectTimeoutMs?: number;
}
interface PeerTransportChannel extends PeerConnection {
}
interface PeerTransportRegistry {
    connect(peerId: string, options?: {
        signal?: AbortSignal;
    }): Promise<PeerTransportChannel>;
    onConnection(listener: (channel: PeerTransportChannel) => void): () => void;
    close(): Promise<void>;
}
/**
 * Creates a transport-neutral peer connection registry.
 *
 * A failed write is never replayed: the peer may have processed it before the connection failed.
 * The registry opens the next transport for subsequent writes and reports the failed write to its
 * caller, which can retry safely with the same application-level message id if its protocol allows.
 */
declare function createPeerTransportRegistry(options: PeerTransportRegistryOptions): PeerTransportRegistry;

/** This company's own storage. `undefined` means never written; a stored `null` reads back `null`. */
interface PluginStore {
    claim?(key: string, value: unknown): Promise<boolean>;
    getVersioned?(key: string): Promise<{
        value: unknown;
        version: string;
    } | undefined>;
    setIfVersion?(key: string, value: unknown, expectedVersion: string): Promise<{
        ok: boolean;
        version: string;
    }>;
    get<T>(key: string): Promise<T | undefined>;
    set(key: string, value: unknown): Promise<void>;
    delete(key: string): Promise<void>;
}
/** What `emit` accepts beyond the event itself. */
interface EmitOptions {
    /** Events sharing one key are delivered in order; different keys go in parallel. */
    orderKey?: string;
    /**
     * The event's id, when the plugin builds its own. Minted here when omitted.
     *
     * Overridable because a deterministic id is how a plugin asks for idempotency: the examples build
     * one on purpose (`template-${count}` in the template, the dedup guards in the echo plugins), and
     * minting over them would turn every resend into a new event.
     *
     * Such an id must be scoped to THIS company. A globally scoped idempotency key is a scar from the
     * previous system, where it handed one company's installation back to another.
     */
    eventId?: string;
}
type ContractAvailabilityListener = (change: ContractProviderChange) => void | Promise<void>;
/**
 * What a plugin is handed for ONE company.
 *
 * There is no way to reach another company from here, and that is the point: isolation stops being
 * something the author remembers and becomes something the type does not offer.
 */
interface PluginContext {
    /** The company this context belongs to. For logs — never needed to keep data apart. */
    readonly tenantId: string;
    /**
     * This company's own folder, or `undefined` when the process was given none.
     *
     * Not a default path: without a persistent place, a path would promise a durability it does not
     * have, and a container's filesystem is reassigned.
     */
    readonly dataDir: string | undefined;
    /** Optional direct peer channels, configured by the runtime without binding plugins to a protocol. */
    readonly peers?: PeerTransportRegistry;
    readonly store: PluginStore;
    /**
     * Re-announces THIS company's contributions, with `slots` replacing the ones the manifest declared.
     *
     * Everything else in the announcement is unchanged — what it emits, the contracts it provides — and
     * the subscription is not touched. Here because a static manifest cannot describe a connector: a QR
     * code lives for seconds, a session badge changes with the phone, and there is one panel per person
     * who ever wrote in. Announced once from a manifest every company shares, none of that reaches a
     * screen.
     *
     * The runtime REMEMBERS the last list announced for this company, and a reconnection re-announces
     * that one rather than the static declaration: re-announcing a dead panel after a reconnect is how
     * a live QR code disappears. Called before the first connection, or while the kernel is away, it
     * keeps the list and announces it when the connection is there — it neither throws nor loses it.
     *
     * An empty list is an announcement, not a no-op: it is how a connector takes its panels down.
     */
    announce(slots: readonly ManifestSlot[]): Promise<void>;
    emit(type: string, payload: unknown, options?: EmitOptions): Promise<void>;
    call(contract: string, method: string, input: unknown, options?: CallOptions): Promise<unknown>;
    config(): Promise<Record<string, unknown>>;
    contracts?: {
        list(): Promise<DiscoveredContract[]>;
        /** Watch availability changes for a declared optional contract. Returns an unsubscribe function. */
        watch(contract: string, listener: ContractAvailabilityListener): () => void;
    };
    notifications?: {
        publish(input: PublishNotification): Promise<PublishNotificationResult>;
    };
    members?: {
        list(input?: {
            offset?: number;
            pageSize?: number;
        }): Promise<{
            members: DirectoryMember[];
            nextOffset: number | null;
        }>;
    };
    /** Optional on older hosts. Discover metadata and add subscriptions within this company. */
    events?: {
        list(): Promise<DiscoveredEvent[]>;
        subscribe(types: readonly string[]): Promise<void>;
    };
    log(line: string): void;
}
declare function contextFor(host: Host, instance: PluginInstance, dataDir: string | undefined, log?: (line: string) => void, 
/**
 * How this company re-announces its contributions. Supplied by the runtime, which is the only
 * place that holds the manifest and the connection.
 *
 * Defaults to accepting the list and doing nothing with it, so a context built on its own — in a
 * test, or by the conformance suite — is still a context a plugin can call `announce` on.
 */
announce?: (slots: readonly ManifestSlot[]) => Promise<void>, subscribe?: (types: readonly string[]) => Promise<void>, peers?: PeerTransportRegistry): PluginContext;

/** An event as a plugin receives it, with the company it is for. */
interface ConformanceEvent {
    eventId: string;
    type: string;
    tenantId: string;
    payload: unknown;
}
/**
 * What an author hands the suite: their plugin, reduced to the three things the kernel asks of it.
 *
 * Deliberately small. A plugin does a great deal the kernel has no opinion about; these are the parts
 * it is entitled to expect, so these are the parts checked.
 */
interface PluginUnderTest {
    manifest: PluginManifest;
    /** Handles one event. The same event id may arrive more than once; that is the point of scenario 1. */
    handle(host: Host, event: ConformanceEvent): Promise<void>;
    /** Everything held for that company. */
    exportTenantData(tenantId: string): Promise<unknown>;
    /** Erases it, and answers only once it is gone. */
    deleteTenantData(tenantId: string): Promise<void>;
    /**
     * Did a contract this plugin SERVES answer the last thing it was handed, with an output?
     *
     * A pure provider — `provides: [CONTACTS]`, no `consumes`, no `onEvent` at all — acts by answering
     * callers, not by handling events, so none of the evidence the first scenario reads from the host
     * would ever appear for it. This is how such a plugin says it did its job. Optional: the older
     * `handle`-shaped adapters do not serve anything, and a plugin that does is driven through
     * `conformanceFor`.
     *
     * An output, specifically, and not merely "a method was found and called": a served method that
     * answers `undefined` has done nothing a caller can use, and letting the mere existence of a
     * handler count as evidence would re-arm the trap the first scenario exists to close.
     */
    answeredAServedCall?(): boolean;
}
interface PluginScenario {
    name: string;
    /** Why this matters to somebody using the software, not what the code does. */
    matters: string;
    /** Runs the plugin through the situation and answers what went wrong, or `undefined` when it held. */
    check(plugin: PluginUnderTest): Promise<string | undefined>;
}
/**
 * What the kernel is entitled to expect of a plugin, as executable specification.
 *
 * A plugin runs this against itself. That matters because the alternative is us discovering a plugin's
 * mistakes in a customer's installation: at-least-once delivery, a contract somebody uninstalled, and
 * a process serving two companies are all situations that look fine in development and only appear
 * once the thing is real.
 *
 * Every scenario here exists because it is a mistake somebody makes on their first plugin.
 */
declare const CONFORMANCE: PluginScenario[];
interface ConformanceFailure {
    scenario: PluginScenario;
    got: string;
}
/** One company's plugin, as `create` returns it. The loose shape, so any definition satisfies it. */
interface BuiltCompany {
    onEvent?(event: ReceivedEvent): Promise<void> | void;
    serves?: ServedContracts | undefined;
    routes?: ServedRoutes | undefined;
    exportData(): Promise<unknown> | unknown;
    deleteData(): Promise<void> | void;
}
/**
 * A plugin declared with `definePlugin`, plus the one thing the suite cannot work out on its own.
 *
 * Written against the loose shape rather than `PluginDefinition<Names>` so a definition naming
 * contracts and one naming none both satisfy it without the names leaking into this file.
 */
interface DefinitionUnderTest {
    definition: {
        id: string;
        manifest: PluginManifest & {
            serves?: readonly string[] | undefined;
        };
        create(ctx: PluginContext): BuiltCompany;
    };
    /**
     * The suite's event, as the event THIS plugin really receives.
     *
     * It has to be written down, and it is the only part of the adapter an author owns. The suite's own
     * events say `exemplo.v1.Pedido`, and a plugin that dispatches on the type -- which is every plugin
     * built on `definePlugin` -- would ignore all of them and pass every scenario by doing nothing. So
     * the translation is explicit here and checked by the first scenario, rather than implicit and
     * silently able to make the whole suite vacuous.
     *
     * Optional only because a pure provider receives no events at all: a plugin with an `onEvent` and
     * no `eventFor` is handed nothing, and the first scenario says so.
     */
    eventFor?(event: ConformanceEvent): {
        type: string;
        payload: unknown;
    };
    /**
     * The call a caller really makes on a contract THIS plugin serves.
     *
     * The counterpart of `eventFor` for a provider. `provides: [CONTACTS]` with no `consumes` and no
     * `onEvent` is a whole shape of plugin -- two of this tree's examples are exactly that -- and it
     * acts by answering callers rather than by handling events. Without this it would have nowhere to
     * land what the suite hands it, and the only way to pass would be to invent an event it does not
     * listen for, which is the trap the first scenario exists to close.
     *
     * The suite cannot guess the input: a contract method validates what it is given, and `{ n: 1 }`
     * is refused by every honest one. So the author writes the call down, as they write `eventFor`.
     */
    callFor?(event: ConformanceEvent): {
        contract: string;
        method: string;
        input: unknown;
    };
}
/**
 * A declared plugin, as the suite's older `handle`/`exportTenantData` shape.
 *
 * It lives here rather than in each example because every example needs the same bookkeeping and
 * getting it wrong is silent: one built plugin per company AND per host, because the scenarios hand
 * over a different host to build a different situation -- one where the contract is provided, one
 * where nobody provides it -- and a company sharing one built plugin across them would answer out of
 * the other situation's storage.
 */
declare function conformanceFor(under: DefinitionUnderTest): PluginUnderTest;
/**
 * Runs a plugin against every scenario and answers what it failed.
 *
 * An empty array is the only passing result. A scenario that throws is a failure like any other: a
 * plugin that cannot be driven through a situation cannot be said to survive it.
 */
declare function runPluginConformance(plugin: PluginUnderTest | DefinitionUnderTest): Promise<ConformanceFailure[]>;

/**
 * One thing to paste, that says where to connect as well as how.
 *
 * A bare enrolment code only works when there is one kernel and everybody knows its address. There
 * are several backends, and a code copied from one of them says nothing about which: whoever deploys
 * the plugin would have to learn the address through some other channel and get it right, and a code
 * redeemed against the wrong server fails as "not accepted" with nothing to act on.
 *
 * So the token carries the address and the single-use code together, and a plugin needs nothing else.
 *
 * It is ENCODED, not encrypted, and that is a decision rather than an omission. The plugin has to
 * read the address before it has any relationship with the server, so there is no key it could
 * decrypt with — a key shipped inside every plugin would be a secret everybody has. What protects it
 * is what protected the bare code: it is random, it works once, it expires in minutes, and it is
 * redeemed over TLS. Encoding buys something different: one opaque word nobody retypes half of or
 * edits by hand.
 */
interface ConnectionTarget {
    /** The backend this token belongs to, without a trailing slash. */
    kernelUrl: string;
    /** The single-use enrolment code that backend minted. */
    code: string;
}
declare function encodeConnectionToken(target: ConnectionTarget): string;
/**
 * Reads a token somebody pasted, or `undefined` for anything that is not one.
 *
 * Checked rather than trusted, like everything that arrives from outside: the address decides where a
 * plugin sends its credentials, so anything that is not an http(s) URL is refused here instead of
 * being handed to `fetch`.
 */
declare function decodeConnectionToken(raw: string): ConnectionTarget | undefined;

/**
 * A page of the plugin's own, where somebody pastes the connection token.
 *
 * The only way to hand a plugin its token used to be an environment variable — fine for whoever
 * deploys with a shell, and no use to somebody who installed a plugin and has only a browser. With
 * this, a plugin that has nothing configured starts, says where its page is, and waits.
 *
 * It is the plugin's, served by the plugin's own process: the product never sees it, and it works
 * before the plugin has any relationship with any backend — which is the only moment it is needed.
 */
interface SetupPageOptions {
    /** Where to listen. `0` picks a free port, which the logged address then names. */
    port?: number;
    /**
     * Which interface to listen on. All of them by default, because a plugin in a container is reached
     * from outside it; the key in the address is what keeps a stranger out, not the interface.
     */
    host?: string;
    /** What the page calls this plugin. Drawn as text. */
    pluginName?: string;
    /** Spends the token. Throwing refuses it, and the message is what the person reads. */
    onToken(token: string): Promise<void>;
    /** Where the address is announced. Defaults to the console, because that is where a deployer looks. */
    log?(line: string): void;
}
interface SetupPage {
    /** The address to open, key included. */
    url: string;
    /** Settles once a token was accepted and the page stopped serving. */
    done: Promise<void>;
    close(): Promise<void>;
}
declare function serveSetupPage(options: SetupPageOptions): Promise<SetupPage>;

/**
 * How a plugin gets the credentials it runs with.
 *
 * There were two halves and no bridge for a while: the product could mint an enrolment code and the
 * SDK could redeem one, and nothing called it. So every plugin still needed an operator to edit
 * `PLUGIN_DEPLOYMENTS` on the server and restart the kernel — exactly what the code existed to
 * remove — while the template's README told people to paste a code that had nowhere to go.
 *
 * The ways in, in this order:
 *
 * 1. **Credentials in the environment.** How the first plugins got in before any of this existed, and
 *    how an operator deploys without a screen. It wins, because somebody said it explicitly.
 * 2. **A file this plugin wrote on a previous boot.** What a token bought, kept.
 * 3. **A connection token** — the backend's address and a single-use code as one opaque word, spent
 *    once. There are several backends, and the token is what says which one this plugin belongs to.
 * 4. **A bare enrolment code** with a `KERNEL_URL` beside it, which is the same thing in two pieces.
 * 5. **The plugin's own setup page**, when it is offered one: it waits for somebody to paste a token.
 *
 * A code is single-use by design. A plugin that enrolled on every start would need a permanent one,
 * which is a contradiction — so the file is not a cache, it is the point.
 */
interface PluginCredentials {
    /**
     * The backend this plugin belongs to.
     *
     * Part of the credentials, not configuration beside them: there are several backends, and an
     * instance token is only worth something at the one that issued it.
     */
    kernelUrl: string;
    instanceId: string;
    instanceToken: string;
    /** Opens this deployment's stream. A code buys a deployment of one. */
    credential: string;
}
interface CredentialOptions {
    /**
     * The backend's address, when it is not carried by a token. Usually `process.env.KERNEL_URL`, and
     * unnecessary with a connection token, which names its own backend.
     */
    kernelUrl?: string | undefined;
    /** A connection token, for a first boot. Usually `process.env.PLUGIN_CONNECTION_TOKEN`. */
    token?: string | undefined;
    /**
     * Where this plugin keeps its own files. The credentials land beside them, because they belong to
     * this deployment and follow it — a plugin moved to another machine with its data keeps working.
     */
    dataDir: string;
    /** A bare enrolment code, for a first boot. Usually `process.env.PLUGIN_ENROLMENT_CODE`. */
    code?: string | undefined;
    /** What this plugin calls itself, used when the code did not already name a plugin. */
    pluginId?: string | undefined;
    /**
     * Offers a page of the plugin's own to paste the token into, when there is no other way in.
     *
     * Without it a plugin with nothing configured refuses to start and says what is missing — right for
     * a deployment driven by environment variables. With it, the plugin starts, says where its setup
     * page is, and waits: right for somebody installing a plugin who has a browser and no shell.
     */
    setupPage?: Omit<SetupPageOptions, "onToken"> | undefined;
    /** Injected by tests; the real one is the platform's. */
    fetch?: FetchLike;
    /** Injected by tests. Defaults to the process environment. */
    env?: Record<string, string | undefined>;
}
declare function credentials(options: CredentialOptions): Promise<PluginCredentials>;

/** Shell extension points that accept plugin-owned React components. */
declare const NAV_RAIL: "shell.nav.rail";
declare const NAVBAR_LEADING: "shell.navbar.leading";
declare const NAVBAR_ACTIONS: "shell.navbar.actions";
/** Must stay identical to frontend/src/slots/names.ts: the host matches these strings, not the names. */
declare const DOCK: "shell.dock";
declare const RAIL_FOOTER: "shell.rail.footer";
declare const CONTENT_TOP: "shell.content.top";
declare const ACCOUNT_MENU: "shell.account.menu";
type ShellNavigationSlot = typeof NAV_RAIL | typeof NAVBAR_LEADING | typeof NAVBAR_ACTIONS | typeof DOCK | typeof RAIL_FOOTER | typeof CONTENT_TOP | typeof ACCOUNT_MENU;
/** Declare a TSX export in one of the shell's navigation slots. */
declare function shellNavigation(id: string, slot: ShellNavigationSlot, component: string, options?: {
    priority?: number;
}): ManifestSlot;

interface ScreenPage {
    /** Where the page lives, under the shell's prefix. Never a leading slash. */
    path: string;
    /** One string, or one per language — in which case it is translated as well as shown. */
    title: string | Record<string, string>;
    /** The NAME of an export in this plugin's bundle. Never code. */
    component: string;
    /** A link in the shell's navigation, addressed for you. */
    rail?: {
        icon?: string;
        label?: string;
        slot?: ShellNavigationSlot;
        priority?: number;
    };
}
interface ScreensOptions {
    /**
     * The address the operator approved, and the one the browser will download from.
     *
     * One per plugin: the bundle is the same bytes for everyone who installs it, which is the whole
     * reason there is one review, one hash and one server for it.
     */
    url: string;
    pages: readonly ScreenPage[];
}
/** The parts of a manifest screens are made of. Spread into the manifest. */
type ScreenManifest = Pick<PluginManifest, "ui" | "pages" | "slots" | "messages">;
/**
 * The message key a page's title is published under.
 *
 * Keyed by path, because a plugin with two screens has two titles. The plugin's own id is not in it:
 * the kernel hands catalogues out per plugin (`Record<pluginId, Record<locale, …>>`) and the shell
 * resolves them with the plugin already known.
 */
declare const titleKey: (path: string) => string;
/**
 * What a screen contributes, with `slots` and `messages` PRESENT rather than optional.
 *
 * `ScreenManifest` has every field optional because a manifest may carry none of them; this always
 * produces both, and saying so is what lets a caller spread them unguarded.
 */
type BuiltScreenManifest = ScreenManifest & {
    slots: ManifestSlot[];
    messages: Record<string, Record<string, string>>;
};
declare function screens({ url, pages }: ScreensOptions): BuiltScreenManifest;
/** One screen, which is what most plugins have. The same as `screens` with a list of one. */
declare const screen: (options: ScreenPage & Pick<ScreensOptions, "url">) => ScreenManifest;

interface DeclarativePage {
    /** Where the page lives, under the shell's prefix. Never a leading slash. */
    path: string;
    /** One string, or one per language — in which case it is translated as well as shown. */
    title: string | Record<string, string>;
    /** What the host draws. A page node discriminates on `type`; a slot node on `kind`. */
    content: PageNodeShape;
    /** A link in the shell's navigation, addressed for you. */
    rail?: {
        icon?: string;
        label?: string;
        slot?: ShellNavigationSlot;
        priority?: number;
    };
}
interface DeclarativeScreensOptions {
    pages: readonly DeclarativePage[];
}
/**
 * What a data-drawn screen contributes, with `slots` and `messages` PRESENT rather than optional.
 *
 * `ScreenManifest` has every field optional, because a manifest may carry none of them. This
 * function always produces both, and saying so is what lets a caller spread them without a guard:
 * the generated plugin did exactly that and showed four type errors to every author who opened it.
 */
type DeclarativeScreenManifest = ScreenManifest & {
    slots: ManifestSlot[];
    messages: Record<string, Record<string, string>>;
};
/** The parts of a manifest a data-drawn screen is made of. Spread into the manifest. */
declare function declarativeScreens({ pages }: DeclarativeScreensOptions): DeclarativeScreenManifest;

/**
 * The methods that answer one contract, by name.
 *
 * Each is handed the input and the CALL -- which says who asked, when a person asked. A method that
 * records an author reads it from there and refuses when it is absent, because the alternative is
 * taking the author's word from the browser.
 *
 * Optional because a handler invoked DIRECTLY -- in this plugin's own tests, or by an automation
 * run -- genuinely has no call behind it. The runtime always passes one; making the parameter
 * required only forced every author to write `{}` at a call site where nobody asked anything.
 */
type ContractMethods = Record<string, (input: unknown, call?: ServedCall) => unknown>;
/** What a plugin does for ONE company, apart from the contracts it answers. */
interface CompanyPluginBase {
    onEvent?(event: ReceivedEvent): Promise<void> | void;
    routes?: ServedRoutes;
    /**
     * Both are required, by the type rather than by the handshake.
     *
     * A company must be able to leave with its data and to be forgotten. The kernel refuses a plugin
     * without them, and a refusal at the handshake is a refusal somebody meets in production; a type
     * error is one they meet while writing.
     */
    exportData(): Promise<unknown> | unknown;
    deleteData(): Promise<void> | void;
    /** Called when this company goes away, to let go of what was held for it. */
    onShutdown?(): Promise<void> | void;
}
/**
 * The methods a provider answers for the contracts it names: the type of `serves`.
 *
 * Exported because a provider whose contract lives in its own factory function could not name this
 * without writing it out: `ServedContracts` is a `Record<string, …>`, and TypeScript will not accept
 * an index signature where `Record<Names, ContractMethods>` is demanded — so the factory's return had
 * to be spelled `Record<typeof CONTRACT, ContractMethods> & ServedContracts` by hand. Two providers
 * wrote that; every future one would have copied it.
 *
 * ```ts
 * const ticketsContract = (store: Store): Serves<typeof TICKETS> => ({ [TICKETS]: { List: () => … } });
 * ```
 */
type Serves<Names extends string> = Record<Names, ContractMethods> & ServedContracts;
/**
 * What a plugin does for ONE company.
 *
 * `Names` comes from the manifest, so `serves` is demanded exactly when the manifest names contracts
 * and refused when it names none: a name on one side only is a compiler error, not a startup one.
 * The intersection with `ServedContracts` is what lets the runtime pass the result to `host.serving`
 * without widening it back by hand.
 */
type CompanyPlugin<Names extends string = never> = CompanyPluginBase & ([Names] extends [never] ? {
    serves?: undefined;
} : {
    serves: Serves<Names>;
});
interface PluginDefinition<Names extends string = never> {
    id: string;
    /**
     * Announced at the handshake, and the same for every company. `serves` names the contracts.
     *
     * `serves` and `consumes` are the SDK's own words, not the kernel's: the runtime turns the first
     * into `provides` and the second into the subscription, and sends neither. They are declared here
     * so that subscribing is something the manifest says once, rather than a line in `onConnected` a
     * plugin can be shipped without — which is how a plugin ends up connected, running and deaf.
     */
    manifest: PluginManifest & {
        serves?: readonly Names[];
        consumes?: readonly string[];
    };
    /**
     * Called ONCE PER COMPANY. What is declared inside belongs to that company and no other.
     *
     * `NoInfer` keeps the manifest as the only place that names contracts: without it, a `serves` the
     * manifest never declared would teach the compiler the name instead of being refused.
     */
    create(ctx: PluginContext): CompanyPlugin<NoInfer<Names>>;
}
/**
 * Identity at runtime; the work it does is at the type level.
 *
 * `const Names` keeps the contract names as the literals the author wrote, which is what lets the
 * factory's `serves` be checked against the manifest.
 */
declare function definePlugin<const Names extends string = never>(definition: PluginDefinition<Names>): PluginDefinition<Names>;
/**
 * The loose shape every definition widens to: the check only reads names.
 *
 * Written out instead of taking `PluginDefinition<string>`, which a definition naming no contract at
 * all does not satisfy — there `serves` is refused, not merely absent.
 */
interface DeclaredPlugin {
    manifest: {
        serves?: readonly string[] | undefined;
    };
    create(ctx: PluginContext): {
        serves?: ServedContracts | undefined;
    };
}
/**
 * The contracts one company's plugin answers, checked against what the manifest declared.
 *
 * The type already refuses both mismatches at the place they are written. This is the same question
 * asked of a definition built at runtime, where no literal was available to check: declared and not
 * answered is a caller met with silence, answered and not declared is a handler the kernel never
 * reaches.
 */
declare function servedContractsOf(definition: DeclaredPlugin, ctx: PluginContext): ServedContracts;

/**
 * A plugin letting itself in with a code.
 *
 * The alternative is an operator editing a JSON blob on the server and restarting the kernel, which
 * means the company that wants a plugin cannot connect one without the people who run the machine.
 * With a code, the company generates it on its own screen and whoever deploys the plugin pastes it in
 * once.
 *
 * Once. What comes back outlives the code, and a plugin that enrolled on every boot would need the
 * code to be permanent — which is precisely what a single-use code is not. Keep what this returns the
 * way you would keep a password.
 */
interface Enrolment {
    instanceId: string;
    instanceToken: string;
    /** Opens this deployment's stream. A code buys a deployment of one. */
    credential: string;
    pluginId: string;
}
declare function enrol(options: {
    kernelUrl: string;
    code: string;
    /**
     * What this plugin calls itself.
     *
     * Used when the code did not already name one, which is the case for a code minted by "add a
     * plugin" — before this kernel has ever heard of it.
     */
    pluginId?: string;
    fetch?: FetchLike;
}): Promise<Enrolment>;

/**
 * What the environment tells a plugin about where it runs.
 *
 * Here rather than in each plugin's `main.ts`, which is the whole point of the facade: every example
 * that read one of these by hand was fourteen lines of boilerplate instead of three, and the ones
 * that did not read them were silently broken — a containerised plugin whose setup page nobody could
 * reach, an operator's `PLUGIN_INSTANCES` nothing looked at.
 *
 * Everything here is external data: a string somebody typed into a deployment. It arrives `unknown`,
 * it is validated, and a malformed value is refused at boot with the variable named — a plugin that
 * starts and fails on the first call is far harder to diagnose than one that says what is wrong.
 */
type Environment = Record<string, string | undefined>;
/** Where a plugin's setup page listens when nothing says otherwise. */
declare const SETUP_PORT = 4700;
/**
 * The port for the setup page: the option, then `PLUGIN_SETUP_PORT`, then the default.
 *
 * `scripts/plugin-container.ts` sets and maps exactly this variable, and nothing read it: with a
 * three-line `main.ts` the setup page was unreachable in a browser for every containerised plugin —
 * and the setup page is how a person pastes a connection token.
 *
 * A value that is not a port is refused rather than becoming `NaN`: `Number("8o80")` quietly listens
 * on a port nobody mapped, and the plugin looks started.
 */
declare function readSetupPort(env: Environment, option?: number): number;
/**
 * The companies one process serves, when the operator declared several.
 *
 * `undefined` when the variable is absent or empty, which is the ordinary case: one company should
 * not need JSON to say so, and `PLUGIN_INSTANCE_ID` with `PLUGIN_INSTANCE_TOKEN` keeps working.
 *
 * The capability never went away — `startWith` always took a list — but the facade left no door to
 * it, so an operator running one process for N companies would have been broken by a plan the spec
 * says is additive.
 */
declare function readInstances(env: Environment): readonly PluginInstance[] | undefined;

/**
 * The storage this needs, and nothing else.
 *
 * Spelled out here rather than taking `PluginStore` or `HostStorage`: both satisfy it — `ctx.store`
 * reads typed (`get<T>`) and `host.storage` reads `unknown`, and neither is assignable to the other —
 * so naming the narrow port is what lets a plugin written as a declaration protect itself with the
 * context it was handed instead of needing a host it is never given.
 */
interface OnceStore {
    /** Required for coordination across processes. Must be an atomic insert-if-absent. */
    claim?(key: string, value: unknown): Promise<boolean>;
    get(key: string): Promise<unknown>;
    set(key: string, value: unknown): Promise<void>;
    delete(key: string): Promise<void>;
}
/**
 * Doing something once, when the same event may arrive several times.
 *
 * Delivery is at-least-once in both directions, and that is a choice rather than a defect: the other
 * option is at-most-once, where a customer's message is simply lost. So the kernel hands an event over
 * again after a reconnection, a redelivery, or an acknowledgement that never arrived — and it cannot
 * know whether the plugin already acted, because the acting happened outside it. A message handed to
 * WhatsApp is gone from the kernel's point of view whatever happens next.
 *
 * Which leaves the plugin to decide, and every plugin was writing this by hand: three copies under
 * three names, and the WhatsApp connector had one for messages coming in and none for replies going
 * out — so a real customer was answered twice. A protection every plugin needs and any plugin can
 * forget belongs here.
 */
type Once = <T>(key: string, work: () => Promise<T> | T) => Promise<T | undefined>;
/** Another worker owns this effect, or stopped before recording its result. Keep delivery pending. */
declare class OnceInProgress extends Error {
    readonly key: string;
    constructor(key: string);
}
/**
 * Takes the storage port and not a whole host, which is all it ever touched.
 *
 * `kind` separates one sort of work from another on the same event: handling a message is not the same
 * as replying to it, and a plugin that did one should still be able to do the other.
 */
declare function createOnce(store: OnceStore, kind: string): Once;

/**
 * The two refusals, with no imports of their own.
 *
 * They live apart from the outbox that reacts to one and the relay that raises the other because
 * both of those need them: a class in either file would make the two import each other.
 */
/**
 * Thrown by an `onEvent` handler to say: understood, and wrong.
 *
 * The distinction this exists for: a refusal retried is a loop, and a silence not retried is a lost
 * event. Throw this for a payload this plugin will never accept; throw anything else -- or let a
 * failure through -- for something that might work next time.
 */
declare class EventRefused extends Error {
    readonly reason: string;
    constructor(reason: string);
}
/** Thrown by `emit` when a consumer refused. The outbox keeps the event and stops sending it. */
declare class EmitRefused extends Error {
    readonly by: string;
    readonly reason: string;
    constructor(by: string, reason: string);
}

/**
 * Refusing a caller with a code, which is what this project's contracts promise.
 *
 * The rule is written down and kept by hand everywhere: **the API answers codes, not sentences** —
 * `{ error: "not_a_participant" }` — and whoever draws the screen turns that into words in the
 * reader's language. Every plugin therefore wraps every method in the same `try`/`catch`, and the
 * internal chat alone had eight of them before this existed.
 *
 * Writing it by hand has a second cost, quieter than the typing: the `catch` that forgets to filter
 * passes an internal failure outward. A stack trace, a file path, a database message — things a
 * caller must never see, and that the kernel's own HTTP layer is careful never to leak.
 *
 * So a handler simply throws its code. What is not a code does not reach the caller, and is handed
 * to `onError` instead of vanishing.
 */

interface RefusingOptions {
    /**
     * The codes this contract answers with, when the plugin wants to be sure.
     *
     * Without it, anything shaped like a code passes — and a library throwing `timeout` or `closed`
     * is shaped like a code. Listing them makes a refusal something the plugin DECIDED to say rather
     * than something a dependency happened to throw.
     */
    codes?: readonly string[];
    /** Answered when the failure was not a code. Keep it a code, like everything else. */
    fallback?: string;
    /** Told about anything that was hidden, so a swallowed failure is still findable. */
    onError?: (error: unknown) => void;
}
/**
 * The same methods, each answering `{ error: code }` instead of throwing.
 *
 * The caller's identity is passed straight through: a handler that needs an author takes it as its
 * second argument, exactly as it would without this.
 */
declare function refusing<Methods extends ContractMethods>(methods: Methods, options?: RefusingOptions): ContractMethods;

interface StartOptions {
    kernelUrl: string;
    credential: string;
    /**
     * Serialised bytes above which an event's payload goes to the artefact store rather than the relay.
     *
     * Set it only having measured your own relay: the default is derived from the relay's body limit and
     * the inline path is faster below it at every size measured, so lowering this trades latency on each
     * large event for relieving a process every plugin shares.
     */
    largePayloadBytes?: number;
    instances: readonly PluginInstance[];
    dataDir(instance: PluginInstance): string | undefined;
    /**
     * The host for one company. Defaults to one bound to that instance's token.
     *
     * Injected so the tests need no kernel and no network: they pass `createFakeHost`.
     */
    hostFor?(instance: PluginInstance): Host;
    log?: (line: string) => void;
    /**
     * A built interface bundle to fall back on when nothing is serving `ui.url`.
     *
     * For development, where the plugin often runs before the little server that hands the bundle out.
     * Defaults to `PLUGIN_UI_BUNDLE`.
     */
    uiBundleFile?: string;
    /**
     * Ask the KERNEL to host the interface bundle, because this plugin has nowhere to serve it from.
     *
     * This is how a plugin declares it wants hosting: by handing the runtime the built file. There is
     * no sentinel address to write in the manifest, and that is deliberate — the address is an ANSWER,
     * not a declaration. The kernel decides where the bytes go and tells the plugin where they are, so
     * a `ui.url` of `kernel://bundle` would be a second, weaker way of saying the same thing and one
     * more string to keep in step with wherever the kernel actually put it.
     *
     * It is the one part of the design that needs this: a plugin on a closed machine dials out for
     * everything else, while the browser fetches its bundle directly and cannot dial in.
     *
     * A plugin that serves its own bundle leaves this unset and nothing changes for it.
     */
    hostedBundle?: {
        /**
         * The built file, e.g. `ui/dist/bundle.js`.
         *
         * Optional: without it the bytes come from the address the manifest announces, which pinning
         * fetches anyway to hash what that address is handing out. A deployment should not have to
         * repeat, as a path, a fact the runtime can already read.
         */
        file?: string;
        /** Defaults to `text/javascript`. The kernel refuses anything it will not serve. */
        contentType?: string;
        /** Defaults to `durable`: a bundle lives as long as the plugin does. */
        zone?: ArtefactZone;
    };
    /** Reported with the company that failed, so a partial start is never silent. */
    onError?: (tenantId: string, error: unknown) => void;
    /** How one instance is announced. Defaults to the handshake below; replaced in tests. */
    announce?: (instance: PluginInstance) => Promise<void>;
    /** Injected in tests; defaults to the global. */
    fetch?: FetchLike;
    /** Builds this instance's protocol-neutral peer channels. Each company receives its own registry. */
    peerTransportsFor?(instance: PluginInstance): PeerTransportRegistry | undefined;
}
/** What a started plugin offers whatever is driving it. */
interface StartedPlugin {
    /** Current credentials, including instances installed after startup. */
    tokenFor(instanceId: string): string | undefined;
    /** The companies this process is serving. For logs and for tests; never used to route anything. */
    companies(): string[];
    /** Introduces every company again, and opens what the handshake made available. */
    introduce(): Promise<void>;
    /**
     * Hands one event to the company it was addressed to. Returns when it was handled.
     *
     * REJECTS when it was not: the author's `onEvent` threw, or no company of that name is running.
     * The caller acknowledges on a return, so a failure has to reach it — swallowing one turned the
     * kernel's at-least-once delivery into at-most-once, and a locked database meant a log line, an
     * ack, and a customer's message that no longer exists anywhere.
     */
    handle(instanceId: string, event: ReceivedEvent): Promise<void>;
    stop(): Promise<void>;
}
/**
 * The part worth testing: builds one plugin per company and keeps them apart.
 *
 * One host and one `create` per instance, which IS the isolation — there is no namespacing below
 * this, so a context built once and shared would leak every company into every other one and look
 * correct from everywhere else.
 *
 * A company whose factory throws is left out and reported, rather than taking the process down --
 * one bad credential must not keep every other company off the air.
 */
declare function startWith<Names extends string>(definition: PluginDefinition<Names>, options: StartOptions): StartedPlugin;
interface RunPluginOptions {
    /** Install SIGINT/SIGTERM handlers. Disable when embedding in a process with its own lifecycle. */
    handleSignals?: boolean;
    /** Grace period before stop rejects. Signal-driven shutdown exits with failure after this deadline. */
    shutdownTimeoutMs?: number;
    /**
     * A built interface bundle to fall back on when nothing is serving `ui.url`.
     *
     * For development, where the plugin often runs before the little server that hands it out.
     * Defaults to `PLUGIN_UI_BUNDLE`.
     */
    uiBundleFile?: string;
    /**
     * Ask the KERNEL to keep the interface bundle, for a plugin with nowhere to serve it from.
     *
     * The same option `startWith` takes, forwarded — it had no door an author could reach, and this is
     * the entry point a plugin's `main.ts` actually calls. Defaults to `PLUGIN_UI_HOSTED_BUNDLE`, so an
     * operator can turn hosting on for a plugin that was not written with it in mind.
     */
    hostedBundle?: StartOptions["hostedBundle"];
    /** See `StartOptions.largePayloadBytes`. Defaults to `PLUGIN_LARGE_PAYLOAD_BYTES`. */
    largePayloadBytes?: StartOptions["largePayloadBytes"];
    /** Where this plugin keeps its files, credentials included. Defaults to `PLUGIN_DATA_DIR`. */
    dataDir?: string;
    /**
     * Where the plugin's own setup page listens, for pasting a connection token in a browser.
     *
     * Defaults to `PLUGIN_SETUP_PORT`, which is the variable the container sets and maps, and then to
     * 4700. An author writes nothing: reading that variable by hand was ten lines of `main.ts` every
     * example would have copied, and the ones that did not copy it published a page nobody could reach.
     */
    setupPort?: number;
    /**
     * The companies this process serves. Defaults to `PLUGIN_INSTANCES`, and then to the one company
     * the credentials name.
     *
     * An operator may run one process for several companies; the plugin is still written for one, and
     * `create` is still called once per company. Here because the capability existed in `startWith`
     * with no door an author could reach, and the operator's declaration is additive by spec.
     */
    instances?: readonly PluginInstance[];
    log?: (line: string) => void;
    /** Injected in tests. Defaults to the process environment. */
    env?: Environment;
    /**
     * Injected in tests; defaults to the global.
     *
     * The global's own shape rather than `FetchLike`, because this one reaches the client as well as
     * the host and the client asks for the global's — and a stand-in that satisfies the wider shape
     * satisfies the narrower one, so nothing here has to be cast.
     */
    fetch?: typeof globalThis.fetch;
    /** Installs replaceable peer transport adapters independently for each company instance. */
    peerTransportsFor?(instance: PluginInstance): PeerTransportRegistry | undefined;
}
/**
 * What an author calls: resolves credentials, wires both streams, starts.
 *
 * No decisions of its own. Everything it does beyond getting credentials and opening the connection
 * belongs to `startWith`, which is where it can be tested without a kernel.
 */
declare function runPlugin<Names extends string>(definition: PluginDefinition<Names>, options?: RunPluginOptions): Promise<{
    stop(): Promise<void>;
    readonly done: Promise<void>;
}>;

/**
 * Asking for a permission, by what it is for.
 *
 * Every one of these builds the scope name it owns. Spelling a name by hand is how a guard that
 * never matches gets shipped — it refuses nothing and nobody notices until somebody audits it — and
 * `kernel.members:read` had no builder at all, so the first plugin that needed it wrote the string
 * out, which is exactly what the other three exist to prevent.
 *
 * `essential: true` is the default because it is the common case and the safer one: the plugin will
 * not start without it, and the company is told to install or not rather than being offered a half
 * that does not work.
 */

interface RequestedScope {
    name: string;
    /** What an administrator reads while deciding. The only part that is the author's. */
    description: string;
    essential: boolean;
}
/**
 * Permission to announce this plugin's own events.
 *
 * Emitting is a permission, not plumbing: without it every emit answers 403 and the refusal is
 * recorded in the kernel's audit trail. Declaring `emits` is not enough.
 */
declare const emitOwnEvents: (pluginId: string, description: string, options?: {
    essential?: boolean;
}) => RequestedScope;
/** Permission to hear another plugin's events. */
declare const readEventsOf: (owner: string, description: string, options?: {
    essential?: boolean;
}) => RequestedScope;
/** Permission to call a contract somebody else provides. */
declare const callContract: (contract: string, description: string, options?: {
    essential?: boolean;
}) => RequestedScope;
/** Permission to read the company's staff directory — `ctx.members.list()`. */
declare const readMembers: (description: string, options?: {
    essential?: boolean;
}) => RequestedScope;
/** A scope that can never be essential: the type says so, not only the comment. */
type BackgroundScope = RequestedScope & {
    essential: false;
};
/**
 * Ask the company to let this plugin keep an effect going after its screen closes.
 *
 * Takes no `essential` option, unlike every builder above, and that is the point. The spec requires
 * that refusing this leaves a working plugin (it just stops when the screen does); making it
 * essential would turn a refusal into "cannot install", which is a different question from the one
 * the company was asked.
 *
 * `description` is the catalogue KEY `scopes.shell.background.<effect>`, not the author's text,
 * despite what `RequestedScope.description` says. The shell owns these scopes, so there is no author
 * to describe them, and the approval screen resolves `shell.*` descriptions from its own catalogue
 * in the viewer's language. An effect the shell does not know is dropped: a typo asks for nothing
 * rather than for a scope no screen can explain.
 */
declare const background: (effects: readonly BackgroundEffect[]) => BackgroundScope[];
/** Permission to publish persistent in-app notifications for company members. */
declare const sendNotifications: (description: string, options?: {
    essential?: boolean;
}) => RequestedScope;

/**
 * Handing out a plugin's own interface build.
 *
 * Separate from the plugin's process on purpose: the bundle is the same bytes for everyone who
 * installs the plugin, which is the whole reason there is one review, one hash and one server for
 * it. The process may run on somebody's laptop while the bundle sits at a public address — what has
 * to match is the `integrity`, which the runtime computes from whatever this is serving.
 *
 * It is here because it was the same forty lines in every plugin that ships a screen, and the parts
 * that are easy to get subtly wrong — the content type the browser needs, the CORS header the
 * fetch needs, `no-store` so a cached build does not fail its integrity check in a way that looks
 * like a wrong hash, and refusing a path that climbs out of the directory — were copied along with
 * them, waiting for one copy to drift.
 */

interface ServeBundleOptions {
    /** The directory holding the build — usually `ui/dist`. */
    directory: string;
    /** Defaults to `PLUGIN_UI_PORT`, then to 4600. Keep it below 49152 (see below). */
    port?: number;
    /** Named in the log, so somebody with four of these running knows which is which. */
    pluginId?: string;
    log?: (line: string) => void;
}
/**
 * Serves one directory, one level deep, and nothing else.
 *
 * A plugin handing out its own build has no reason to read anywhere else, and a path containing
 * `..` is somebody asking for a file that is not theirs.
 */
declare function serveBundle(options: ServeBundleOptions): Server;

/** Compatible with synchronous schema parsers, including Zod. Throws on invalid data. */
interface ValueSchema<T> {
    parse(value: unknown): T;
}
interface MethodSchema<Input = unknown, Output = unknown> {
    input: ValueSchema<Input>;
    output: ValueSchema<Output>;
}
type InputOf<M extends MethodSchema> = ReturnType<M["input"]["parse"]>;
type OutputOf<M extends MethodSchema> = ReturnType<M["output"]["parse"]>;
/**
 * What a provider implements, typed.
 *
 * `call` carries whoever the KERNEL named, and it is optional because it is absent far more often
 * than not: a call from another plugin has nobody behind it. A handler that needs an author checks
 * for it and refuses, rather than inventing one.
 *
 * It is here because without it this boundary was unusable by exactly the plugins that most need a
 * boundary — anything storing something with an author — and they fell back to validating `unknown`
 * by hand.
 */
type TypedHandlers<Methods extends Record<string, MethodSchema>> = {
    [K in keyof Methods]: (input: InputOf<Methods[K]>, call?: ServedCall) => OutputOf<Methods[K]> | Promise<OutputOf<Methods[K]>>;
};
/** An opt-in typed boundary. Existing string-based context calls remain available. */
declare function defineContract<const Name extends string, const Methods extends Record<string, MethodSchema>>(name: Name, methods: Methods): {
    name: Name;
    call<K extends keyof Methods & string>(context: Pick<PluginContext, "call">, method: K, input: InputOf<Methods[K]>, options?: CallOptions): Promise<OutputOf<Methods[K]>>;
    serve(handlers: TypedHandlers<Methods>): Serves<Name>;
};
declare function defineEvent<const Name extends string, Payload>(name: Name, schema: ValueSchema<Payload>): {
    name: Name;
    parse: (value: unknown) => Payload;
    emit(context: Pick<PluginContext, "emit">, payload: Payload, options?: EmitOptions): Promise<void>;
};

export { ACCOUNT_MENU, ArtefactZone, BackgroundEffect, type BackgroundScope, type BuiltScreenManifest, CONFORMANCE, CONTENT_TOP, CallOptions, type CompanyPlugin, type ConformanceEvent, type ConformanceFailure, type ConnectionTarget, type ContractAvailabilityListener, type ContractMethods, type ContractProviderChange, type CredentialOptions, DOCK, type DeclarativePage, type DeclarativeScreensOptions, type DefinitionUnderTest, DiscoveredContract, DiscoveredEvent, type EmitOptions, EmitRefused, type Enrolment, type Environment, EventRefused, FetchLike, Host, ManifestSlot, type MethodSchema, NAVBAR_ACTIONS, NAVBAR_LEADING, NAV_RAIL, type Once, OnceInProgress, type OnceStore, PageNodeShape, type PeerConnection, type PeerSessionDescription, type PeerSignalingAdapter, type PeerTransportAdapter, type PeerTransportChannel, type PeerTransportRegistry, type PeerTransportRegistryOptions, type PluginClient, type PluginClientOptions, type PluginContext, type PluginCredentials, type PluginDefinition, PluginInstance, PluginManifest, type PluginScenario, type PluginStore, type PluginUnderTest, PublishNotification, PublishNotificationResult, RAIL_FOOTER, ReceivedEvent, type RefusingOptions, type RequestedScope, type RunPluginOptions, SETUP_PORT, type ScreenManifest, type ScreenPage, type ScreensOptions, type ServeBundleOptions, ServedCall, ServedContracts, ServedRoutes, type Serves, type SetupPage, type SetupPageOptions, type ShellNavigationSlot, type StartOptions, type StartedPlugin, type TypedHandlers, type ValueSchema, background, callContract, conformanceFor, contextFor, createOnce, createPeerTransportRegistry, createPluginClient, credentials, declarativeScreens, decodeConnectionToken, defineContract, defineEvent, definePlugin, emitOwnEvents, encodeConnectionToken, enrol, readEventsOf, readInstances, readMembers, readSetupPort, refusing, runPlugin, runPluginConformance, screen, screens, sendNotifications, serveBundle, serveSetupPage, servedContractsOf, shellNavigation, startWith, titleKey };
