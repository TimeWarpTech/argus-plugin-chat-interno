# Argus Plugin SDK

Install the SDK with:

```sh
npm install @creativepetabyte/argus-sdk
```

Plugins declare contract dependencies in their manifest. A dependency with `essential: false` lets the
plugin start without a provider and is a good candidate for watching availability changes:

```ts
const CONTACTS = "chat.contacts.v1.Contacts";

export const plugin = definePlugin({
  id: "chat.reports",
  manifest: {
    requires: [{ contract: CONTACTS, essential: false }],
  },
  create(ctx) {
    const stopWatching = ctx.contracts?.watch(CONTACTS, ({ provider, available }) => {
      if (available) ctx.log(`${provider} is ready`);
      else ctx.log(`${provider} is unavailable`);
    });

    return {
      exportData: () => ({}),
      deleteData: () => {},
      onShutdown() {
        stopWatching?.();
      },
    };
  },
});
```

`watch` reports changes for the current company when a provider is installed, enabled, accepted at
handshake, disabled, removed, disconnected, or reconnects. A change contains the contract name, provider
plugin id, and its new availability. Call `ctx.contracts.list()` for the current snapshot when the
plugin starts; the watcher reports subsequent changes. Kernel control notifications are delivered to
the installed consumer that declared the contract and do not require the provider's business-event
permission.

## Typed contracts and events

`defineContract` adds typed method names, inputs and outputs without changing existing
`ctx.call` consumers. Both caller and provider validate data at runtime. Schemas must expose
`parse(unknown)`; synchronous Zod schemas work directly. Share the declaration between plugins.

```ts
import { defineContract, defineEvent, definePlugin } from "@creativepetabyte/argus-sdk";
import { z } from "zod";

export const calculator = defineContract("demo.Calculator", {
  Add: {
    input: z.object({ a: z.number(), b: z.number() }),
    output: z.number(),
  },
});
export const calculated = defineEvent("demo.Calculated", z.object({ value: z.number() }));

export const plugin = definePlugin({
  id: "demo.calculator",
  manifest: { serves: [calculator.name] },
  create(ctx) {
    return {
      serves: calculator.serve({ Add: ({ a, b }) => a + b }),
      exportData: () => ({}),
      deleteData: () => {},
    };
  },
});

// In a consumer with the corresponding manifest permissions:
// const value = await calculator.call(ctx, "Add", { a: 2, b: 3 }); // number
// await calculated.emit(ctx, { value });
```

These helpers do not register permissions or bypass the kernel's authorization. Raw
`ctx.call`, `ctx.emit` and storage reads remain available and do not infer application schemas.

## Stream recovery

`createPluginClient` waits up to `drainTimeoutMs` (default 5 seconds) for pending handlers
when a stream disconnects or stops, then reports `plugin_handler_drain_timeout` and releases
the connection. It does not acknowledge unfinished work or cancel the application's side effect.
Redelivery of the same instance/event pair joins the existing pending handler across reconnects.
A handler that never completes still requires application recovery; persistent idempotency is
needed across process restarts. `connectedTimeoutMs` (default 30 seconds) bounds re-announcement.

`createSseParser` accepts LF, CRLF and CR across arbitrary chunk boundaries. It defaults to
8 Mi UTF-16 code units per frame (`maxFrameChars` can override this). An oversized frame throws
`sse_frame_too_large`; discard that parser and reconnect. The limit counts comments and unknown
fields as well as event data, and applies per frame rather than per network chunk.


The relay consumer also bounds reconnection drain with `drainTimeoutMs` (default 5 seconds).
In-progress event IDs and ordered lanes survive reconnection. Its `stop()` rejects if work
remains after the deadline: callers must not interpret that as permission to erase tenant data
or tear down resources still in use. The runtime's administrative export/delete path reports
failure in this case. A later `stop()` can complete once the work has actually settled.

## Persistent in-app notifications

Declare `sendNotifications("Notify members about new activity")` in `requestedScopes`. It is optional
by default: existing companies must approve `kernel.notifications:write` before publication succeeds.
The kernel advertises `kernel.notifications.v1`. The recipient inbox is part of the shell, including
unread counts, reading one or all items, pagination and realtime updates across the user's tabs.

```ts
await ctx.notifications?.publish({
  key: `message:${message.id}`,
  recipients: participantIds.filter((id) => id !== message.authorId),
  title: { "pt-BR": "Nova mensagem", en: "New message" },
  body: message.text.slice(0, 1000),
  page: "chat-interno",
  query: { conversation: message.conversationId },
});
```

The instance token supplies the company and source plugin; they cannot be supplied in the input.
Recipients must be active accepted company members. `page` must be a page announced by this plugin;
external URLs are refused. Titles require both supported languages. A request accepts at most 100
recipients, a title of 160 characters per language and 1000 body characters. Split larger recipient
sets into batches with distinct keys. Do not publish sensitive content to anyone who cannot read it.

The same `(company, plugin, recipient, key)` is persisted once, including simultaneous retries.
`created` and `ids` describe newly inserted entries, so a retry can return zero. Persist pending work
and retry with the same key after transport failure; the SDK does not silently retry business writes.
A successful response confirms database persistence. Realtime signals carry no message content, and
reconnection refetches the inbox. This API does not request browser or operating-system push permission.

A plugin screen receives the current query string as `PluginHostProps.search`; read it with
`URLSearchParams` to open the item named by the notification. Backend authorization still applies.
