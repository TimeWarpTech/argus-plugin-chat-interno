import { H as Host, P as PluginManifest, S as ServedContracts, f as ServedRoutes, F as FetchLike } from './host-BWk47Iqh.js';

/** One event as it arrives off the wire. */
interface ReceivedEvent {
    eventId: string;
    type: string;
    instanceId: string;
    tenantId: string;
    orderKey: string;
    payload: unknown;
}
/**
 * Parses an SSE byte stream into events.
 *
 * Separate from the connection so it can be tested without a socket, and because this is where the
 * mistakes are: a frame split across two chunks, a heartbeat comment, a field the kernel added later.
 */
interface SseParserOptions {
    /** Maximum UTF-16 code units per frame, including comments and unknown fields. Defaults to 8 Mi. */
    maxFrameChars?: number;
}
declare function createSseParser(onEvent: (event: {
    id?: string;
    data: string;
}) => void, options?: SseParserOptions): {
    push(chunk: string): void;
};

/**
 * Several companies in one process, without a plugin ever knowing.
 *
 * A plugin belongs to ONE company. That is what makes its code simple — no tenant threaded through
 * every function, no query that has to remember a filter — and what makes its isolation real rather
 * than promised. The company is the backend's business: it lives in the token, the kernel decides it,
 * and the plugin is never asked to carry it.
 *
 * But a process per company means hundreds of processes for a product with hundreds of customers, each
 * with its own connection and its own memory. So the multiplexing happens here, at the edge: one
 * connection, one host per company, its own folder for its own data, and each event routed to the
 * instance it was addressed to. The author writes a function that takes a host; the proxy runs it once
 * per company.
 */
/** One company's instance, as the operator configured it. */
interface PluginInstance {
    /** `<pluginId>:<tenantId>`, as the kernel mints it. */
    instanceId: string;
    /** What this instance presents on every call. It is what names the company; nothing else does. */
    instanceToken: string;
}
/** What a plugin gives back when it starts for one company. */
interface RunningPlugin {
    /** Events this company's plugin wants to act on. */
    onEvent?(event: ReceivedEvent): Promise<void> | void;
    /** Contracts it answers for this company. */
    contracts?: ServedContracts;
    /**
     * HTTP routes it answers for this company, keyed `"<METHOD> <path>"`.
     *
     * The same routes the manifest declares: declaring without serving is an address that answers 404,
     * and serving without declaring is a handler the kernel will never reach.
     */
    routes?: ServedRoutes;
    /**
     * What this company's plugin offers the interface, as it stands right now.
     *
     * A function rather than a value, because a manifest is sent whole on every announce and its content
     * changes: a page listing queues has to carry the queues that exist when it is sent, not the ones
     * that existed at boot.
     */
    manifest?(): PluginManifest;
}
interface PluginProcessOptions {
    kernelUrl: string;
    /** The deployment's credential. It grants the events of the instances hosted here, and no others. */
    credential: string;
    instances: readonly PluginInstance[];
    /**
     * Builds the plugin for one company.
     *
     * Called once per instance, with a host bound to that company: its storage, its calls and its events
     * are that company's, and the plugin has no way to reach another even by mistake.
     */
    start(host: Host, instance: PluginInstance): RunningPlugin;
    /**
     * Where each instance keeps whatever it stores on disk, given its own folder.
     *
     * A folder each, never a shared file with a company column: separating rows by remembering to filter
     * is the bet this design exists to avoid, and a folder cannot be forgotten.
     */
    dataDir?(instance: PluginInstance): string;
    onError?(error: unknown): void;
    /**
     * Injected in tests; defaults to the global.
     *
     * `FetchLike` rather than `typeof fetch` for the reason `host.ts` gives: the global type carries
     * extras nothing here calls, and demanding them refuses a perfectly good stand-in.
     */
    fetch?: FetchLike;
}
interface PluginProcess {
    /** Introduces every instance, with the manifest that instance offers. */
    introduce(manifestOf?: (instance: PluginInstance, host: Host) => PluginManifest): Promise<void>;
    /** Routes one event to the company it was addressed to. */
    handle(event: ReceivedEvent): Promise<void>;
    /** The host serving one company, for a caller that needs it directly. */
    hostOf(instanceId: string): Host | undefined;
    /** Where that instance keeps its own data. */
    dataDirOf(instanceId: string): string;
    /**
     * Sends what every instance's outbox is still holding (spec §5.1 rules 1 and 2).
     *
     * Call it from the client's `onConnected`: what is pending is pending because the kernel was
     * unreachable, so being reachable again is exactly the news that matters. Does nothing for a process
     * given no `dataDir`, which has no persistent place to keep an outbox.
     */
    flushOutboxes(): Promise<void>;
    /**
     * Opens every instance's relay stream, when the kernel offers a relay.
     *
     * One stream per instance rather than one per process, because a grant names an instance: the
     * relay decides where a delivery goes by who presented the grant, and sharing one would mean this
     * process deciding instead. Does nothing on a kernel with no relay, so calling it is always safe.
     *
     * Call it after `introduce`: the capability is learned at the handshake.
     *
     * `retryMs` is how long before the first reconnection attempt, doubling up to half a minute. The
     * default is a second, which is right for a plugin and slow for a test that kills the relay.
     */
    startRelay(options?: {
        retryMs?: number;
    }): {
        stop(): void;
        /** Whether every instance's stream is up. A test waits on it instead of guessing a delay. */
        connected(): boolean;
    };
}
declare function createPluginProcess(options: PluginProcessOptions): PluginProcess;

export { type PluginInstance as P, type ReceivedEvent as R, type SseParserOptions as S, type PluginProcess as a, type PluginProcessOptions as b, createSseParser as c, type RunningPlugin as d, createPluginProcess as e };
