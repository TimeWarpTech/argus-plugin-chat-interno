#!/usr/bin/env node

// src/cli.ts
import { createInterface } from "node:readline/promises";

// src/cli/add-screen.ts
import { readFile as readFile2, writeFile as writeFile2 } from "node:fs/promises";
import { join as join3 } from "node:path";

// src/cli/nearest.ts
import { stat } from "node:fs/promises";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";
async function nearestToThisPackage(name) {
  let directory = dirname(fileURLToPath(import.meta.url));
  for (let climbed = 0; climbed < 6; climbed += 1) {
    const candidate = join(directory, name);
    try {
      await stat(candidate);
      return candidate;
    } catch {
      const up = dirname(directory);
      if (up === directory) break;
      directory = up;
    }
  }
  throw new Error(`this package is missing ${name}, so there is nothing to write from`);
}

// src/cli/render.ts
import { mkdir, readdir, readFile, writeFile } from "node:fs/promises";
import { dirname as dirname2, join as join2, relative } from "node:path";
var TemplateUnresolved = class extends Error {
  constructor(remaining) {
    super(`a placeholder was never filled: ${remaining}`);
    this.remaining = remaining;
    this.name = "TemplateUnresolved";
  }
  remaining;
};
var PLACEHOLDER = /\{\{(\w+)\}\}/gu;
function renderTemplate(source, values) {
  const filled = source.replace(PLACEHOLDER, (whole, name) => values[name] ?? whole);
  const left = filled.indexOf("{{");
  if (left !== -1) throw new TemplateUnresolved(filled.slice(left, left + 40));
  return filled;
}
async function renderTree(from, to, values) {
  const written = [];
  const walk = async (directory) => {
    for (const entry of await readdir(directory, { withFileTypes: true })) {
      const source = join2(directory, entry.name);
      if (entry.isDirectory()) {
        await walk(source);
        continue;
      }
      const target = join2(to, relative(from, source)).replace(/\.tpl$/u, "");
      const filled = renderTemplate(await readFile(source, "utf8"), values);
      await mkdir(dirname2(target), { recursive: true });
      await writeFile(target, filled.replace(/\r\n/gu, "\n"), "utf8");
      written.push(relative(to, target));
    }
  };
  await walk(from);
  return written;
}

// src/cli/add-screen.ts
var SCREEN_FILE = join3("src", "screen.ts");
var REWRITTEN = [join3("src", "main.ts"), SCREEN_FILE];
var DEV_DEPENDENCIES = {
  "@tailwindcss/vite": "^4.3.3",
  "@types/react": "^19.3.0",
  "@vitejs/plugin-react": "^6.1.2",
  react: "^19.3.1",
  "react-dom": "^19.3.1",
  tailwindcss: "^4.3.3",
  vite: "^8.3.5"
};
async function manifestAt(path) {
  let parsed;
  try {
    parsed = JSON.parse(await readFile2(path, "utf8"));
  } catch {
    throw new Error(`${path} is not a package.json this command can read`);
  }
  if (typeof parsed !== "object" || parsed === null || Array.isArray(parsed)) {
    throw new Error(`${path} is not a package.json: its contents are not an object`);
  }
  return parsed;
}
async function refuseIfTouched(directory, values) {
  const templates = join3(await nearestToThisPackage("templates"), "default");
  const lf = (text) => text.replace(/\r\n/gu, "\n");
  for (const file of REWRITTEN) {
    const asWritten = renderTemplate(await readFile2(join3(templates, `${file}.tpl`), "utf8"), values);
    const onDisk = await readFile2(join3(directory, file), "utf8");
    if (lf(onDisk) !== lf(asWritten)) {
      throw new Error(
        `${file} has changes of your own, and this command would write over them: move them aside and run it again`
      );
    }
  }
}
async function readScreen(directory) {
  try {
    return await readFile2(join3(directory, SCREEN_FILE), "utf8");
  } catch {
    throw new Error(`${directory} is not a plugin this command made: there is no ${SCREEN_FILE} in it`);
  }
}
async function addScreen(options) {
  const { directory } = options;
  const screen = await readScreen(directory);
  if (!screen.includes("declarativeScreens")) {
    throw new Error(`${directory} already has a screen of its own, and this command will not add a second`);
  }
  const names = screenNames(screen);
  await refuseIfTouched(directory, names);
  const manifestPath = join3(directory, "package.json");
  const pkg = await manifestAt(manifestPath);
  const written = await renderTree(await nearestToThisPackage("templates/screen"), directory, names);
  await writeFile2(
    manifestPath,
    `${JSON.stringify(
      {
        ...pkg,
        scripts: {
          ...pkg.scripts,
          "build:ui": "vite build --config ui/vite.config.ts",
          // The bundle cannot be stale when the process boots, which is the whole original defect.
          prestart: "npm run build:ui"
        },
        devDependencies: { ...pkg.devDependencies, ...DEV_DEPENDENCIES }
      },
      null,
      2
    )}
`,
    "utf8"
  );
  return { written };
}
function screenNames(screen) {
  const read = (name) => {
    const found = new RegExp(`${name} = "([^"]*)"`, "u").exec(screen)?.[1];
    if (found === void 0) throw new Error(`${SCREEN_FILE} does not say what its ${name} is`);
    return found;
  };
  const title = (language) => {
    const found = new RegExp(`"?${language}"?: "([^"]*)"`, "u").exec(screen)?.[1];
    return found ?? read("PLUGIN_ID");
  };
  return {
    pluginId: read("PLUGIN_ID"),
    directory: read("SCREEN_PATH"),
    namePtBr: title("pt-BR"),
    nameEn: title("en")
  };
}

// src/cli/doctor.ts
import { readdir as readdir2, readFile as readFile3, stat as stat2 } from "node:fs/promises";
import { builtinModules } from "node:module";
import { dirname as dirname3, join as join4, relative as relative2, sep } from "node:path";
var SDK = "@creativepetabyte/argus-sdk";
var LINTERS = [
  {
    command: "biome",
    package: "@biomejs/biome",
    instead: "biome@0.3.3, an unrelated package that analyses nothing and exits 0"
  },
  { command: "eslint", package: "eslint" },
  { command: "oxlint", package: "oxlint" }
];
var RUNNERS = /* @__PURE__ */ new Set(["npx", "bunx", "pnpx", "exec", "dlx", "run", "--no-install", "--yes", "-y", "--"]);
var PACKAGE_MANAGERS = /* @__PURE__ */ new Set(["npm", "pnpm", "yarn", "bun", "node", "deno"]);
function invocations(script) {
  const found = [];
  for (const segment of script.split(/&&|\|\||[;|\n]/u)) {
    const words = segment.trim().split(/\s+/u).filter(Boolean);
    let at = 0;
    while (at < words.length && (RUNNERS.has(words[at] ?? "") || PACKAGE_MANAGERS.has(words[at] ?? ""))) at += 1;
    const word = words[at];
    if (word === void 0 || word.startsWith("-") || word.includes("=")) continue;
    found.push({ word, bare: !word.includes("/") && !word.includes("\\") });
  }
  return found;
}
function declaredRanges(manifest) {
  return {
    ...manifest.dependencies,
    ...manifest.devDependencies,
    ...manifest.peerDependencies,
    ...manifest.optionalDependencies
  };
}
function lintFindings(evidence) {
  const declared = declaredRanges(evidence.manifest);
  const findings = [];
  for (const linter of LINTERS) {
    if (declared[linter.package] !== void 0) continue;
    const scripts = Object.entries(evidence.manifest.scripts ?? {}).filter(
      ([, script]) => invocations(script).some((call) => call.bare && call.word === linter.command)
    );
    if (scripts.length === 0) continue;
    const named = scripts.map(([name]) => `"${name}"`).join(", ");
    const squatted = declared[linter.command] !== void 0;
    findings.push({
      code: "lint_without_linter",
      severity: "error",
      message: [
        `script ${named} runs \`${linter.command}\`, but ${linter.package} is not a dependency of this plugin`,
        squatted ? `the declared \`${linter.command}\` is a different package from ${linter.package}, so the script lints nothing and still exits 0 -- a lint that always passes is worse than no lint` : `a bare \`${linter.command}\` resolves to whatever the install happened to leave on the path${linter.instead === void 0 ? "" : ` -- on npm that name is ${linter.instead}`}, so this script can report success without checking anything`,
        `add ${linter.package} to devDependencies (\`npm i -D ${linter.package}\`) and keep calling it from a script, where node_modules/.bin wins`
      ].join(": ")
    });
  }
  return findings;
}
function offThisMachine(range) {
  const value = range.trim();
  if (/^(file|link|portal):/u.test(value)) return true;
  if (/^git\+file:/u.test(value)) return true;
  if (/^(\.\.?[/\\]|[/\\])/u.test(value)) return true;
  return /^[a-zA-Z]:[/\\]/u.test(value);
}
function localPathFindings(evidence) {
  const findings = [];
  for (const [name, range] of Object.entries(declaredRanges(evidence.manifest))) {
    if (!offThisMachine(range)) continue;
    findings.push({
      code: "dependency_off_this_machine",
      severity: "error",
      message: [
        `dependency ${name} is declared as \`${range}\`, which is a path on this computer`,
        "nobody else's `npm install` can resolve it and neither can CI, so the plugin builds here and nowhere else",
        `publish it, or point at a repository (\`github:owner/repo\`, \`git+https://...\`) -- for ${SDK} use a published version range`
      ].join(": ")
    });
  }
  return findings;
}
var BUILTINS = new Set(builtinModules);
var SPECIFIERS = [
  /\bfrom\s*["']([^"'\n]+)["']/gu,
  /\bimport\s*["']([^"'\n]+)["']/gu,
  /\bimport\s*\(\s*["']([^"'\n]+)["']/gu,
  /\brequire\s*\(\s*["']([^"'\n]+)["']/gu
];
var PACKAGE_NAME = /^(?:@[a-z0-9][a-z0-9-._]*\/)?[a-z0-9][a-z0-9-._]*$/u;
function packageOfSpecifier(specifier) {
  if (specifier.startsWith(".") || specifier.startsWith("/") || specifier.startsWith("#")) return void 0;
  if (/^[a-zA-Z]+:/u.test(specifier) && !specifier.startsWith("@")) return void 0;
  const parts = specifier.split("/");
  const name = specifier.startsWith("@") ? parts.slice(0, 2).join("/") : parts[0];
  if (name === void 0 || !PACKAGE_NAME.test(name)) return void 0;
  return BUILTINS.has(name) ? void 0 : name;
}
function importedPackages(sources) {
  const first = /* @__PURE__ */ new Map();
  for (const source of sources) {
    for (const pattern of SPECIFIERS) {
      for (const match of source.text.matchAll(pattern)) {
        const name = packageOfSpecifier(match[1] ?? "");
        if (name !== void 0 && !first.has(name)) first.set(name, source.path);
      }
    }
  }
  return first;
}
function undeclaredFindings(evidence) {
  const declared = new Set(Object.keys(declaredRanges(evidence.manifest)));
  const findings = [];
  for (const [name, path] of importedPackages(evidence.sources)) {
    if (declared.has(name) || name === evidence.manifest.name) continue;
    const installed = evidence.installed[name];
    findings.push({
      code: "undeclared_dependency",
      severity: "error",
      message: [
        `${path} imports ${name}, which this plugin's package.json does not declare`,
        installed === void 0 ? "it is not installed here either, so the import fails as soon as anyone runs it" : installed.own ? "it resolves today only because something else installed it, and it disappears the moment that something else stops" : `it resolves only from a parent node_modules (version ${installed.version}), which is nothing this plugin controls -- the day that parent changes, the import stops working with no change here`,
        `declare it: \`npm i ${name}\`, or \`npm i -D ${name}\` when only tests and the build use it`
      ].join(": ")
    });
  }
  return findings;
}
function reactFindings(evidence) {
  if (evidence.reactCopies.length < 2) return [];
  return [
    {
      code: "react_twice",
      severity: "error",
      message: [
        `React is installed ${evidence.reactCopies.length} times in this tree (${evidence.reactCopies.join(", ")})`,
        "a screen rendered by one copy and hooks taken from the other read a null dispatcher, which fails at runtime with a message that blames the component",
        "keep one: declare `react` once in this plugin and let everything else take it as a peer dependency (`npm ls react` shows who asked for the other)"
      ].join(": ")
    }
  ];
}
function floorOf(range) {
  const match = /(\d+)\.(\d+)\.(\d+)/u.exec(range);
  if (match === null) return void 0;
  return [Number(match[1]), Number(match[2]), Number(match[3])];
}
function behind(mine, theirs) {
  return mine[0] < theirs[0] || mine[0] === theirs[0] && mine[1] < theirs[1];
}
function sdkFindings(evidence) {
  const range = declaredRanges(evidence.manifest)[SDK];
  if (range === void 0 || offThisMachine(range)) return [];
  const mine = floorOf(range);
  const known = evidence.latestSdkVersion ?? evidence.runningSdkVersion;
  const theirs = floorOf(known);
  if (mine === void 0 || theirs === void 0 || !behind(mine, theirs)) return [];
  const installed = evidence.installed[SDK];
  return [
    {
      code: "sdk_behind",
      severity: "note",
      message: [
        `${SDK} is declared as \`${range}\`${installed === void 0 ? "" : ` and installed at ${installed.version}`}, while ${evidence.latestSdkVersion === void 0 ? `the SDK running this check is ${known}` : `the published version is ${known}`}`,
        "a plugin that old is missing capabilities the kernel already offers, and the host it talks to has moved on",
        `raise the range and install: \`npm i ${SDK}@^${known}\`, then run your tests -- the SDK's README lists what changed`
      ].join(": ")
    }
  ];
}
var EFFECTS = ["audio", "video", "capture", "realtime"];
var BACKGROUND = /\bbackground\s*:\s*\[([^\]]*)\]/gu;
var DISPOSE = /\bexport\s+(?:async\s+)?(?:function|const|let|var)\s+dispose\b|\bexport\s*\{[^}]*\bdispose\b/u;
function backgroundFindings(evidence) {
  const declared = /* @__PURE__ */ new Map();
  for (const source of evidence.sources) {
    for (const match of source.text.matchAll(BACKGROUND)) {
      const effects2 = (match[1] ?? "").split(",").map((piece) => piece.trim().replace(/^["'`]|["'`]$/gu, "")).filter(Boolean);
      if (effects2.length === 0) continue;
      if (!effects2.every((effect) => EFFECTS.includes(effect))) continue;
      declared.set(source.path, effects2);
    }
  }
  if (declared.size === 0) return [];
  if (evidence.sources.some((source) => DISPOSE.test(source.text))) return [];
  const [path, effects] = [...declared][0] ?? ["", []];
  return [
    {
      code: "background_without_dispose",
      severity: "error",
      message: [
        `${path} declares background ${effects.map((effect) => `\`${effect}\``).join(", ")}, and no file here exports \`dispose\``,
        "calling the bundle's `dispose` is the only way the shell can end those effects, so without it they keep running after the screen is gone -- audio that will not stop, a capture nobody closed",
        "export `dispose` from the bundle's entry (`export function dispose() { ... }`) and stop in it everything the background started"
      ].join(": ")
    }
  ];
}
function endOfExpression(text, start) {
  const pairs = { "(": ")", "[": "]", "{": "}" };
  const stack = [];
  let quote;
  for (let at = start; at < text.length; at += 1) {
    const character = text[at] ?? "";
    if (quote !== void 0) {
      if (character === "\\") at += 1;
      else if (character === quote) quote = void 0;
      continue;
    }
    if (character === '"' || character === "'" || character === "`") {
      quote = character;
      continue;
    }
    if (pairs[character] !== void 0) {
      stack.push(pairs[character] ?? "");
      continue;
    }
    if (stack.length > 0) {
      if (character === stack[stack.length - 1]) stack.pop();
      continue;
    }
    if (character === "," || character === "}" || character === ";" || character === "\n") return at;
  }
  return text.length;
}
function valueAfter(text, key) {
  const at = new RegExp(`(?:^|[^\\w$.])${key}\\s*:`, "u").exec(text);
  if (at === null) return void 0;
  const from = at.index + at[0].length;
  let start = from;
  while (start < text.length && /\s/u.test(text[start] ?? "")) start += 1;
  return text.slice(start, endOfExpression(text, start)).trim();
}
function itemsOf(raw) {
  const value = raw.trim();
  if (!value.startsWith("[") && !value.startsWith("{")) return [];
  const inner = value.slice(1, -1);
  const items = [];
  let at = 0;
  while (at < inner.length) {
    while (at < inner.length && /[\s,]/u.test(inner[at] ?? "")) at += 1;
    if (at >= inner.length) break;
    const end = endOfExpression(inner, at);
    const item = inner.slice(at, end).trim();
    if (item !== "") items.push(item);
    at = end + 1;
  }
  return items;
}
var STRING_CONSTANT = /\bconst\s+([A-Za-z_$][\w$]*)\s*=\s*(?:"([^"\\\n]*)"|'([^'\\\n]*)'|`([^`$\\\n]*)`)\s*[;\n]/gu;
function constantsOf(sources) {
  const table = /* @__PURE__ */ new Map();
  for (const source of sources) {
    for (const match of source.text.matchAll(STRING_CONSTANT)) {
      const name = match[1] ?? "";
      const value = match[2] ?? match[3] ?? match[4] ?? "";
      if (!table.has(name)) table.set(name, value);
    }
  }
  return table;
}
function declaredOf(raw, constants) {
  const value = raw.trim();
  const literal = /^(["'`])([^"'`]*)\1$/u.exec(value);
  if (literal !== null) return { text: literal[2] ?? "", resolved: true };
  const named = constants.get(value);
  if (named !== void 0) return { text: named, resolved: true };
  return { text: value, resolved: false };
}
function declaredList(raw, constants) {
  return raw === void 0 ? [] : itemsOf(raw).map((item) => declaredOf(item, constants));
}
function objectList(raw) {
  return raw === void 0 ? [] : itemsOf(raw).filter((item) => item.startsWith("{"));
}
var EXPORTED = [
  /\bexport\s+(?:async\s+)?(?:function|const|let|var|class)\s+([A-Za-z_$][\w$]*)/gu,
  /\bexport\s+default\s+(?:async\s+)?(?:function|class)\s+([A-Za-z_$][\w$]*)/gu
];
function exportedNames(sources) {
  const names = /* @__PURE__ */ new Set();
  for (const source of sources) {
    for (const pattern of EXPORTED) {
      for (const match of source.text.matchAll(pattern)) names.add(match[1] ?? "");
    }
    for (const match of source.text.matchAll(/\bexport\s*\{([^}]*)\}/gu)) {
      for (const piece of (match[1] ?? "").split(",")) {
        const parts = piece.trim().split(/\s+as\s+/u);
        const name = (parts[parts.length - 1] ?? "").trim();
        if (/^[A-Za-z_$][\w$]*$/u.test(name)) names.add(name);
      }
    }
  }
  return names;
}
function methodKeys(sources) {
  const keys = /* @__PURE__ */ new Set();
  for (const source of sources) {
    for (const match of source.text.matchAll(/(?:^|[\s{,])([A-Z][A-Za-z0-9_]*)\s*:/gmu)) keys.add(match[1] ?? "");
  }
  return keys;
}
var MANIFEST = /\bmanifest\s*[:=]\s*\{/u;
var BLOCK_CONSTANT = /\bconst\s+([A-Za-z_$][\w$]*)\s*=\s*(?=[{[]|[A-Za-z_$][\w$]*\s*\()/gu;
function expandSpreads(block, sources) {
  const blocks = /* @__PURE__ */ new Map();
  for (const source of sources) {
    for (const match of source.text.matchAll(BLOCK_CONSTANT)) {
      const name = match[1] ?? "";
      const start = match.index + match[0].length;
      if (!blocks.has(name)) blocks.set(name, source.text.slice(start, endOfExpression(source.text, start)));
    }
  }
  let text = block;
  for (let round = 0; round < 2; round += 1) {
    const found = [...text.matchAll(/\.\.\.([A-Za-z_$][\w$]*)/gu)].map((match) => blocks.get(match[1] ?? "")).filter((value) => value !== void 0);
    if (found.length === 0) break;
    text = `${text}
${found.join("\n")}`;
  }
  return text;
}
function inventoryOf(evidence) {
  const constants = constantsOf(evidence.sources);
  const disposeExported = evidence.sources.some((source) => DISPOSE.test(source.text));
  const empty = {
    serves: [],
    requires: [],
    consumes: [],
    emits: [],
    pages: [],
    slots: [],
    scopes: [],
    slotHelpers: [],
    scopeHelpers: [],
    automation: { methods: [] },
    ui: {},
    background: [],
    disposeExported,
    found: false
  };
  const holder = evidence.sources.find((source) => MANIFEST.test(source.text));
  if (holder === void 0) return empty;
  const at = MANIFEST.exec(holder.text);
  const start = (at?.index ?? 0) + (at?.[0].length ?? 0) - 1;
  const block = expandSpreads(holder.text.slice(start, endOfExpression(holder.text, start) + 1), evidence.sources);
  const serves = [
    ...declaredList(valueAfter(block, "serves"), constants),
    ...declaredList(valueAfter(block, "provides"), constants)
  ];
  const read = (item, key) => {
    const raw = valueAfter(item, key);
    return raw === void 0 ? void 0 : declaredOf(raw, constants);
  };
  const pages = objectList(valueAfter(block, "pages")).map((item) => {
    const path = read(item, "path");
    const component = read(item, "component");
    const url2 = read(item, "url");
    return {
      ...path === void 0 ? {} : { path },
      ...component === void 0 ? {} : { component },
      ...url2 === void 0 ? {} : { url: url2 }
    };
  });
  const slots = objectList(valueAfter(block, "slots")).map((item) => {
    const slot = read(item, "slot");
    const component = read(item, "component");
    return { ...slot === void 0 ? {} : { slot }, ...component === void 0 ? {} : { component } };
  });
  const scopeItems = itemsOf(valueAfter(block, "requestedScopes") ?? "");
  const scopes = scopeItems.filter((item) => item.startsWith("{") && valueAfter(item, "name") !== void 0).map((item) => {
    const essential = valueAfter(item, "essential");
    const description = read(item, "description");
    return {
      name: read(item, "name") ?? { text: "", resolved: false },
      ...description === void 0 ? {} : { description },
      ...essential === void 0 ? {} : { essential: essential === "true" }
    };
  });
  const helpersIn = (items) => items.filter((item) => /^[A-Za-z_$][\w$.]*\s*\(/u.test(item)).map((item) => `${/^[A-Za-z_$][\w$.]*/u.exec(item)?.[0] ?? ""}()`);
  const slotHelpers = helpersIn(itemsOf(valueAfter(block, "slots") ?? ""));
  const scopeHelpers = scopeItems.filter((item) => /^[A-Za-z_$][\w$.]*\s*\(/u.test(item)).map((item) => `${/^[A-Za-z_$][\w$.]*/u.exec(item)?.[0] ?? ""}()`);
  const background = declaredList(valueAfter(block, "background"), constants).filter((effect) => effect.resolved).map((effect) => effect.text);
  const uiBlock = valueAfter(block, "ui") ?? block;
  const url = read(uiBlock, "url");
  const hosted = evidence.sources.map((source) => valueAfter(source.text, "hostedBundle")).find((value) => value !== void 0);
  const file = hosted === void 0 ? void 0 : read(hosted, "file");
  const automationContract = serves.find((name) => name.resolved && name.text.endsWith(".AutomationNodesService"));
  const methods = [
    ...new Set(
      evidence.sources.flatMap(
        (source) => [...source.text.matchAll(/\bmethod\s*:\s*["']([A-Za-z0-9_]+)["']/gu)].map((match) => match[1] ?? "")
      )
    )
  ];
  return {
    serves,
    requires: objectList(valueAfter(block, "requires")).map((item) => ({
      contract: read(item, "contract") ?? { text: "", resolved: false },
      essential: valueAfter(item, "essential") === void 0 ? void 0 : valueAfter(item, "essential") === "true"
    })),
    consumes: declaredList(valueAfter(block, "consumes"), constants),
    emits: declaredList(valueAfter(block, "emits"), constants),
    pages,
    slots,
    scopes,
    slotHelpers,
    scopeHelpers,
    automation: {
      ...automationContract === void 0 ? {} : { contract: automationContract },
      methods: automationContract === void 0 ? [] : methods
    },
    ui: {
      ...url === void 0 || url.text === "" ? {} : { url },
      ...file === void 0 || file.text === "" ? {} : { bundleFile: file.text, bundleExists: evidence.builtFiles.includes(file.text) }
    },
    background,
    disposeExported,
    found: true
  };
}
function inventoryLines(inventory) {
  if (!inventory.found) return ["  (no `manifest` found in these sources, so there is nothing to list)"];
  const show = (declared) => declared.resolved ? declared.text : `${declared.text} (unresolved)`;
  const lines = [];
  const row = (label, values) => {
    if (values.length > 0) lines.push(`  ${label.padEnd(12)} ${values.join(", ")}`);
  };
  row("serves", inventory.serves.map(show));
  row(
    "requires",
    inventory.requires.map(
      (required) => `${show(required.contract)}${required.essential === true ? " (essential)" : " (optional)"}`
    )
  );
  row("emits", inventory.emits.map(show));
  row("reads", inventory.consumes.map(show));
  row(
    "pages",
    inventory.pages.map((page) => {
      const where = page.path === void 0 ? "?" : show(page.path);
      return `${where} -> ${page.component === void 0 ? "declarative content" : show(page.component)}`;
    })
  );
  row("slots", [
    ...inventory.slots.map((slot) => {
      const where = slot.slot === void 0 ? "?" : show(slot.slot);
      return `${where} -> ${slot.component === void 0 ? "declarative content" : show(slot.component)}`;
    }),
    ...inventory.slotHelpers
  ]);
  row("scopes", [
    ...inventory.scopes.map(
      (scope) => `${show(scope.name)}${scope.description === void 0 ? "" : ` (${show(scope.description)})`}`
    ),
    ...inventory.scopeHelpers
  ]);
  if (inventory.automation.contract !== void 0) {
    row("automation", [show(inventory.automation.contract)]);
    row("nodes", inventory.automation.methods);
  }
  const bundle = [
    ...inventory.ui.url === void 0 ? [] : [show(inventory.ui.url)],
    ...inventory.ui.bundleFile === void 0 ? [] : [
      `${inventory.ui.bundleFile} ${inventory.ui.bundleExists ? "(built)" : "(NOT BUILT -- build it before starting)"}`
    ]
  ];
  row("ui bundle", bundle.length === 0 ? ["none declared"] : bundle);
  row(
    "background",
    inventory.background.length === 0 ? ["none declared"] : [...inventory.background, inventory.disposeExported ? "dispose exported" : "dispose MISSING"]
  );
  return lines;
}
function incoherenceFindings(evidence, inventory) {
  const findings = [];
  const constants = constantsOf(evidence.sources);
  const declared = new Set(inventory.emits.filter((event) => event.resolved).map((event) => event.text));
  const unreadable = inventory.emits.some((event) => !event.resolved);
  const emitted = /* @__PURE__ */ new Map();
  let dynamic = false;
  for (const source of evidence.sources) {
    for (const match of source.text.matchAll(/\bemit\s*\(\s*([^,)]+)/gu)) {
      const read = declaredOf((match[1] ?? "").trim(), constants);
      if (!read.resolved) dynamic = true;
      else if (!emitted.has(read.text)) emitted.set(read.text, source.path);
    }
  }
  if (!unreadable) {
    for (const [type, path] of emitted) {
      if (declared.has(type)) continue;
      findings.push({
        code: "emit_not_declared",
        severity: "error",
        message: [
          `${path} emits "${type}", which this plugin's manifest does not list in \`emits\``,
          "the kernel refuses an event type a plugin never declared, so this one is dropped at runtime and whoever subscribed waits for something that never arrives",
          `add "${type}" to \`emits\` in the manifest`
        ].join(": ")
      });
    }
  }
  if (!dynamic && emitted.size > 0) {
    for (const event of inventory.emits) {
      if (!event.resolved || emitted.has(event.text)) continue;
      findings.push({
        code: "event_declared_never_emitted",
        severity: "note",
        message: [
          `the manifest declares the event "${event.text}" and no code here emits it`,
          "a company approving this plugin is asked to allow an event that never happens, and anybody who subscribes waits forever",
          "emit it, or drop it from `emits`"
        ].join(": ")
      });
    }
  }
  const exported = exportedNames(evidence.sources);
  const named = [
    ...inventory.pages.map((page) => ({ where: "page", component: page.component })),
    ...inventory.slots.map((slot) => ({ where: "slot", component: slot.component }))
  ];
  for (const entry of named) {
    const component = entry.component;
    if (component === void 0 || !component.resolved || exported.has(component.text)) continue;
    findings.push({
      code: "component_not_exported",
      severity: "error",
      message: [
        `the manifest's ${entry.where} names the component "${component.text}", and nothing in this plugin exports that name`,
        "the shell looks the name up in the bundle's exports and finds nothing, so the screen comes up empty with an error only the browser console sees",
        `export it from the bundle's entry (\`export function ${component.text}() { ... }\`), or correct the name in the manifest`
      ].join(": ")
    });
  }
  if (inventory.automation.contract !== void 0) {
    const keys = methodKeys(evidence.sources);
    for (const method of inventory.automation.methods) {
      if (keys.has(method)) continue;
      findings.push({
        code: "automation_method_missing",
        severity: "error",
        message: [
          `an automation node declares \`method: "${method}"\`, and no contract method of that name is implemented here`,
          "the editor lists the node because the catalogue is announced, and the run refuses it the first time somebody uses it -- a failure that arrives weeks later, inside somebody else's automation",
          `implement \`${method}\` in the contract this plugin serves, or correct the node's \`method\``
        ].join(": ")
      });
    }
  }
  return findings;
}
function inspectPlugin(evidence) {
  return [
    ...lintFindings(evidence),
    ...localPathFindings(evidence),
    ...undeclaredFindings(evidence),
    ...reactFindings(evidence),
    ...backgroundFindings(evidence),
    ...incoherenceFindings(evidence, inventoryOf(evidence)),
    ...sdkFindings(evidence)
  ];
}
function reportOf(findings) {
  if (findings.length === 0) return { lines: ["doctor: nothing to report \u2014 this plugin's setup looks sound"], code: 0 };
  const lines = findings.map((finding) => `${finding.severity} [${finding.code}] ${finding.message}`);
  const errors = findings.filter((finding) => finding.severity === "error").length;
  const notes = findings.length - errors;
  lines.push(`doctor: ${errors} error(s), ${notes} note(s)`);
  return { lines, code: errors > 0 ? 1 : 0 };
}
var SKIPPED = /* @__PURE__ */ new Set(["node_modules", ".git", "dist", "build", "coverage", "drizzle", "data", ".logs", ".cache"]);
var SOURCE = /\.(?:[cm]?tsx?|[cm]?jsx?)$/u;
var MAX_SOURCES = 2e3;
async function readJson(path) {
  try {
    const parsed = JSON.parse(await readFile3(path, "utf8"));
    if (typeof parsed !== "object" || parsed === null || Array.isArray(parsed)) return void 0;
    return parsed;
  } catch {
    return void 0;
  }
}
async function pluginRoot(from) {
  let directory = from;
  for (; ; ) {
    try {
      await stat2(join4(directory, "package.json"));
      return directory;
    } catch {
      const up = dirname3(directory);
      if (up === directory) break;
      directory = up;
    }
  }
  throw new Error(`no package.json at or above ${from}, so there is no plugin here to look at`);
}
async function sourcesUnder(root) {
  const found = [];
  const walk = async (directory) => {
    if (found.length >= MAX_SOURCES) return;
    let entries;
    try {
      entries = await readdir2(directory, { withFileTypes: true });
    } catch {
      return;
    }
    for (const entry of entries) {
      if (found.length >= MAX_SOURCES) return;
      const path = join4(directory, entry.name);
      if (entry.isDirectory()) {
        if (!SKIPPED.has(entry.name) && !entry.name.startsWith(".")) await walk(path);
        continue;
      }
      if (!SOURCE.test(entry.name)) continue;
      try {
        found.push({ path: relative2(root, path).split(sep).join("/"), text: await readFile3(path, "utf8") });
      } catch {
      }
    }
  };
  await walk(root);
  return found.sort((a, b) => a.path.localeCompare(b.path));
}
async function builtFilesUnder(root) {
  const found = [];
  const walk = async (at) => {
    let entries;
    try {
      entries = await readdir2(at, { withFileTypes: true });
    } catch {
      return;
    }
    for (const entry of entries) {
      if (found.length >= 500) return;
      const path = join4(at, entry.name);
      if (entry.isDirectory()) await walk(path);
      else found.push(relative2(root, path).split(sep).join("/"));
    }
  };
  for (const directory of ["dist", join4("ui", "dist"), "build"]) await walk(join4(root, directory));
  return found;
}
async function installedVersion(root, name) {
  let directory = root;
  for (let climbed = 0; climbed < 12; climbed += 1) {
    const manifest = await readJson(join4(directory, "node_modules", ...name.split("/"), "package.json"));
    const version = manifest?.["version"];
    if (typeof version === "string") return { version, own: directory === root };
    const up = dirname3(directory);
    if (up === directory) break;
    directory = up;
  }
  return void 0;
}
async function reactCopies(root) {
  const modules = join4(root, "node_modules");
  const found = [];
  const check = async (at) => {
    const manifest = await readJson(join4(at, "package.json"));
    if (typeof manifest?.["version"] === "string") found.push(relative2(root, at).split(sep).join("/"));
  };
  await check(join4(modules, "react"));
  let entries;
  try {
    entries = await readdir2(modules, { withFileTypes: true });
  } catch {
    return found;
  }
  for (const entry of entries) {
    if (!entry.isDirectory() || entry.name === ".bin") continue;
    const inner = entry.name.startsWith("@") ? (await readdir2(join4(modules, entry.name), { withFileTypes: true }).catch(() => [])).map(
      (scoped) => join4(modules, entry.name, scoped.name)
    ) : [join4(modules, entry.name)];
    for (const dependency of inner) await check(join4(dependency, "node_modules", "react"));
  }
  return found;
}
async function publishedSdkVersion() {
  try {
    const response = await fetch(`https://registry.npmjs.org/${encodeURIComponent(SDK)}/latest`, {
      signal: AbortSignal.timeout(2e3),
      headers: { accept: "application/json" }
    });
    if (!response.ok) return void 0;
    const body = await response.json();
    if (typeof body !== "object" || body === null) return void 0;
    const version = body["version"];
    return typeof version === "string" ? version : void 0;
  } catch {
    return void 0;
  }
}
async function ownVersion() {
  try {
    const manifest = await readJson(await nearestToThisPackage("package.json"));
    const version = manifest?.["version"];
    return typeof version === "string" ? version : "0.0.0";
  } catch {
    return "0.0.0";
  }
}
async function readEvidence(options) {
  const root = await pluginRoot(options.from);
  const manifest = await readJson(join4(root, "package.json"));
  if (manifest === void 0) throw new Error(`${join4(root, "package.json")} is not a package.json this can read`);
  const sources = await sourcesUnder(root);
  const wanted = /* @__PURE__ */ new Set([
    ...Object.keys(declaredRanges(manifest)),
    ...importedPackages(sources).keys(),
    SDK
  ]);
  const installed = {};
  for (const name of wanted) {
    const version = await installedVersion(root, name);
    if (version !== void 0) installed[name] = version;
  }
  const latest = options.online ? await publishedSdkVersion() : void 0;
  return {
    root,
    manifest,
    runningSdkVersion: options.runningSdkVersion ?? await ownVersion(),
    ...latest === void 0 ? {} : { latestSdkVersion: latest },
    installed,
    reactCopies: await reactCopies(root),
    sources,
    builtFiles: await builtFilesUnder(root)
  };
}
async function doctor(options) {
  const evidence = await readEvidence(options);
  const report = reportOf(inspectPlugin(evidence));
  return {
    lines: [
      `doctor: looking at ${evidence.root}`,
      "",
      `what ${evidence.manifest.name ?? "this plugin"} declares:`,
      ...inventoryLines(inventoryOf(evidence)),
      "",
      ...report.lines
    ],
    code: report.code
  };
}

// src/cli/init.ts
import { readdir as readdir3, readFile as readFile4 } from "node:fs/promises";
import { join as join5 } from "node:path";
var PLUGIN_ID = /^[a-z0-9](?:[a-z0-9]|[._-](?=[a-z0-9]))*$/u;
var MAX_ID_LENGTH = 100;
function isPluginId(value) {
  return value.length > 0 && value.length <= MAX_ID_LENGTH && PLUGIN_ID.test(value);
}
var UNWRITABLE = /* @__PURE__ */ new Set([
  34,
  // a double quote, which would close the string it is written into
  92,
  // a backslash, which would escape whatever followed it
  10,
  // a line feed
  13
  // a carriage return
]);
function readableName(value, language) {
  const name = value.trim();
  if (name === "") throw new Error(`the name in ${language}: nothing was given`);
  if ([...name].some((character) => UNWRITABLE.has(character.codePointAt(0) ?? 0))) {
    throw new Error(`the name in ${language}: a quote, a backslash or a line break cannot be in it`);
  }
  return name;
}
async function sdkVersion() {
  const manifest = JSON.parse(await readFile4(await nearestToThisPackage("package.json"), "utf8"));
  const version = manifest.version;
  if (typeof version !== "string") throw new Error("this package has no version to pin");
  return version;
}
async function askUntilValid(ask2, question, valid) {
  const answer = await ask2(question).then(
    (given) => given.trim(),
    (error) => {
      const reason = error instanceof Error ? error.message : String(error);
      throw new Error(`${question}: nothing was given and there was nobody to ask (${reason})`);
    }
  );
  if (!valid(answer)) throw new Error(`${question}: ${answer === "" ? "nothing was given" : answer} is not one`);
  return answer;
}
async function isEmptyOrAbsent(directory) {
  try {
    return (await readdir3(directory)).length === 0;
  } catch {
    return true;
  }
}
async function init(options) {
  const id = options.id ?? await askUntilValid(options.ask, "plugin id", isPluginId);
  if (!isPluginId(id)) {
    throw new Error(`plugin id: ${id === "" ? "nothing was given" : id} is not one`);
  }
  const given = options.name ?? {
    "pt-BR": await askUntilValid(options.ask, "name in pt-BR", (answer) => answer !== ""),
    en: await askUntilValid(options.ask, "name in en", (answer) => answer !== "")
  };
  const name = {
    "pt-BR": readableName(given["pt-BR"], "pt-BR"),
    en: readableName(given.en, "en")
  };
  const page = id.replaceAll(".", "-");
  const folder = options.directory ?? page;
  const directory = join5(options.into, folder);
  if (!await isEmptyOrAbsent(directory)) {
    throw new Error(`${folder} already has files in it, and this command will not write over them`);
  }
  await renderTree(join5(await nearestToThisPackage("templates"), "default"), directory, {
    pluginId: id,
    directory: page,
    folder,
    namePtBr: name["pt-BR"],
    nameEn: name.en,
    sdkVersion: await sdkVersion()
  });
  return {
    directory,
    next: `cd ${folder} && npm install && PLUGIN_CONNECTION_TOKEN=... npm start`
  };
}

// src/cli/command.ts
var USAGE = `argus-plugin <command>

  init [id] [directory]   write a new plugin that connects and draws
    --name-pt <name>      the name end users read, in pt-BR
    --name-en <name>      the same name in en
  add-screen [directory]  give that plugin a screen of its own, hosted by the kernel
  doctor [directory]      say what is wrong with this plugin's setup
    --online              also ask the registry which SDK version is published

Without --name-pt and --name-en the command asks for them, which needs a terminal.`;
var FLAGS = ["--name-pt", "--name-en"];
var SWITCHES = ["--online"];
function parse(argv) {
  const positional = [];
  const flags = /* @__PURE__ */ new Map();
  for (let at = 0; at < argv.length; at += 1) {
    const argument = argv[at] ?? "";
    if (!argument.startsWith("--")) {
      positional.push(argument);
      continue;
    }
    if (SWITCHES.includes(argument)) {
      flags.set(argument, "");
      continue;
    }
    if (!FLAGS.includes(argument)) return { positional, flags, unknown: argument };
    const value = argv[at + 1];
    if (value === void 0 || value.startsWith("--")) return { positional, flags, unknown: argument };
    flags.set(argument, value);
    at += 1;
  }
  return { positional, flags };
}
function nameFrom(flags) {
  const pt = flags.get("--name-pt");
  const en = flags.get("--name-en");
  return pt === void 0 || en === void 0 ? void 0 : { "pt-BR": pt, en };
}
async function runCommand(argv, io) {
  const [command, ...rest] = argv;
  if (command === "--help" || command === "-h") {
    io.write(USAGE);
    return 0;
  }
  const read = parse(rest);
  if (read.unknown !== void 0) {
    io.fail(`argus-plugin: ${read.unknown} is not a flag this command has

${USAGE}`);
    return 1;
  }
  if (command === "doctor") {
    const [directory2] = read.positional;
    try {
      const report = await doctor({
        from: directory2 ?? io.into,
        online: read.flags.has("--online")
      });
      for (const line of report.lines) (report.code === 0 ? io.write : io.fail)(line);
      return report.code;
    } catch (error) {
      io.fail(`argus-plugin: ${error instanceof Error ? error.message : String(error)}`);
      return 1;
    }
  }
  if (command === "add-screen") {
    const [directory2] = read.positional;
    try {
      const { written } = await addScreen({ directory: directory2 ?? io.into });
      for (const file of written) io.write(`written: ${file}`);
      io.write("next: npm install && npm start \u2014 `prestart` builds the bundle, `build:ui` on its own rebuilds it");
      return 0;
    } catch (error) {
      io.fail(`argus-plugin: ${error instanceof Error ? error.message : String(error)}`);
      return 1;
    }
  }
  if (command !== "init") {
    io.fail(command === void 0 ? USAGE : `argus-plugin: there is no command called ${command}

${USAGE}`);
    return 1;
  }
  const [id, directory] = read.positional;
  const name = nameFrom(read.flags);
  try {
    const written = await init({
      ...id === void 0 ? {} : { id },
      ...directory === void 0 ? {} : { directory },
      ...name === void 0 ? {} : { name },
      ask: io.ask,
      into: io.into
    });
    io.write(`written: ${written.directory}`);
    io.write(`next: ${written.next}`);
    return 0;
  } catch (error) {
    io.fail(`argus-plugin: ${error instanceof Error ? error.message : String(error)}`);
    return 1;
  }
}

// src/cli.ts
var ask = process.stdin.isTTY ? async (question) => {
  const reader = createInterface({ input: process.stdin, output: process.stdout });
  try {
    return await reader.question(`${question}: `);
  } finally {
    reader.close();
  }
} : () => Promise.reject(new Error("stdin is not a terminal, so pass --name-pt and --name-en"));
process.exitCode = await runCommand(process.argv.slice(2), {
  into: process.cwd(),
  write: (line) => process.stdout.write(`${line}
`),
  fail: (line) => process.stderr.write(`${line}
`),
  ask
});
//# sourceMappingURL=cli.js.map