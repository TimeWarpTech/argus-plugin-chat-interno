import { z } from 'zod';

declare const DirectoryMember: z.ZodObject<{
    userId: z.ZodString;
    name: z.ZodString;
    role: z.ZodEnum<{
        owner: "owner";
        admin: "admin";
        agent: "agent";
    }>;
}, z.core.$strip>;
type DirectoryMember = z.infer<typeof DirectoryMember>;

declare const PublishNotification: z.ZodObject<{
    key: z.ZodString;
    recipients: z.ZodArray<z.ZodUUID>;
    title: z.ZodObject<{
        "pt-BR": z.ZodString;
        en: z.ZodString;
    }, z.core.$strict>;
    body: z.ZodDefault<z.ZodString>;
    page: z.ZodString;
    query: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodString>>;
}, z.core.$strict>;
type PublishNotification = z.input<typeof PublishNotification>;
declare const PublishNotificationResult: z.ZodObject<{
    created: z.ZodNumber;
    ids: z.ZodArray<z.ZodUUID>;
}, z.core.$strip>;
type PublishNotificationResult = z.infer<typeof PublishNotificationResult>;

/**
 * A plugin's scopes are not constants: their names carry the plugin's own id, so they can only be
 * built. These three functions are the only place that builds them.
 *
 * They were template strings spread across the kernel -- `${pluginId}.events:read` in the relay,
 * `${contract}:call` in the RPC path. A typo in one of those is worse than a broken test: a guard
 * that never matches is a guard that never refuses.
 */
/** Hearing an owner's events. Checked at delivery, which is where the kernel knows who owns one. */
declare function eventsReadScope(owner: string): string;
/**
 * Emitting one's own events. Symmetrical with reading, and the reason a disabled instance -- whose
 * effective scopes are empty -- stops emitting at once instead of emitting into a stream nobody may
 * read.
 */
declare function eventsEmitScope(owner: string): string;
/** Calling somebody else's contract. */
declare function contractCallScope(contract: string): string;
/**
 * What a plugin can go on doing after its screen is gone, named by what a person would notice.
 *
 * Effects, not a lifecycle: the bundle is loaded on every page regardless, so "keep me loaded" would
 * promise something that is already true and ask the company to approve nothing. What a company can
 * meaningfully refuse is the sound, the camera, the screen capture or the open connection.
 *
 * Here rather than in the plugin SDK, with the SDK re-exporting, because every OTHER scope name is
 * built here and the SDK already imports those to wrap them in a `RequestedScope`. The kernel has to
 * decide these scopes and the shell has to explain them, and neither of those may import the plugin
 * SDK into production code to learn the name of a permission.
 */
declare const BACKGROUND_EFFECTS: readonly ["audio", "video", "capture", "realtime"];
type BackgroundEffect = (typeof BACKGROUND_EFFECTS)[number];
/** The scope name for one effect, so no call site spells `shell.background.*` by hand. */
declare function backgroundScope(effect: BackgroundEffect): string;

/**
 * What this SDK actually uses of `fetch`: a URL, an init, a response.
 *
 * Narrower than `typeof fetch` on purpose -- the global type carries extras (`preconnect`) that
 * nothing here calls, and demanding them would refuse a perfectly good stand-in, in a test or behind
 * a proxy.
 *
 * On its own, importing nothing, because everything that talks over the network needs it and a home
 * inside any one of them would make the others import that one.
 */
type FetchLike = (url: string, init: RequestInit) => Promise<Response>;

/**
 * How long an artefact is meant to last. Named, not a number of days.
 *
 * `durable` lives as long as the plugin that stored it: an interface bundle is this. `temporary`
 * expires on its own, which is what a half-finished upload or a generated export wants — nobody has
 * to remember to delete it, and forgetting is how a store fills up.
 */
type ArtefactZone = "temporary" | "durable";
/** Written out so a wrong zone is a type error at the call site and a refusal on the wire. */
declare const ARTEFACT_ZONES: readonly ArtefactZone[];
interface ArtefactToStore {
    bytes: Uint8Array;
    /**
     * What the bytes are, as the plugin understands them.
     *
     * A PROPOSAL, never a header: the kernel serves from a closed list of types it is willing to hand
     * a browser and refuses anything else. A plugin that could name the type of what the product's own
     * origin serves would have authority over that origin.
     */
    contentType: string;
    /** Defaults to `durable`, which is what a bundle is. */
    zone?: ArtefactZone;
    /**
     * The id of the event this artefact travels with. For `temporary` it makes the artefact that
     * emission's own, so another emission of identical bytes cannot share it and be broken when this
     * one is forgotten. A resend of the same event passes the same id and uploads nothing. Ignored in
     * `durable`, where the address is the content.
     */
    emission?: string;
}
/** Where the artefact now is, and the hash whoever loads it will check it against. */
interface StoredArtefact {
    url: string;
    integrity: string;
}
/** What this SDK says when the kernel has no artefact store at all. Matched, so it is written once. */
declare const NO_ARTEFACT_STORE = "this kernel has no artefact store";
/** The hash in the format `integrity` is written in, which is what the browser will enforce. */
declare const integrityOf: (bytes: Uint8Array) => string;

/** Client-side cancellation stops waiting; it cannot undo work already accepted by a provider. */
interface CallOptions {
    signal?: AbortSignal;
    timeoutMs?: number;
}

/**
 * The plugin's outbox (spec §5.1 rules 1 and 2).
 *
 * No transport guarantees delivery. A connection that drops takes whatever was in flight with it, and
 * `emit` used to be a bare POST: the event simply stopped existing and nobody found out. The rule is
 * that the emitter persists first and forgets only on an acknowledgement, with the SAME event id on
 * every resend — a new id on a retry makes one event into two, and no deduplication window on the
 * receiving side can undo that.
 *
 * On disk, because the alternative fails exactly when it matters: an outbox in memory is lost when the
 * process restarts, and the reason it had anything pending was that the kernel was unreachable long
 * enough for somebody to restart it. In a container the directory must be a mounted volume — an
 * ephemeral filesystem is reassigned, which loses the outbox for the same reason.
 */
/** An event a plugin emits. It lives here because the outbox is what holds one until it is confirmed. */
interface EmittedEvent {
    eventId: string;
    type: string;
    payload: unknown;
    /** Events sharing one key are delivered in order; different keys go in parallel. */
    orderKey?: string;
    ackRequired?: boolean;
}
interface PluginOutbox {
    /** Records the event. Resolves once it will survive this process. */
    keep(event: EmittedEvent): Promise<void>;
    /** Everything not yet acknowledged, oldest first. */
    pending(): Promise<EmittedEvent[]>;
    /**
     * The event with this id, if the outbox still holds it as pending. Read-only.
     *
     * Optional so an outbox written against the earlier shape still satisfies this type. What needs it
     * is the one thing that has to look at an event just before the outbox lets go of it.
     */
    held?(eventId: string): Promise<EmittedEvent | undefined>;
    /** Forgets one the kernel confirmed. Forgetting something it never held is not an error. */
    acknowledge(eventId: string): Promise<void>;
    /**
     * Sets one aside: a consumer understood it and refused it.
     *
     * Held, because it is what the plugin panel shows — the one place that knows both the event and
     * the reason is the emitter still holding it — and no longer sent, because the same bytes earn the
     * same answer and resending is a loop.
     *
     * Optional so an outbox written against the earlier shape still satisfies this type.
     */
    refuse?(eventId: string, reason: string): Promise<void>;
    /** What was refused, and why. Empty for an outbox that does not keep them. */
    refused?(): Promise<{
        event: EmittedEvent;
        reason: string;
    }[]>;
    /**
     * Records who the event is owed to, replacing whatever was there.
     *
     * Written beside the event rather than in a table of its own, so a restart cannot leave an event
     * whose list is gone -- which would read as delivered.
     */
    owes?(eventId: string, instanceIds: readonly string[]): Promise<void>;
    /**
     * Records that one subscriber took the event.
     *
     * `true` when the event is now fully delivered and has been forgotten; `false` while others are
     * still owed, and also for a subscriber the event never owed or an event already gone -- a verdict
     * for something that is not here changes nothing and is not an error, because at-least-once runs
     * in both directions.
     */
    accepted?(eventId: string, instanceId: string): Promise<boolean>;
    /** Who still owes an answer. Empty for an event with no list, which is the old one-ack behaviour. */
    owing?(eventId: string): Promise<string[]>;
}
/**
 * What the outbox needs from a filesystem.
 *
 * Narrow on purpose: a test can hand over a filesystem whose `rename` fails the way Windows fails,
 * which is the only honest way to cover a durability path that depends on an error nobody can
 * provoke on demand. The default is `node:fs/promises` -- no Bun API here, and none needed: `rename`
 * behaves identically on both runtimes (an open handle on the destination is `EPERM` on both).
 */
interface OutboxFiles {
    mkdir(path: string, options: {
        recursive: true;
    }): Promise<unknown>;
    readdir(path: string): Promise<string[]>;
    readFile(path: string, encoding: "utf8"): Promise<string>;
    rename(from: string, to: string): Promise<void>;
    unlink(path: string): Promise<void>;
    writeFile(path: string, data: string, encoding: "utf8"): Promise<void>;
}
/** The real one. */
declare const nodeOutboxFiles: OutboxFiles;
/**
 * The outbox could not persist, and said so.
 *
 * Loud by design (rule 9): `onError` alone was what production already had, and nothing acted on it.
 * An event that cannot be written is an event the SDK cannot promise to resend, so the caller hears
 * about it instead of being handed a resolved promise that looks like success.
 */
declare class OutboxWriteFailed extends Error {
    constructor(target: string, options?: {
        cause?: unknown;
    });
}
declare function createFileOutbox(directory: string, files?: OutboxFiles): PluginOutbox;
/**
 * The same outbox in memory.
 *
 * For a test, and for a development run where losing the process is losing nothing. A plugin in
 * production uses the file one: see the note above about why memory fails exactly when it matters.
 */
declare function createMemoryOutbox(): PluginOutbox;
interface EmitterDeps {
    readonly outbox: PluginOutbox;
    /**
     * Hands the event over, and answers who now owes an answer for it.
     *
     * Raises when it could not be handed over at all -- no relay, or one that cannot be reached -- and
     * the event stays where it is. It never means "delivered": that is what the returned list is for,
     * crossed off one name at a time as the verdicts arrive (spec §4, §5).
     */
    send(event: EmittedEvent): Promise<readonly string[]>;
    /** An event that could not be sent. Silence here is the failure nobody notices (rule 9). */
    onError(error: unknown): void;
}
interface Emitter {
    /** Records the event, then tries to send it. Never raises because the kernel was unreachable. */
    emit(event: EmittedEvent): Promise<void>;
    /** Sends what is still pending, oldest first. Called on every reconnection. */
    flush(): Promise<void>;
}
declare function createEmitter({ outbox, send, onError }: EmitterDeps): Emitter;

/**
 * What the kernel hands an instance so it can use the relay.
 *
 * The author never sees any of this: the SDK asks, keeps it, renews it and presents it. A plugin's
 * code calls `emit` and reads events, exactly as before the relay existed.
 */
interface RelayOffer {
    /** The credential: it opens this instance's stream and emits, and it never leaves the SDK. */
    grant: string;
    /** The same statement, for proving rather than acting. It travels with every event. */
    proof: string;
    relayUrl: string;
    expiresAt: number;
    /** The key the grant is checked against. Carried here so a consumer needs nothing else. */
    publicKey: Record<string, unknown>;
}
/** What a grant says, as this side reads it. */
interface GrantView {
    instanceId: string;
    tenantId: string;
    pluginId: string;
    /**
     * Que horas eram no KERNEL quando o grant foi assinado.
     *
     * É o que deixa este lado ler a validade no relógio certo, em vez do próprio -- que, num plugin
     * de terceiro, é o relógio de um computador que ninguém aqui controla. Ausente num grant
     * assinado antes do campo existir.
     */
    issuedAt?: number;
    expiresAt: number;
    routes: Record<string, string[]>;
    /** Contract → the instance that answers it. Absent means this instance may call nothing. */
    calls?: Record<string, string>;
}
/**
 * The grant, or `undefined` for anything that is not one.
 *
 * Written here as well as in the kernel, like `kernel.v1.CallRequested` already is: this SDK has no
 * dependencies on purpose, because it is what a third party installs, and a shared import would drag
 * the product into a plugin's node_modules. The end to end test is what keeps the two honest.
 */
declare function verifyGrant(token: string, publicJwk: Record<string, unknown>, now?: number): GrantView | undefined;
interface RelayLinkDeps {
    /** Asks the kernel. `undefined` when the kernel offers no relay, or could not be reached. */
    ask(): Promise<RelayOffer | undefined>;
    now?(): number;
}
interface RelayLink {
    /** The current offer, renewed when it is close to running out. `undefined` when there is no relay. */
    offer(): Promise<RelayOffer | undefined>;
    /** Drops what is held, for a relay that refused it. The next `offer` asks again. */
    forget(): void;
}
declare function createRelayLink(deps: RelayLinkDeps): RelayLink;
/**
 * What the relay did with an event, which is the whole answer to an emit now.
 *
 * `away` is who the grant names and holds no stream, known without waiting for anybody — so the
 * emitter learns at once what it still owes, and the verdicts for `handed` arrive on its own stream.
 */
interface Handed {
    handed: string[];
    away: string[];
}
/** One frame of a verdict, as it arrives on the emitter's stream. */
interface VerdictFrame {
    eventId: string;
    /** The consumer that answered. */
    from: string;
    outcome: "accepted" | "refused";
    reason?: string;
}
/**
 * Hands the event over and returns what the relay did with it.
 *
 * It does not wait for the consumers: their verdicts arrive on this instance's own stream, and
 * `away` already says who could not be written to. Resolving means the relay took it, not that
 * anybody accepted it — that is what the outbox's list is for.
 */
declare function emitThroughRelay(doFetch: FetchLike, offer: RelayOffer, event: EmittedEvent): Promise<Handed>;
/**
 * What a kernel with a relay announces at the handshake.
 *
 * Restated here rather than imported, like the grant format above and `kernel.v1.CallRequested`
 * already are: this SDK has no dependencies, and the end to end test is what keeps the two honest.
 */
declare const RELAY_CAPABILITY = "kernel.relay.v1";

/** One event as the consumer's handler sees it: the same shape a kernel delivery already produces. */
interface RelayedToMe {
    eventId: string;
    type: string;
    instanceId: string;
    tenantId: string;
    orderKey: string;
    payload: unknown;
}
interface RelayConsumerOptions {
    /** `<pluginId>:<tenantId>` — this instance, which is what a delivery has to be addressed to. */
    instanceId: string;
    link: RelayLink;
    /**
     * What to do with an event.
     *
     * Returning means accepted. Throwing `EventRefused` means understood and wrong, and the emitter
     * stops retrying it. Throwing anything else means nothing is said, so the emitter tries again.
     */
    onEvent(event: RelayedToMe): Promise<void> | void;
    /**
     * Told when a verdict for one of THIS instance's own events comes back.
     *
     * A delivery and a verdict travel the same stream, because an instance both emits and consumes
     * over one connection. This is the emitting half, and it is what lets an emit return without
     * waiting for anybody (spec §4).
     */
    onVerdict?(verdict: VerdictFrame): Promise<void> | void;
    onError?(error: unknown): void;
    fetch?: FetchLike;
    /**
     * Fetches the artefact a large payload travelled as. Separate from `fetch` on purpose: the address
     * comes from the emitter, so this must be a plain fetch that adds no header, credential or rewrite.
     * Defaults to the global `fetch`.
     */
    downloadFetch?: FetchLike;
    /** How long before the first reconnection attempt. Doubles up to half a minute. */
    retryMs?: number;
    /** Keep asking for an offer when the kernel announced a relay but its grant RPC is temporarily unavailable. */
    retryWithoutOffer?: boolean;
    /**
     * A call the relay carried to this instance, answered by whatever this plugin provides.
     *
     * Returns the provider's own words: an `output`, or an `error` it chose. Throwing is the same as
     * an error it did not choose -- the caller is told the call failed, and nothing is retried.
     */
    onCall?(call: {
        callId: string;
        contract: string;
        method: string;
        input: unknown;
        caller: string;
    }): Promise<{
        output?: unknown;
        error?: string;
    }>;
    /** How long an accepted id is remembered. Ten minutes, which is the kernel's own window. */
    dedupWindowMs?: number;
    /**
     * How long to wait on the relay for a verdict to be taken. Ten seconds.
     *
     * Nothing waits without a deadline. A half-open socket here would leave the lane's promise
     * unsettled forever: every later event in that lane blocked, and `connect` never returning from
     * its wait for work in flight -- so the consumer would never reconnect either.
     */
    verdictTimeoutMs?: number;
    /** Wait for in-flight work before reconnecting. Stop rejects on timeout to prevent unsafe teardown. */
    drainTimeoutMs?: number;
    /**
     * How long a stream must have lasted for its clean end to earn an immediate reconnection.
     *
     * Below it, the end is treated as a failure and backs off -- a stream that ends as soon as it
     * opens would otherwise spin.
     */
    reconnectAtOnceAfterMs?: number;
    now?(): number;
}
interface RelayConsumer {
    /** Connects, and keeps connecting, until stopped. */
    start(): Promise<void>;
    stop(): Promise<void>;
    /**
     * Whether this instance's stream is up right now.
     *
     * An emitter that cannot be told does not emit: the event waits on disk instead, which is what it
     * already does for a relay that cannot be reached at all (spec §4).
     */
    connected(): boolean;
}
interface CarriedCall {
    callId: string;
    contract: string;
    method: string;
    input: unknown;
    caller: string;
}
/**
 * The consumer's side of the relay.
 *
 * Outbound only, exactly like the kernel stream it sits beside: it opens a stream and posts its
 * verdict back, so a plugin still never listens on a port.
 *
 * The grant is verified HERE, not only by the relay that carried it. The relay moves bytes between
 * peers and is deliberately not a source of truth about permissions, so a consumer that took its
 * word would be trusting the carrier instead of the kernel. What is checked is what the kernel
 * signed: that this emitter really holds a grant, and that the grant really routes this type here.
 */
declare function createRelayConsumer(options: RelayConsumerOptions): RelayConsumer;

interface HostOptions {
    /** Deadline for kernel requests and relay submissions. Defaults to 30 seconds. */
    requestTimeoutMs?: number;
    /**
     * Serialised bytes above which an event's payload goes to the artefact store instead of the relay.
     *
     * Leave it unset unless you have measured your own relay. The default is derived from the relay's
     * body limit, and below it the inline path is faster at every size measured -- lowering it trades
     * latency on each large event for relieving a process every plugin shares. `PLUGIN_LARGE_PAYLOAD_BYTES`
     * sets the same thing for an operator who cannot rebuild; see `thresholdFrom`.
     */
    largePayloadBytes?: number;
    /** Where the kernel is, e.g. "http://localhost:43000". */
    kernelUrl: string;
    /** The instance's token. It carries which company this plugin is acting for; nothing else does. */
    instanceToken: string;
    /** This instance's id, needed only to emit: the kernel refuses an envelope addressed to another. */
    instanceId?: string;
    /** Injected in tests; defaults to the global. */
    fetch?: FetchLike;
    /** A route handler that threw. The caller already got a 500; the author needs the reason. */
    onRouteError?: (error: unknown) => void;
    /**
     * Where emitted events are kept until the kernel acknowledges them (spec §5.1 rule 2).
     *
     * Optional, and that is deliberate: without one, `emit` raises when the kernel is unreachable, as it
     * always has, and the plugin decides what to do. With one, `emit` answers normally and the event
     * waits — on disk, if that is the outbox given — to be resent with the same id. A plugin that
     * handles a customer's messages wants the second; `createFileOutbox` on a mounted volume is it.
     */
    outbox?: PluginOutbox;
    /**
     * How long to wait before sending again what the relay could not hand over.
     *
     * Only while something is owed: an empty outbox is not a reason to keep reading a disk, so the
     * loop stops on its own and is armed again by the next event that stays behind.
     */
    retryPendingMs?: number;
    /** An event the outbox is still holding because it could not be sent. Silence here hides it. */
    onEmitError?: (error: unknown) => void;
    /**
     * Whether to use the relay when the kernel offers one. Defaults to true.
     *
     * Here only so a test can pin the kernel path. An author never sets it: which path an event takes
     * is the kernel's to decide, through the offer, and not something a plugin should have an opinion
     * about.
     */
    useRelay?: boolean;
}
interface HostStorage {
    /** Atomically records a previously absent key. False means another worker already claimed it. */
    claim?(key: string, value: unknown): Promise<boolean>;
    /** Reads a key and its opaque decimal version for compare-and-set coordination. */
    getVersioned?(key: string): Promise<{
        value: unknown;
        version: string;
    } | undefined>;
    /** Replaces a key only if it is still at this version; false means a concurrent writer won. */
    setIfVersion?(key: string, value: unknown, expectedVersion: string): Promise<{
        ok: boolean;
        version: string;
    }>;
    /** `undefined` when the key was never written. A stored `null` reads back as `null`. */
    get(key: string): Promise<unknown>;
    set(key: string, value: unknown): Promise<void>;
    delete(key: string): Promise<void>;
}
/**
 * A slot node, by its discriminant alone.
 *
 * The shell draws a SLOT contribution from one vocabulary (`kind`) and a PAGE from another (`type`),
 * and the two are easy to mix up: three examples built slot contributions with `type:`, the shell's
 * `isDeclarativeNode` discarded them, and three screens rendered blank while their tests still
 * passed. With both sides `unknown` the compiler had nothing to say about it. Pinning the
 * discriminant costs one field and rejects the whole swap.
 *
 * Deliberately NOT the full union. The closed sets live where the validator that enforces them lives
 * -- `frontend/src/slots/declarative-node.ts` for slot nodes and `frontend/src/slots/ui-tree.ts` for
 * page nodes -- and those two must not drift from each other nor from this. Lifting them into shared
 * `SlotNode`/`PageNode` types that both the shell and the SDK import is the proper fix, and is
 * follow-up spec material; this is the cheap half that keeps the regression from coming back green.
 */
type SlotNodeShape = {
    kind: string;
    [key: string]: unknown;
};
/** A page node, by its discriminant alone. See {@link SlotNodeShape} for why this is not the union. */
type PageNodeShape = {
    type: string;
    [key: string]: unknown;
};
/**
 * One piece of interface a plugin contributes, naming the slot it goes in.
 *
 * Named rather than written inline because it is announced from two places: the static manifest, and
 * `ctx.announce` for a plugin whose contributions are alive (a QR code, a session badge, a panel per
 * person who wrote in). Two copies of the shape would drift.
 */
interface ManifestSlot {
    id: string;
    slot: string;
    /** Higher values appear earlier when the host has no explicit administrator ordering. */
    priority?: number;
    content?: SlotNodeShape;
    component?: string;
}
/** What an instance says it offers, at the handshake (spec §4.5). */
interface PluginManifest {
    /**
     * Pieces of interface it contributes, each naming the slot it goes in.
     *
     * One of two things, never both: `content` is a declarative node the shell draws, and `component`
     * is the NAME of an export in this plugin's own bundle. The type demanded `content` on every
     * contribution for a while, which made the component case impossible to write.
     */
    slots?: ManifestSlot[];
    /** Screens of its own. */
    pages?: {
        path: string;
        title: string;
        content?: PageNodeShape;
        url?: string;
        component?: string;
    }[];
    /** Contracts it provides, so a caller can be routed to it. */
    provides?: string[];
    /**
     * Contracts it needs to work, with the essential ones marked (spec §4.8).
     *
     * A bundled module has declared this from the start; a remote plugin could not, so a plugin that
     * needed another one installed fine and then reported itself refused. Essential means the company
     * is told to install the provider FIRST, by name; optional means this plugin runs with less.
     */
    requires?: {
        contract: string;
        essential: boolean;
    }[];
    /** Permissions this plugin asks its installer to approve for calls and event subscriptions. */
    requestedScopes?: {
        name: string;
        description: string;
        essential: boolean;
    }[];
    /**
     * Effects it wants to keep going after its screen closes, by EFFECT name (`"audio"`), not by scope
     * name. The scopes travel separately in `requestedScopes`, built by `background()`. Passing the
     * scopes here declared nothing, with no error anywhere: the kernel reads effect names and drops
     * the rest, so the type now refuses a scope name at the author's keyboard. Only what the company
     * approved reaches the shell.
     */
    background?: readonly BackgroundEffect[];
    /** Event types its own contract declares. Anything else it emits is refused. */
    emits?: string[];
    /**
     * What this plugin's text says, per language.
     *
     * `{ "pt-BR": { queues: "Filas" }, en: { queues: "Queues" } }`. A plugin puts a KEY in the text
     * fields it sends and ships the words here; the shell resolves them for whoever is reading.
     *
     * Sent by the plugin rather than chosen by the kernel because language belongs to the person, not
     * the company: two agents at the same desk can want different ones from the same announced manifest.
     */
    messages?: Record<string, Record<string, string>>;
    /**
     * This plugin's own interface bundle, for contributions that are components.
     *
     * `integrity` pins what somebody reviewed: a bundle replaced at an approved address fails to load
     * rather than quietly shipping something nobody read. The operator approves the ORIGIN; the hash
     * says the bytes are the ones that were read.
     *
     * `styles` are stylesheets it needs, pinned the same way — a stylesheet is code. A bundle that
     * carries its CSS compiled inside it exports it as `css` instead and declares none here.
     */
    ui?: {
        url: string;
        integrity?: string;
        styles?: {
            url: string;
            integrity: string;
        }[];
    };
    /**
     * HTTP routes it answers, behind a prefix the kernel owns.
     *
     * The plugin says what it answers; the kernel says where. `path` is relative — `messages`, never
     * `/api/v1/messages` — because a plugin choosing its place in the product's namespace could shadow
     * a product route or collide with another plugin.
     *
     * `auth: "hook"` is reached at the address the kernel minted for this installation, which is the
     * credential; `auth: "session"` is reached by a person in the product, holding `scopes`. A hook
     * route declaring scopes is refused at the handshake: nobody holds a scope at a webhook, so the
     * route would look guarded and be open.
     */
    routes?: {
        method: "GET" | "POST" | "PUT" | "PATCH" | "DELETE";
        path: string;
        auth: "hook" | "session";
        scopes?: string[];
        /** The largest body it accepts. The kernel caps this whatever it says. */
        maxBodyBytes?: number;
    }[];
}
/** Metadata from installed emitters in this instance's company, never event payloads. */
interface DiscoveredEvent {
    type: string;
    owner: string;
    allowed: boolean;
}
interface DiscoveredContract {
    contract: string;
    owner: string;
    allowed: boolean;
}
interface KernelOffer {
    /** What the kernel offers, so the instance negotiates rather than guessing from a version number. */
    capabilities: string[];
}
interface Host {
    /** The kernel capabilities from the last successful handshake, undefined before the first one. */
    kernelCapabilities(): readonly string[] | undefined;
    /**
     * The relay this instance was offered, renewed as needed. `undefined` when the kernel offers none.
     *
     * Exposed because the consumer side needs the same offer the emitting side uses — one grant, one
     * renewal — and not because a plugin's author has any reason to call it.
     */
    relay(): Promise<RelayOffer | undefined>;
    /** Drops the held offer, for a relay that refused it. The next use asks the kernel again. */
    forgetRelay(): void;
    /**
     * Applies one consumer's verdict to what this instance is still holding.
     *
     * Called by whatever is reading this instance's relay stream. `accepted` crosses that subscriber
     * off the event's list, and the event is forgotten when the last name comes off; `refused` sets it
     * aside with its reason, because the same bytes earn the same answer (spec §5).
     */
    applyVerdict(verdict: {
        eventId: string;
        from: string;
        outcome: "accepted" | "refused";
        reason?: string;
    }): Promise<void>;
    /**
     * Tells the host whether this instance's relay stream is up.
     *
     * Wired by whatever is reading that stream. Until it says yes, `emit` holds the event: a verdict
     * comes back on that stream, and one sent to an instance that is not listening is dropped by the
     * relay -- so emitting first would spend a delivery, run somebody's handler, and learn nothing
     * about it (spec §4).
     */
    reachableWhen(connected: () => boolean): void;
    /**
     * Opens this instance's relay stream, and keeps it open.
     *
     * One call, because the wiring is the same for every plugin and getting any part of it wrong is
     * silent: the verdicts come back on this stream, and an instance that cannot be told does not emit
     * (spec §4). A plugin that only emits needs it too.
     *
     * Does nothing on a kernel that offers no relay, so calling it is always safe. Call it after
     * `initialize`, because the offer is learned at the handshake — including from `onConnected`, which
     * runs again on every reconnection: a second call returns the stream the first one opened rather
     * than opening another, so nobody has to remember that.
     */
    startRelay(options?: {
        onEvent?(event: RelayedToMe): Promise<void> | void;
        /** What answers a contract call the relay carried here. Absent means this plugin serves none. */
        onCall?(call: CarriedCall): Promise<{
            output?: unknown;
            error?: string;
        }>;
        retryMs?: number;
    }): {
        stop(): void | Promise<void>;
        /** Whether the stream is up. An emit holds the event until it is. */
        connected(): boolean;
    };
    /**
     * The company this instance serves.
     *
     * An instance is one plugin for one company, so a plugin never has to be told which — and never has
     * to carry it around. Empty only when the deployment did not name the instance.
     */
    readonly tenantId: string;
    /**
     * Introduces this instance and says what it offers. Nothing it contributes reaches a screen before
     * this, and the kernel forgets it when the connection goes away.
     */
    initialize(manifest: PluginManifest): Promise<KernelOffer>;
    /**
     * Calls another contract. `undefined` means nobody provides it -- a typed state to degrade on, never
     * a mysterious timeout (spec §4.8).
     */
    call(contract: string, method: string, input: unknown, options?: CallOptions): Promise<unknown>;
    /** Asks to hear about event types. Whether they arrive is decided by what the company granted. */
    subscribe(eventTypes: readonly string[]): Promise<void>;
    discoverEvents?(): Promise<DiscoveredEvent[]>;
    discoverContracts?(): Promise<DiscoveredContract[]>;
    publishNotification?(input: PublishNotification): Promise<PublishNotificationResult>;
    listMembers?(input: {
        offset?: number;
        pageSize?: number;
    }): Promise<{
        members: DirectoryMember[];
        nextOffset: number | null;
    }>;
    emit(event: EmittedEvent): Promise<void>;
    /**
     * Sends whatever the outbox is still holding, with the same ids (spec §5.1 rule 1).
     *
     * Does nothing when no outbox was given. Call it after reconnecting: what is pending is pending
     * because the kernel was unreachable, and being reachable again is the news.
     */
    flushOutbox(): Promise<void>;
    storage: HostStorage;
    /**
     * What the company configured for this instance (spec §7.4).
     *
     * Read only: the administrator fills it in, and a plugin that could write it would silently undo
     * their work. What belongs to the plugin goes in `storage`.
     */
    config(): Promise<Record<string, unknown>>;
    /**
     * Answers a call the kernel forwarded to this plugin (spec §4.8).
     *
     * This is what lets a plugin PROVIDE a contract rather than only consume one. `false` means nobody
     * was waiting any more: the caller gave up while the plugin was working, which is not the plugin's
     * failure and not something to retry.
     */
    respond(requestId: string, answer: {
        output?: unknown;
        error?: string;
    }): Promise<boolean>;
    /**
     * Builds the handler for calls the kernel forwards to this plugin.
     *
     * Hand the result the payload of a `kernel.v1.CallRequested` event and it runs the right method and
     * answers. Every plugin that provides a contract would otherwise write this correlation itself, and
     * each would get the error path subtly wrong.
     */
    /**
     * Handles a forwarded request: a contract call, or a request at one of this plugin's HTTP routes.
     *
     * Both arrive the same way — the kernel cannot call a plugin, so it writes the request to the stream
     * the plugin holds and the plugin answers with `Respond`. The routes are a separate argument because
     * they are a different thing to the author: a contract is a method somebody else calls by name, a
     * route is an address somebody else's SYSTEM calls.
     */
    serving(contracts: ServedContracts, routes?: ServedRoutes): (payload: unknown) => Promise<void>;
    /**
     * Keeps a binary somewhere a browser can fetch it, and answers where it is.
     *
     * This exists because a plugin's process needs no inbound port -- it dials -- while its interface
     * bundle has the opposite requirement: the browser fetches that directly, so it must live at an
     * address every agent's browser can reach. On a closed machine there is no such address, and the
     * screen is the only part of the design that breaks the promise that a plugin only dials.
     *
     * So the plugin asks. The kernel authorises and either signs an address on its object store -- in
     * which case not a byte passes through the kernel -- or takes the upload itself. Idempotent by the
     * hash: calling it again with the same bytes transfers nothing.
     *
     * Raises when the kernel has no artefact store, which is a supported deployment: a plugin that
     * serves its own bundle at its own address needs none of this.
     */
    storeArtefact(artefact: ArtefactToStore): Promise<StoredArtefact>;
}
/**
 * The person a call was made by, when a person made it.
 *
 * Established by the KERNEL from the session it verified, and carried on the call. A plugin may act
 * on it; nothing else on a call says who anybody is. Spelled out here rather than imported because
 * the SDK has no dependencies on purpose, exactly like `kernel.v1.CallRequested` above.
 */
interface CallerIdentity {
    userId: string;
    /** Their cargo in THIS company: the same person may be an owner in one and an agent in another. */
    role: string;
}
/**
 * What a handler is told about the call itself, beside its input.
 *
 * `caller` is absent far more often than not — every call from another plugin has nobody behind it —
 * so a handler that needs an author checks for it and refuses, rather than inventing one.
 */
interface ServedCall {
    caller?: CallerIdentity;
}
/** What a plugin provides: a method per name, per contract. */
type ServedContracts = Record<string, Record<string, (input: unknown, call?: ServedCall) => unknown>>;
/** A request at one of a plugin's HTTP routes, as the kernel forwards it. */
interface RouteRequest {
    method: string;
    /** The route as declared, e.g. `conversations/:id/messages`. */
    path: string;
    params: Record<string, string>;
    query: Record<string, unknown>;
    body: unknown;
    /** Only the Meta webhook signature, never arbitrary caller headers. */
    webhookSignature?: string;
    /** Original body bytes, base64 encoded for HMAC verification after JSON parsing. */
    rawBodyBase64?: string;
}
/**
 * What a handler answers.
 *
 * A status and a body, and nothing else: the kernel writes the response. A plugin that could set
 * headers would have authority over the product's own origin, and one that could redirect would send
 * somebody else's caller wherever it liked.
 */
interface RouteAnswer {
    status: number;
    body?: unknown;
    /** `text/plain` is needed for provider webhook challenge handshakes. */
    contentType?: "text/plain";
}
/** A handler per `"<METHOD> <path>"`, matching what the manifest declared. */
type ServedRoutes = Record<string, (request: RouteRequest) => RouteAnswer | Promise<RouteAnswer>>;
declare function createHost(options: HostOptions): Host;

export { verifyGrant as $, type ArtefactToStore as A, type BackgroundEffect as B, type CarriedCall as C, type DiscoveredContract as D, type EmittedEvent as E, type FetchLike as F, type GrantView as G, type Host as H, backgroundScope as I, contractCallScope as J, type KernelOffer as K, createEmitter as L, type ManifestSlot as M, NO_ARTEFACT_STORE as N, type OutboxFiles as O, type PluginManifest as P, createFileOutbox as Q, type RelayedToMe as R, type ServedContracts as S, createMemoryOutbox as T, createRelayConsumer as U, createRelayLink as V, emitThroughRelay as W, eventsEmitScope as X, eventsReadScope as Y, integrityOf as Z, nodeOutboxFiles as _, type CallOptions as a, type HostOptions as a0, createHost as a1, PublishNotification as b, PublishNotificationResult as c, DirectoryMember as d, type DiscoveredEvent as e, type ServedRoutes as f, type PageNodeShape as g, type ServedCall as h, type ArtefactZone as i, ARTEFACT_ZONES as j, BACKGROUND_EFFECTS as k, type CallerIdentity as l, type Emitter as m, type EmitterDeps as n, type HostStorage as o, OutboxWriteFailed as p, type PluginOutbox as q, RELAY_CAPABILITY as r, type RelayConsumer as s, type RelayConsumerOptions as t, type RelayLink as u, type RelayOffer as v, type RouteAnswer as w, type RouteRequest as x, type SlotNodeShape as y, type StoredArtefact as z };
