/** The tones the design system has. A plugin picks one; it never sends colour. */
type Tone = "neutral" | "muted" | "success" | "warning" | "danger";
/**
 * What a plugin puts on screen, once serialised.
 *
 * The author writes TSX. This is what their build produces and what travels: a tree, drawn by the
 * shell, never run. JSX would have to be compiled and then evaluated in the browser, and evaluated
 * plugin code holds the access token kept in memory, the DOM, and whatever is on screen.
 */
type UiNode = {
    type: "text";
    value: string;
    tone?: Tone;
} | {
    type: "heading";
    value: string;
} | {
    type: "field";
    label: string;
    value: string;
    mono?: boolean;
} | {
    type: "badge";
    label: string;
    tone?: Tone;
} | {
    type: "stack";
    children: UiNode[];
} | {
    type: "row";
    children: UiNode[];
} | {
    type: "panel";
    title?: string;
    children: UiNode[];
} | {
    type: "link";
    label: string;
    to: string;
    icon?: string;
} | {
    type: "button";
    label: string;
    action: string;
    tone?: Tone;
} | {
    type: "sandbox";
    title: string;
    url: string;
};
/**
 * One event off the kernel stream: what happened, and which record — never the data itself.
 *
 * Matching the kernel's shape on purpose (spec §5.5): a plugin screen reads the same frame the app
 * does, and refetches through the typed client like everybody else.
 */
interface StreamedEvent {
    type: string;
    /** The record it concerns, or empty for an event about nothing in particular. */
    key: string;
    /** What a screen watches, e.g. "chat.tickets" and "chat.tickets:t-1". */
    topics: readonly string[];
}

/**
 * The JSX runtime a plugin compiles against.
 *
 * With `"jsxImportSource": "@creativepetabyte/argus-sdk/ui"` in its tsconfig, the author writes TSX and the
 * compiler turns it into these calls. Nothing here runs in the app: this runs on the AUTHOR's machine,
 * at their build, and produces the tree that ships.
 */
type Props = Record<string, unknown> & {
    children?: unknown;
};
declare function jsx(component: unknown, props: Props): UiNode;
declare const jsxs: typeof jsx;
declare const jsxDEV: typeof jsx;
/**
 * What TypeScript needs to typecheck the TSX.
 *
 * `IntrinsicElements` is deliberately empty: `<div>` is not something a plugin may write, and saying so
 * here makes it a compile error on the author's machine rather than a blank space in production.
 */
declare namespace JSX {
    type Element = UiNode;
    interface IntrinsicElements {
    }
    interface ElementChildrenAttribute {
        children: Record<string, never>;
    }
}
/** `<>...</>` is a list, which only makes sense inside something that holds children. */
declare function Fragment(props: Props): UiNode;

export { Fragment as F, JSX as J, type StreamedEvent as S, type Tone as T, type UiNode as U, jsxDEV as a, jsxs as b, jsx as j };
