// src/artefacts.ts
import { createHash } from "node:crypto";
var integrityOf = (bytes) => `sha384-${createHash("sha384").update(bytes).digest("base64")}`;

// src/testing.ts
var HTTP_ROUTE_CONTRACT = "kernel.v1.HttpRoute";
function createFakeHost(options = {}) {
  const handlers = /* @__PURE__ */ new Map();
  const stored = new Map(Object.entries(options.storage ?? {}));
  const versions = new Map([...stored.keys()].map((key2) => [key2, "1"]));
  const calls = [];
  const emitted = [];
  const subscriptions = [];
  const responses = [];
  const artefacts = [];
  let manifest;
  let relayOptions;
  let relayStream;
  let relayOpens = 0;
  let served;
  async function answerServed(call) {
    const isRoute = call.contract === HTTP_ROUTE_CONTRACT;
    const routeHandler = isRoute ? served?.routes?.[call.method] : void 0;
    const handler = isRoute ? void 0 : served?.contracts[call.contract]?.[call.method];
    if (routeHandler !== void 0) {
      const input = typeof call.input === "object" && call.input !== null ? call.input : {};
      try {
        return {
          output: await routeHandler({
            method: String(input.method ?? ""),
            path: String(input.path ?? ""),
            params: input.params ?? {},
            query: input.query ?? {},
            body: input.body
          })
        };
      } catch {
        return { output: { status: 500, body: { error: "handler_failed" } } };
      }
    }
    if (handler === void 0) {
      return isRoute ? { output: { status: 404, body: { error: "not_found" } } } : { error: "unknown_method" };
    }
    try {
      return { output: await handler(call.input) };
    } catch {
      return { error: "handler_failed" };
    }
  }
  const key = (contract, method) => `${contract}\0${method}`;
  return {
    // The company this fake instance serves, so a test reads like the real thing.
    tenantId: options.tenantId ?? "empresa-de-teste",
    // This fake deliberately has no relay or other optional kernel capabilities.
    kernelCapabilities: () => [],
    /**
     * No relay, so a plugin tested against this fake takes the kernel path.
     *
     * Which path an event takes is the kernel's decision, and a fake kernel that offered a relay
     * would need a relay to go with it. A test about the relay belongs in an integration test with
     * one running.
     */
    relay: async () => void 0,
    forgetRelay: () => {
    },
    /** No relay, so no verdict ever comes back: a fake kernel offers none. */
    applyVerdict: async () => {
    },
    reachableWhen: () => {
    },
    /**
     * Nothing to connect to, so nothing to stop: a fake kernel offers no relay.
     *
     * The handlers are kept all the same, so a test can carry an event or a call over this stream
     * and watch the plugin answer. Without that, every assertion about the relay side of a plugin
     * would pass against a plugin that never opened it.
     */
    startRelay(options2) {
      if (relayStream !== void 0) return relayStream;
      relayOpens += 1;
      relayOptions = options2;
      relayStream = {
        stop: () => {
          relayOptions = void 0;
          relayStream = void 0;
        },
        connected: () => false
      };
      return relayStream;
    },
    get relayOpens() {
      return relayOpens;
    },
    async deliverOverRelay(event) {
      await relayOptions?.onEvent?.(event);
    },
    // An explicit handler wins, and otherwise what `serving` was told answers -- the host's own
    // order of preference, so the fake is never more capable than the thing it stands for.
    async callOverRelay(call) {
      const explicit = relayOptions?.onCall;
      return explicit === void 0 ? await answerServed(call) : await explicit(call);
    },
    onCall(contract, method, handler) {
      handlers.set(key(contract, method), handler);
    },
    get calls() {
      return calls;
    },
    get artefacts() {
      return artefacts;
    },
    get emitted() {
      return emitted;
    },
    // Nothing is ever pending here: the fake kernel always accepts, so there is nothing to resend.
    flushOutbox: () => Promise.resolve(),
    get subscriptions() {
      return subscriptions;
    },
    get responses() {
      return responses;
    },
    get manifest() {
      return manifest;
    },
    initialize(sent) {
      manifest = { ...sent, implements: ["ExportTenantData", "DeleteTenantData"] };
      return Promise.resolve({ capabilities: [] });
    },
    // Async so a handler that throws becomes a rejected promise, the way a failing provider reaches a
    // plugin over the wire -- a synchronous throw would escape before the caller could await it.
    async call(contract, method, input) {
      calls.push({ contract, method, input });
      const handler = handlers.get(key(contract, method));
      if (handler === void 0) return void 0;
      return await handler(input);
    },
    subscribe(eventTypes) {
      subscriptions.push(...eventTypes);
      return Promise.resolve();
    },
    discoverContracts: () => Promise.resolve([...options.contracts ?? []]),
    emit(event) {
      emitted.push(event);
      return Promise.resolve();
    },
    config: () => Promise.resolve(options.config ?? {}),
    /**
     * Records the artefact and answers an address, without a store of any kind.
     *
     * A plugin's own tests are about its screens and its handlers, not about where a bundle lives --
     * and a fake that raised here would make every plugin that ships one unable to start under test.
     */
    storeArtefact: (artefact) => {
      const integrity = integrityOf(artefact.bytes);
      artefacts.push({ ...artefact, zone: artefact.zone ?? "durable", integrity });
      return Promise.resolve({ url: `https://kernel.test/v1/artefacts/${integrity}`, integrity });
    },
    serving(contracts, routes) {
      served = { contracts, ...routes === void 0 ? {} : { routes } };
      return async (payload) => {
        const raw = typeof payload === "object" && payload !== null ? payload : {};
        const requestId = raw.requestId;
        if (typeof requestId !== "string" || requestId === "") return;
        await this.respond(
          requestId,
          await answerServed({ contract: String(raw.contract), method: String(raw.method), input: raw.input })
        );
      };
    },
    respond(requestId, answer) {
      responses.push({ requestId, ...answer });
      return Promise.resolve(true);
    },
    storage: {
      claim: async (key2, value) => {
        if (stored.has(key2)) return false;
        stored.set(key2, value);
        versions.set(key2, "1");
        return true;
      },
      getVersioned: async (key2) => {
        if (!stored.has(key2)) return void 0;
        return { value: stored.get(key2), version: versions.get(key2) ?? "1" };
      },
      setIfVersion: async (key2, value, expectedVersion) => {
        const actual = versions.get(key2) ?? "0";
        if (actual !== expectedVersion) return { ok: false, version: actual };
        const next = (BigInt(actual) + 1n).toString();
        stored.set(key2, value);
        versions.set(key2, next);
        return { ok: true, version: next };
      },
      // `undefined` for a key that was never written; a stored `null` reads back as `null`.
      get: (k) => Promise.resolve(stored.has(k) ? stored.get(k) : void 0),
      set: (k, value) => {
        stored.set(k, value);
        versions.set(k, (BigInt(versions.get(k) ?? "0") + 1n).toString());
        return Promise.resolve();
      },
      delete: (k) => {
        stored.delete(k);
        versions.delete(k);
        return Promise.resolve();
      }
    }
  };
}
export {
  createFakeHost
};
//# sourceMappingURL=testing.js.map