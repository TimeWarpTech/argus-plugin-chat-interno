import { H as Host, A as ArtefactToStore, E as EmittedEvent, P as PluginManifest, R as RelayedToMe, C as CarriedCall, D as DiscoveredContract } from './host-BWk47Iqh.js';
import 'zod';

/** A call a plugin made, recorded so a test can assert on what it asked for. */
interface RecordedCall {
    contract: string;
    method: string;
    input: unknown;
}
/** The manifest as the KERNEL receives it, including what the SDK declares on the author's behalf. */
type SentManifest = PluginManifest & {
    implements: string[];
};
/** One artefact a plugin asked to have kept, so a test can say what it shipped. */
interface RecordedArtefact extends ArtefactToStore {
    integrity: string;
}
interface FakeHost extends Host {
    /** What this plugin asked the kernel to keep, in order. */
    readonly artefacts: RecordedArtefact[];
    /** Answers this contract's method. Throwing from the handler is how a test makes a call fail. */
    onCall(contract: string, method: string, handler: (input: unknown) => unknown): void;
    readonly calls: RecordedCall[];
    readonly emitted: EmittedEvent[];
    readonly subscriptions: string[];
    /** Answers this plugin gave to calls the kernel forwarded, so a test can assert what it replied. */
    readonly responses: {
        requestId: string;
        output?: unknown;
        error?: string;
    }[];
    /** What was sent at the handshake, or `undefined` when the plugin never introduced itself. */
    readonly manifest: SentManifest | undefined;
    /**
     * How many times the relay stream was asked for. `0` means the plugin never opened it.
     *
     * Worth asserting because forgetting to is silent: the plugin runs, emits nothing anybody sees and
     * answers `away` to every caller, and there was a lint rule rather than a test for it.
     */
    readonly relayOpens: number;
    /** Hands an event to whatever is reading the relay stream, as the relay would. */
    deliverOverRelay(event: RelayedToMe): Promise<void>;
    /**
     * Carries a call to this plugin over the relay.
     *
     * Answered by the handler the plugin gave `startRelay`, and otherwise from what `serving` was
     * told -- which is the real host's own order of preference, and the reason a plugin does not have
     * to answer the same call twice in two places.
     */
    callOverRelay(call: CarriedCall): Promise<{
        output?: unknown;
        error?: string;
    }>;
}
interface FakeHostOptions {
    /** What the company configured for this instance. */
    config?: Record<string, unknown>;
    /** Storage the instance already holds, for a test about what a plugin does on its second run. */
    storage?: Record<string, unknown>;
    /** The company this instance serves. An instance is one plugin for one company. */
    tenantId?: string;
    /** Contract catalog returned to this company's plugin. */
    contracts?: readonly DiscoveredContract[];
}
/**
 * A kernel that is not there, for testing a plugin.
 *
 * A plugin author should be able to run their tests with nothing installed: no Postgres, no Redis, no
 * kernel. What their code does when a contract answers, when nobody provides it, when storage is empty
 * on a first run -- all of that is logic, and logic should not need infrastructure to be exercised.
 *
 * It answers the way the real kernel answers, and the places where that matters are deliberate:
 * `undefined` for a contract nobody provides rather than a throw (spec §4.8), `undefined` for a key
 * never written but `null` for one holding null, and the mandatory lifecycle methods appearing in the
 * manifest because the SDK puts them there.
 */
declare function createFakeHost(options?: FakeHostOptions): FakeHost;

export { type FakeHost, type FakeHostOptions, type RecordedArtefact, type RecordedCall, type SentManifest, createFakeHost };
