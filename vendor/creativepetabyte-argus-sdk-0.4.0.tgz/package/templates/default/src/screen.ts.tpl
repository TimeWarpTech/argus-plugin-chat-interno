/**
 * What this plugin puts on screen, and the presses that belong to it.
 *
 * Kept in a file of its own because it is the one part that changes WHOLESALE when a plugin outgrows
 * the shell's vocabulary: `npx @creativepetabyte/argus-sdk add-screen` replaces this file with one
 * that names a React component instead, and nothing else about the plugin has to move.
 *
 * Today it needs no bundle at all. The page, the button and the modal are data; the product's own
 * shell draws them.
 */
import { declarativeScreens, type ManifestSlot, NAVBAR_LEADING } from "@creativepetabyte/argus-sdk";

export const PLUGIN_ID = "{{pluginId}}";
export const SCREEN_PATH = "{{directory}}";

/** The two presses this plugin answers. Any other press belongs to somebody else. */
export const OPEN = "{{pluginId}}.open";
export const CLOSE = "{{pluginId}}.close";

/** The page: one button, and nothing the shell cannot draw. A page node discriminates on `type`. */
const PAGE = {
  type: "stack",
  children: [{ type: "button", label: { key: "action.open" }, action: OPEN }],
} as const;

export const screen = declarativeScreens({
  pages: [
    {
      path: SCREEN_PATH,
      title: { "pt-BR": "{{namePtBr}}", en: "{{nameEn}}" },
      content: PAGE,
      rail: { icon: "sparkles" },
    },
  ],
});

/**
 * The modal, as a contribution rather than as part of the page.
 *
 * A modal exists in the SLOT vocabulary (`kind`) and not in the page one (`type`), so it is
 * announced into one of the shell's slots. The host renders it through a portal, so it covers the
 * app wherever it was contributed -- the slot is a mounting point, not a position.
 */
export const dialog: ManifestSlot = {
  id: `${PLUGIN_ID}:dialog`,
  slot: NAVBAR_LEADING,
  content: {
    kind: "dialog",
    title: { key: "dialog.title" },
    closeLabel: { key: "dialog.close" },
    closeAction: CLOSE,
    children: [{ kind: "text", value: { key: "dialog.body" } }],
  },
};
