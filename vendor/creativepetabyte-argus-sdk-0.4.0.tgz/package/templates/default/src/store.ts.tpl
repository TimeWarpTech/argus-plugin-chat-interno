/**
 * This company's state, behind a name that says what it means.
 *
 * `ctx.store` is already scoped to one company, so nothing here takes a tenant: there is no way to
 * reach another company's data from the context this is handed. Wrapping it is still worth it —
 * `isDialogOpen()` says what the value is for, where `get("open")` would have the key spelled at
 * every call site.
 */
import type { PluginContext } from "@creativepetabyte/argus-sdk";

const DIALOG_OPEN = "dialog.open";

export interface Store {
  isDialogOpen(): Promise<boolean>;
  setDialogOpen(open: boolean): Promise<void>;
  forget(): Promise<void>;
}

export function openStore(ctx: PluginContext): Store {
  return {
    async isDialogOpen() {
      return (await ctx.store.get<boolean>(DIALOG_OPEN)) === true;
    },
    async setDialogOpen(open: boolean) {
      await ctx.store.set(DIALOG_OPEN, open);
    },
    async forget() {
      await ctx.store.delete(DIALOG_OPEN);
    },
  };
}
