/**
 * The press loop, with no kernel in sight.
 *
 * No kernel, no database, no network: what this plugin decides is logic, and logic should not need
 * infrastructure to be exercised. `company()` builds the plugin the way the runtime builds it, and
 * building it twice is how a test sees the mistake this design makes easy -- state kept at module
 * scope answers one company's question with another's.
 */
import { contextFor, type Host, runPluginConformance } from "@creativepetabyte/argus-sdk";
import { createFakeHost } from "@creativepetabyte/argus-sdk/testing";
import { describe, expect, it } from "vitest";
import plugin, { ACTION_INVOKED, CLOSE, OPEN, onAction } from "./plugin.js";

/** One company's plugin, built the way the runtime builds it. */
function company(host: Host, tenantId = "empresa-a") {
  const ctx = contextFor(
    host,
    { instanceId: `{{pluginId}}:${tenantId}`, instanceToken: `token-${tenantId}` },
    undefined,
    () => {},
  );
  return { ctx, built: plugin.create(ctx) };
}

describe("{{nameEn}}", () => {
  it("opens the dialog when its own button is pressed", async () => {
    const { ctx } = company(createFakeHost());

    expect(await onAction(ctx, { action: OPEN })).toBe("opened");
  });

  it("closes it again", async () => {
    const { ctx } = company(createFakeHost());
    await onAction(ctx, { action: OPEN });

    expect(await onAction(ctx, { action: CLOSE })).toBe("closed");
  });

  /** A press meant for another plugin. Answering it would be acting on somebody else's button. */
  it("ignores a press it did not put there", async () => {
    const { ctx } = company(createFakeHost());

    expect(await onAction(ctx, { action: "somebody.else" })).toBe("ignored");
  });

  /** A payload from the wire, which is not something this code may assume the shape of. */
  it("ignores a payload it cannot read", async () => {
    const { ctx } = company(createFakeHost());

    expect(await onAction(ctx, null)).toBe("ignored");
  });

  /**
   * One company's dialog is not another's -- each with its own host, as the runtime builds them.
   *
   * This is what catches a collection left at MODULE scope: one process serves every company, and
   * state outside `create` is one company's memory answering for another. A shared host would prove
   * nothing here, because then the storage really is one.
   */
  it("keeps one company's dialog out of another's", async () => {
    const a = company(createFakeHost(), "empresa-a");
    const b = company(createFakeHost(), "empresa-b");

    await onAction(a.ctx, { action: OPEN });

    expect(await b.built.exportData()).toMatchObject({ dialogOpen: false });
  });

  /**
   * The kernel's own six promises: idempotence, degradation, undeclared events, company leakage,
   * export and deletion.
   *
   * `eventFor` is the one part an author owns. The suite's events are its own
   * (`exemplo.v1.Pedido`), and every plugin dispatches on the type -- so without this translation
   * the plugin would ignore all of them and pass the whole suite by doing nothing. The first
   * scenario exists to catch exactly that.
   */
  it("passes the conformance suite", async () => {
    expect(
      await runPluginConformance({
        definition: plugin,
        eventFor: () => ({ type: ACTION_INVOKED, payload: { action: OPEN } }),
      }),
    ).toEqual([]);
  });
});
