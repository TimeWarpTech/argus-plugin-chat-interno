/**
 * The process: three lines, and no inbound port.
 *
 * It dials the kernel and the relay, which is why it works from inside a customer's network, behind
 * NAT, on somebody's laptop. The connection token carries the address of the server that minted it,
 * so there is no address to configure beside it.
 */
import { runPlugin } from "@creativepetabyte/argus-sdk";
import plugin from "./plugin.js";

await runPlugin(plugin);
