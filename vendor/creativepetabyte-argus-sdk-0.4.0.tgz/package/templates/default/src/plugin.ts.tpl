/**
 * {{nameEn}} — what this plugin does, with no connection in sight.
 *
 * `create` runs ONCE PER COMPANY, and everything inside it belongs to that company and no other.
 * This file never names a company because it cannot reach one: isolation is what the types offer,
 * not what the author has to remember.
 *
 * What it puts on SCREEN is in `screen.ts`, which is the file that changes wholesale when a plugin
 * outgrows the shell's vocabulary.
 */
import { definePlugin, type PluginContext, type Serves } from "@creativepetabyte/argus-sdk";
import { CLOSE, dialog, OPEN, PLUGIN_ID, screen } from "./screen.js";
import { openStore } from "./store.js";

export { CLOSE, OPEN, PLUGIN_ID };

/** A press on anything this plugin put on screen arrives as this event, minted by the kernel. */
export const ACTION_INVOKED = "kernel.v1.ActionInvoked";

/**
 * The contract this plugin answers, and the ONLY way its own screen can ask it anything.
 *
 * A press leaves the browser as an event, and an event has no answer -- which is enough for "do
 * this" and useless for "what is stored". A screen of this plugin's own therefore reads through a
 * contract, over the `call` the host hands its component, and there is no second way in: the kernel
 * serves `POST /api/v1/plugins/:pluginId/contracts/:contract/:method` and nothing else. An author
 * who guessed instead reached for `fetch("/api/v1/plugins/<id>/routes/orders")` and got a 404 from a
 * plugin that was running perfectly.
 *
 * It is declared even in the plugin the shell draws, where nothing calls it yet, because the screen
 * that needs it arrives later and the contract is the half that is easy to not know about.
 */
export const SCREEN_CONTRACT = "{{pluginId}}.v1.Screen";

/** Where the modal's own words live, both languages complete. */
const MESSAGES = {
  "pt-BR": {
    "action.open": "Abrir",
    "dialog.title": "{{namePtBr}}",
    "dialog.body": "Esta janela é desenhada pelo produto. O plugin só disse que ela existe.",
    "dialog.close": "Fechar",
  },
  en: {
    "action.open": "Open",
    "dialog.title": "{{nameEn}}",
    "dialog.body": "The product draws this window. The plugin only said that it exists.",
    "dialog.close": "Close",
  },
} as const;

/** What a press carries, once checked. An event payload is external data: validated, never asserted. */
function pressedAction(payload: unknown): string | undefined {
  if (typeof payload !== "object" || payload === null) return undefined;
  const { action } = payload as Record<string, unknown>;
  return typeof action === "string" ? action : undefined;
}

/** What this plugin decided about one press. A union, so a test names the case it is about. */
export type Outcome = "ignored" | "opened" | "closed";

/**
 * Answers a press, and says what it decided.
 *
 * The decision is kept apart from the handler that receives it: a handler is a thin shell, and a
 * test asserts the decision rather than a sentence somebody phrased.
 */
export async function onAction(ctx: PluginContext, payload: unknown): Promise<Outcome> {
  const action = pressedAction(payload);
  if (action !== OPEN && action !== CLOSE) return "ignored";

  const store = openStore(ctx);
  const open = action === OPEN;
  await store.setDialogOpen(open);
  // The list REPLACES what the manifest declared, so the rail link travels with it: announcing only
  // the dialog would take this plugin's own way in off the screen while the modal is up.
  await ctx.announce(open ? [...screen.slots, dialog] : screen.slots);
  return open ? "opened" : "closed";
}

export default definePlugin({
  id: PLUGIN_ID,
  manifest: {
    ...screen,
    /**
     * `consumes` IS the subscription: the runtime derives it from here, so there is no version of
     * this plugin that ships connected, running and deaf.
     */
    consumes: [ACTION_INVOKED],
    /**
     * Named here and answered in `create`, and the type ties the two together: a contract on one
     * side only is a compile error rather than a plugin that starts and then refuses a caller.
     */
    serves: [SCREEN_CONTRACT],
    messages: {
      "pt-BR": { ...screen.messages["pt-BR"], ...MESSAGES["pt-BR"] },
      en: { ...screen.messages.en, ...MESSAGES.en },
    },
  },

  create(ctx: PluginContext) {
    /**
     * This company's event ids, and nobody else's.
     *
     * Delivery is at-least-once: after a reconnection the same press WILL arrive again. A `Set`
     * declared here is per company by construction — the same `Set` at module scope would be one
     * company's memory answering for another, which no runtime test can see.
     */
    const handled = new Set<string>();

    const store = openStore(ctx);

    /**
     * What this company's screen may ask, and the whole of it.
     *
     * The state lives HERE, not in the component: a browser that reloads, a second tab and a second
     * device all draw the same thing, because none of them is where it is kept. The input arrives
     * from a browser, so it is validated and never asserted -- `open` is read, and anything that is
     * not a boolean leaves the stored value alone rather than writing `undefined` into it.
     */
    const serves: Serves<typeof SCREEN_CONTRACT> = {
      [SCREEN_CONTRACT]: {
        State: async () => ({ open: await store.isDialogOpen() }),
        SetOpen: async (input: unknown) => {
          const open =
            typeof input === "object" && input !== null ? (input as Record<string, unknown>).open : undefined;
          if (typeof open === "boolean") await store.setDialogOpen(open);
          return { open: await store.isDialogOpen() };
        },
      },
    };

    return {
      serves,

      async onEvent(event) {
        if (event.type !== ACTION_INVOKED) return;
        const eventId: unknown = event.eventId;
        if (typeof eventId === "string" && eventId !== "") {
          if (handled.has(eventId)) return;
          handled.add(eventId);
        }
        ctx.log(`${event.type}: ${await onAction(ctx, event.payload)}`);
      },

      /** Everything held for this company. A company must be able to leave with its own data. */
      async exportData() {
        return { dialogOpen: await openStore(ctx).isDialogOpen(), handled: [...handled] };
      },

      /** Erased, and answered only once it is gone: after this, the company looks like a new one. */
      async deleteData() {
        await openStore(ctx).forget();
        handled.clear();
      },
    };
  },
});
