# {{nameEn}}

A plugin for Argus. It connects to the kernel by dialling out — no inbound port, no domain, no
certificate. As generated, it ships no interface code at all: the page, the button and the modal are
data, and the product's own shell draws them. When that vocabulary runs out, [a screen of its
own](#when-the-shell-cannot-draw-it) is one command away.

## Running it

```
npm install
PLUGIN_CONNECTION_TOKEN=... npm start
```

The token comes from **Plugins → Adicionar plugin** in the product. It already carries the address of
the server that minted it, so there is no address to set beside it. It works once: spending it
installs this plugin for the company that generated it. After the first boot the credentials live
under `data/`, and `npm start` on its own is enough.

## Tests

```
npm test
```

The suite drives two companies side by side with no kernel, and ends with the SDK's conformance
suite: idempotence, degradation, undeclared events, company leakage, export and deletion.

## Lint and types

```
npm run lint
npm run typecheck
```

`npm run fix` applies what Biome can fix on its own. The script calls the binary inside
`node_modules` on purpose: a bare `biome` -- or `npx biome` -- resolves an unrelated package of that
name on npm, which analyses nothing and exits 0, so the lint would report success having read no
file at all.

## When the shell cannot draw it

Everything above needs no build step, because nothing here is compiled for a browser. When this
plugin needs something the shell's vocabulary cannot draw, give it a screen of its own:

```
npx @creativepetabyte/argus-sdk add-screen
```

That adds `ui/`, a `build:ui` script, and the option that has the KERNEL host the bundle — the three
of them together, because two out of three is a plugin that announces an address nobody can fetch.

## What is in here

| file | what it is |
|---|---|
| `src/plugin.ts` | the manifest and `create`: the page, the press, the modal |
| `src/store.ts` | this company's state, behind names that say what they mean |
| `src/main.ts` | the process: `runPlugin`, and nothing else |
| `src/plugin.test.ts` | the press loop and the conformance suite |
| `biome.json` | the formatter and the linter `npm run lint` runs |
