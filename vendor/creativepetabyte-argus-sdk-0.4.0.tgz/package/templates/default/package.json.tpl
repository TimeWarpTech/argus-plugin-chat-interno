{
  "name": "{{folder}}",
  "private": true,
  "type": "module",
  "scripts": {
    "start": "tsx src/main.ts",
    "test": "vitest run",
    "typecheck": "tsc -p tsconfig.json",
    "lint": "node node_modules/@biomejs/biome/bin/biome check .",
    "fix": "node node_modules/@biomejs/biome/bin/biome check --write ."
  },
  "engines": {
    "node": ">=22"
  },
  "dependencies": {
    "@creativepetabyte/argus-sdk": "{{sdkVersion}}"
  },
  "devDependencies": {
    "@biomejs/biome": "2.5.14",
    "tsx": "^4.23.15",
    "typescript": "~6.0.3",
    "vitest": "^5.0.2"
  }
}
