import { fileURLToPath } from "node:url";
import tailwind from "@tailwindcss/vite";
import react from "@vitejs/plugin-react";
import { defineConfig } from "vite";

/**
 * This plugin's interface, built the way the product can load it.
 *
 * Four decisions, each of which costs a day to rediscover:
 *
 * 1. **React is `external`.** The host hands it over through an import map, because two copies of
 *    React on one page are two reconcilers with separate state -- hooks break and context does not
 *    cross, far from the line that caused it. Bundling it in also drags `process.env.NODE_ENV` into
 *    a browser that has no `process`, which fails as "this plugin could not be loaded" with the
 *    upload, the hash and the address all perfectly correct. Measured, in that order.
 * 2. **One ES module, one file.** `lib` with a single entry, so the manifest points at one address
 *    and one `integrity` hash pins the whole artefact. A build that split into chunks would be
 *    several files and several hashes, and the kernel hosts one.
 * 3. **`root` is this directory**, computed rather than assumed, so the build works from the
 *    repository root as well as from here.
 * 4. **`NODE_ENV` is set here, not inherited.** It is the shell, not this file, that decided what the
 *    bundle contained: Vite reads `process.env.NODE_ENV` for `isProduction`, the React plugin builds
 *    its JSX transform from that, and under `test` or `development` it emits `jsxDEV` -- which drags
 *    `react/jsx-dev-runtime` in and stamps every element with the absolute path of the machine that
 *    built it. Measured: one command, green from one shell and a broken plugin from the next, the
 *    environment the only difference. `mode: "production"` does NOT fix it, because `NODE_ENV` wins
 *    over it, and the React plugin exposes no option of its own.
 */
process.env.NODE_ENV = "production";

export default defineConfig({
  root: fileURLToPath(new URL(".", import.meta.url)),
  plugins: [react(), tailwind()],
  build: {
    lib: { entry: "src/ui.tsx", formats: ["es"], fileName: () => "ui.js" },
    // Every entry the host's import map serves, dev runtime included: one left out is one bundled.
    rollupOptions: {
      external: ["react", "react-dom", "react-dom/client", "react/jsx-runtime", "react/jsx-dev-runtime"],
    },
    cssCodeSplit: false,
    outDir: "dist",
    emptyOutDir: true,
  },
});
