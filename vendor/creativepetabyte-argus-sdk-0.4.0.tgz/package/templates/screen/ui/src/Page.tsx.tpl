/**
 * This plugin's screen, drawn by its own code in the browser.
 *
 * It runs inside a shadow root, so these rules belong to this plugin and reach nothing else on the
 * page. The colours are the PRODUCT's tokens, read through `var(--color-…)`: custom properties cross
 * a shadow boundary on their own, so this screen follows the product into dark mode with nobody
 * arranging it.
 *
 * The locale is handed in rather than read from the browser: a plugin that asks
 * `navigator.language` shows one language to a company that chose another.
 *
 * And the DATA comes from this plugin's own contract, over `call`. That is the only way a bundle
 * reaches a plugin, which is worth saying plainly because the plausible alternative is wrong: an
 * author who had never seen this platform reached for `fetch` on `/api/v1/plugins/<id>/routes/orders`, a
 * sensible-looking address that has never existed. The kernel answers 404 there. Their plugin passed
 * its tests, typechecked, built a bundle, and drew a page that stayed empty forever. There is no URL
 * to build here and no credential in this file: the host passes `call` to this component, the shell
 * binds the plugin id, and the session's token stays in memory where the product keeps it.
 */
import type { PluginCall } from "@creativepetabyte/argus-sdk/ui";
import { useCallback, useEffect, useState } from "react";

/**
 * The contract this screen asks, spelled here as well as in `src/plugin.ts`.
 *
 * Two spellings of one string looks like the duplication this project refuses, and the alternative
 * is worse: importing it from `src/` would pull the plugin's PROCESS into a browser bundle -- its
 * storage, its `node:fs` -- for the sake of one constant. So the string is repeated, and
 * `add-screen.test.ts` asserts that both halves name the same contract and the same methods. The
 * test is the single definition; these are two copies of it.
 */
const SCREEN = "{{pluginId}}.v1.Screen";

export interface PageProps {
  locale?: string;
  /**
   * Absent when nobody is hosting this component -- a test, a preview, a slot somebody mounted on
   * their own. That is a state to draw, never a reason to throw: an exception here surfaces as the
   * product saying this plugin broke, when all that happened is that there was nobody to ask.
   */
  call?: PluginCall;
}

const WORDS = {
  "pt-BR": {
    open: "Abrir",
    title: "{{namePtBr}}",
    body: "Esta janela é do plugin: o bundle desenha, o kernel hospeda, e o produto só empresta a página.",
    close: "Fechar",
    loading: "Carregando…",
    offline: "Sem o produto por trás, esta tela não tem a quem perguntar.",
    state: (open: boolean) => `O plugin guarda esta janela como ${open ? "aberta" : "fechada"}.`,
  },
  en: {
    open: "Open",
    title: "{{nameEn}}",
    body: "This window is the plugin's: its bundle draws it, the kernel hosts it, and the product only lends the page.",
    close: "Close",
    loading: "Loading…",
    offline: "With no product behind it, this screen has nobody to ask.",
    state: (open: boolean) => `The plugin keeps this window as ${open ? "open" : "closed"}.`,
  },
} as const;

const BUTTON =
  "rounded-lg px-4 py-2 text-sm font-medium text-white bg-[var(--color-accent)] hover:opacity-90 transition";

/**
 * What `State` and `SetOpen` answered, read rather than asserted.
 *
 * It crossed a kernel and a plugin process to get here. `as` on that is a cast that reads fine until
 * the shape changes, and the day it changes is the day a refusal gets drawn as a result.
 */
function openIn(answer: unknown): boolean | undefined {
  if (typeof answer !== "object" || answer === null) return undefined;
  const { open } = answer as Record<string, unknown>;
  return typeof open === "boolean" ? open : undefined;
}

export function Page({ locale, call }: PageProps) {
  const words = locale?.startsWith("en") === true ? WORDS.en : WORDS["pt-BR"];
  const [open, setOpen] = useState<boolean | undefined>(undefined);

  /** Asks the plugin, and keeps whatever it answered. One place reads the answer, so one place guards it. */
  const ask = useCallback(
    async (method: string, input?: unknown): Promise<void> => {
      if (call === undefined) return;
      setOpen(openIn(await call(SCREEN, method, input)));
    },
    [call],
  );

  // What the PLUGIN holds for this company, not what this component last decided: a reload, another
  // tab or another browser all draw the same thing, because none of them is where the state lives.
  useEffect(() => {
    void ask("State");
  }, [ask]);

  if (call === undefined) return <p className="p-6 text-sm text-[var(--color-muted)]">{words.offline}</p>;
  if (open === undefined) return <p className="p-6 text-sm text-[var(--color-muted)]">{words.loading}</p>;

  return (
    <div className="p-6">
      <button type="button" className={BUTTON} onClick={() => void ask("SetOpen", { open: true })}>
        {words.open}
      </button>

      <p className="mt-4 text-sm text-[var(--color-muted)]">{words.state(open)}</p>

      {open ? (
        <div className="fixed inset-0 z-50 grid place-items-center bg-black/40 p-4">
          <div
            role="dialog"
            aria-modal="true"
            aria-label={words.title}
            className="w-full max-w-md rounded-xl border border-[var(--color-line)] bg-[var(--color-panel)] p-6 shadow-xl"
          >
            <h2 className="text-lg font-semibold text-[var(--color-text)]">{words.title}</h2>
            <p className="mt-3 text-sm text-[var(--color-muted)]">{words.body}</p>
            <button type="button" className={`${BUTTON} mt-6`} onClick={() => void ask("SetOpen", { open: false })}>
              {words.close}
            </button>
          </div>
        </div>
      ) : null}
    </div>
  );
}
