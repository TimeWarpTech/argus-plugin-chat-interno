import compiled from "./ui.css?inline";

/**
 * The bundle: what the host loads, and everything it may name.
 *
 * Deliberately almost empty. The manifest names an EXPORT of this module -- `Page` -- and the host
 * resolves that name against what loaded. No string on this path becomes code: no `eval`, no
 * `new Function`, no `innerHTML` with anything of this plugin's. Approval covers an artefact
 * somebody read at a version, which is what the `integrity` hash pins, and a name is not an artefact.
 */

/**
 * The compiled rules, EXPORTED rather than injected.
 *
 * One artefact and one hash: the bundle's `integrity` already covers these bytes, so there is one
 * thing somebody read and one thing pinned, no second origin to approve, and no way for the sheet
 * and the script to drift apart between reviews.
 *
 * A build that wrote these into `document.head` on import -- the default of most "inject styles"
 * options -- fails twice over: the rules restyle the PRODUCT, and they still do not style this
 * plugin, because rules in the document do not cross into a shadow root. The symptom is a plugin
 * rendering unstyled while the product around it changes appearance, which reads as two unrelated
 * bugs. Only a string export named `css` is read by the host.
 */
export const css = compiled;

export { Page } from "./Page";
