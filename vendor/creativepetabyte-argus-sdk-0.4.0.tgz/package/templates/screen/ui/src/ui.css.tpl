/* This plugin's own Tailwind, preflight and all. It is contained by the shadow root the host puts
   this bundle in -- never by good manners.

   The product's tokens are USED here, never redeclared: `@theme { --color-panel: var(--color-panel) }`
   is a circular reference the browser discards, and every themed colour then silently reads
   transparent -- which looks exactly like the shadow boundary blocking the tokens and gets reported
   as a platform bug. Custom properties cross a shadow boundary on their own, so
   `bg-[var(--color-panel)]` simply works and this plugin follows the product into dark mode with
   nobody arranging it. */
@import "tailwindcss";
