/**
 * The process: still three lines, still no inbound port.
 *
 * `hostedBundle` is what makes the screen work from a machine nobody can reach: the runtime hands
 * the built file to the kernel at every handshake and announces the address it gets back. Without
 * it, a plugin would have to serve the bundle itself from an address every agent's browser can
 * reach -- which is the one thing a plugin that only dials out cannot promise.
 *
 * If the file is not there, the SDK says so by name and the plugin runs with no screen rather than
 * announcing an address nobody can fetch. `prestart` builds it, so that is a message you should
 * never see.
 */
import { runPlugin } from "@creativepetabyte/argus-sdk";
import plugin from "./plugin.js";

await runPlugin(plugin, { hostedBundle: { file: "ui/dist/ui.js" } });
