/**
 * What this plugin puts on screen: a component of its own, in a bundle the KERNEL hosts.
 *
 * Only the PAGE changed when this plugin gained a screen. The presses and the shell-drawn modal are
 * still here and still work: a plugin with its own code in the browser does not lose the vocabulary
 * the shell draws, and keeping both visible is how an author sees that they are different tools.
 *
 * The address is not written here and must not be: the runtime uploads the built file at every
 * handshake and replaces the address and the hash with what the kernel answered -- including after a
 * reconnection, which a hash taken once at startup cannot follow. If hosting ever fails the screen
 * is DROPPED rather than announced at the address below, because the SDK refuses to fall back.
 */
import { type ManifestSlot, NAVBAR_LEADING, screens } from "@creativepetabyte/argus-sdk";

export const PLUGIN_ID = "{{pluginId}}";
export const SCREEN_PATH = "{{directory}}";

/** The two presses this plugin answers. Any other press belongs to somebody else. */
export const OPEN = "{{pluginId}}.open";
export const CLOSE = "{{pluginId}}.close";

/**
 * The name of an export in `ui/dist/ui.js`. A NAME, never code.
 *
 * The bundle is fetched by the browser and executed in the page, so what crosses from here is a
 * string the shell looks up -- not a function, and nothing built at runtime.
 */
const PAGE_COMPONENT = "Page";

/** Where this plugin would serve its own bundle from, if it served one. The runtime overwrites it. */
const UI_URL = "http://localhost:4610/ui.js";

export const screen = screens({
  url: UI_URL,
  pages: [
    {
      path: SCREEN_PATH,
      title: { "pt-BR": "{{namePtBr}}", en: "{{nameEn}}" },
      component: PAGE_COMPONENT,
      rail: { icon: "sparkles" },
    },
  ],
});

/**
 * The modal the SHELL draws, still announced on a press.
 *
 * A modal exists in the slot vocabulary (`kind`) and not in the page one (`type`). Your component
 * can draw its own -- `ui/src/Page.tsx` does -- and this one remains for everything outside your
 * page: a press arriving from another plugin's screen, or from a slot you contribute elsewhere.
 */
export const dialog: ManifestSlot = {
  id: `${PLUGIN_ID}:dialog`,
  slot: NAVBAR_LEADING,
  content: {
    kind: "dialog",
    title: { key: "dialog.title" },
    closeLabel: { key: "dialog.close" },
    closeAction: CLOSE,
    children: [{ kind: "text", value: { key: "dialog.body" } }],
  },
};
